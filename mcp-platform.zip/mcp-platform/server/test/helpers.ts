import type { AddressInfo } from "node:net";
import { exportJWK, generateKeyPair, SignJWT, createLocalJWKSet, type JWK } from "jose";
import { createAuthenticator } from "../src/auth.js";
import { loadConfig, type Config } from "../src/config.js";
import type { K8sEvent, KubeReader, Obj } from "../src/kube.js";
import { createLogger } from "../src/logger.js";
import { createApp } from "../src/server.js";
import { RateLimiter } from "../src/ratelimit.js";

export const ISSUER = "https://idp.example.com";
export const AUDIENCE = "k8s-governance-mcp";
export const NOW = new Date("2026-09-29T10:00:00Z");

export const baseEnv = {
  AUTH_ISSUER: ISSUER,
  AUTH_AUDIENCE: AUDIENCE,
  AUTH_JWKS_URI: "https://idp.example.com/jwks",
};

export async function makeKeys() {
  const { publicKey, privateKey } = await generateKeyPair("RS256");
  const jwk: JWK = { ...(await exportJWK(publicKey)), kid: "k1", alg: "RS256", use: "sig" };
  const resolver = createLocalJWKSet({ keys: [jwk] });
  const sign = (claims: Record<string, unknown>, o: { aud?: string; iss?: string; exp?: string | number } = {}) =>
    new SignJWT(claims)
      .setProtectedHeader({ alg: "RS256", kid: "k1" })
      .setSubject("alice@example.com")
      .setIssuer(o.iss ?? ISSUER)
      .setAudience(o.aud ?? AUDIENCE)
      .setIssuedAt()
      .setExpirationTime(o.exp ?? "5m")
      .sign(privateKey);
  return { resolver, sign };
}

export interface FakeData {
  exceptions?: Obj[];
  events?: K8sEvent[];
  deployments?: Record<string, Obj>;
  custom?: Record<string, Obj>;
}

export function fakeKube(d: FakeData = {}): KubeReader & { calls: string[] } {
  const calls: string[] = [];
  return {
    calls,
    async listCustom(a) {
      calls.push(`listCustom:${a.plural}:${a.namespace ?? "*"}`);
      return (d.exceptions ?? []).filter((e) => !a.namespace || e.metadata.namespace === a.namespace);
    },
    async getCustom(a) {
      calls.push(`getCustom:${a.plural}:${a.namespace}/${a.name}`);
      const o = d.custom?.[`${a.plural}/${a.namespace}/${a.name}`] ?? d.exceptions?.find((e) => e.metadata.name === a.name && e.metadata.namespace === a.namespace);
      if (!o) throw Object.assign(new Error("nf"), { code: 404 });
      return o;
    },
    async listEvents() {
      return d.events ?? [];
    },
    async getDeployment(a) {
      const o = d.deployments?.[`${a.namespace}/${a.name}`];
      if (!o) throw Object.assign(new Error("nf"), { code: 404 });
      return o;
    },
    async listPods() {
      return [];
    },
  };
}

export async function startApp(data: FakeData = {}, env: Record<string, string> = {}) {
  const cfg: Config = loadConfig({ ...baseEnv, ...env });
  const keys = await makeKeys();
  const lines: string[] = [];
  const log = createLogger("debug", (l) => lines.push(l));
  const kube = fakeKube(data);
  const app = createApp({
    cfg,
    log,
    kube,
    now: () => NOW,
    auth: createAuthenticator(cfg, keys.resolver),
    limiter: new RateLimiter(cfg.RATE_LIMIT_WINDOW_MS, cfg.RATE_LIMIT_MAX),
  });
  const server = app.listen(0, "127.0.0.1");
  await new Promise((r) => server.once("listening", r));
  const url = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  return { url, sign: keys.sign, lines, kube, close: () => new Promise((r) => server.close(r)) };
}

export const exception = (ns: string, name: string, ruleId: string, validDate: string, extra: Obj = {}): Obj => ({
  metadata: { name, namespace: ns },
  spec: { ruleId, validDate, jiraTicket: "SVC-10097", approvedBy: "platform-oncall@example.com", ...extra },
});
