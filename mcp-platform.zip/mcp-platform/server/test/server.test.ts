import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { afterEach, describe, expect, it } from "vitest";
import { exception, startApp } from "./helpers.js";

let ctx: Awaited<ReturnType<typeof startApp>> | undefined;
afterEach(async () => {
  await ctx?.close();
  ctx = undefined;
});

async function connect(url: string, token: string) {
  const client = new Client({ name: "test", version: "1.0.0" });
  await client.connect(
    new StreamableHTTPClientTransport(new URL(`${url}/mcp`), {
      requestInit: { headers: { Authorization: `Bearer ${token}` } },
    }),
  );
  return client;
}
const text = (r: any) => r.content[0].text as string;

const data = {
  exceptions: [
    exception("team-a", "waiver-a-441", "CIS-4.4.1", "2026-09-29"),
    exception("team-a", "old-a-441", "CIS-4.4.1", "2026-09-20"),
    exception("team-b", "waiver-b", "CIS-4.1.5", "2026-09-29"),
  ],
  events: [
    {
      type: "Warning",
      reason: "FailedCreate",
      message: "DENIED by Audit-Guard Webhook: [CIS-4.4.1] uses secretKeyRef",
      lastTimestamp: "2026-09-29T09:00:00Z",
      involvedObject: { kind: "ReplicaSet", name: "payment-service-abc" },
    },
  ],
  deployments: { "audit-guard-system/audit-guard-webhook": { spec: { replicas: 1 }, status: { readyReplicas: 1 } } },
  custom: {
    "rootsyncs/config-management-system/root-sync": {
      status: { source: { commit: "abc" }, sync: { commit: "abc", lastUpdate: "t" } },
    },
  },
};

describe("authentication (gateway forwards tokens untouched, so we must enforce)", () => {
  it("rejects missing token with 401", async () => {
    ctx = await startApp(data);
    const r = await fetch(`${ctx.url}/mcp`, { method: "POST", body: "{}", headers: { "content-type": "application/json" } });
    expect(r.status).toBe(401);
    expect(r.headers.get("www-authenticate")).toContain("Bearer");
  });

  it("rejects wrong audience, wrong issuer, expired and garbage tokens", async () => {
    ctx = await startApp(data);
    const bad = [
      await ctx.sign({ groups: ["platform-oncall"] }, { aud: "other" }),
      await ctx.sign({ groups: ["platform-oncall"] }, { iss: "https://evil.example.com" }),
      await ctx.sign({ groups: ["platform-oncall"] }, { exp: Math.floor(Date.now() / 1000) - 3600 }),
      "not.a.jwt",
    ];
    for (const t of bad) {
      const r = await fetch(`${ctx.url}/mcp`, {
        method: "POST",
        body: "{}",
        headers: { "content-type": "application/json", authorization: `Bearer ${t}` },
      });
      expect(r.status).toBe(401);
    }
  });

  it("rejects an alg=none token", async () => {
    ctx = await startApp(data);
    const b64 = (o: object) => Buffer.from(JSON.stringify(o)).toString("base64url");
    const t = `${b64({ alg: "none" })}.${b64({ sub: "x", iss: "https://idp.example.com", aud: "k8s-governance-mcp", groups: ["platform-oncall"], iat: 1, exp: 9999999999 })}.`;
    const r = await fetch(`${ctx.url}/mcp`, { method: "POST", body: "{}", headers: { "content-type": "application/json", authorization: `Bearer ${t}` } });
    expect(r.status).toBe(401);
  });

  it("returns 403 for a valid token without an allowed role", async () => {
    ctx = await startApp(data);
    const t = await ctx.sign({ groups: ["random"] });
    const r = await fetch(`${ctx.url}/mcp`, { method: "POST", body: "{}", headers: { "content-type": "application/json", authorization: `Bearer ${t}` } });
    expect(r.status).toBe(403);
  });
});

describe("authorisation and tools", () => {
  it("platform on-call sees every tool, incl. platform-only ones, and all namespaces", async () => {
    ctx = await startApp(data);
    const c = await connect(ctx.url, await ctx.sign({ groups: ["platform-oncall"] }));
    const names = (await c.listTools()).tools.map((t) => t.name);
    expect(names).toContain("get_audit_guard_health");
    const all = JSON.parse(text(await c.callTool({ name: "list_audit_exceptions", arguments: {} })));
    expect(all.count).toBe(3);
    const active = JSON.parse(text(await c.callTool({ name: "list_audit_exceptions", arguments: { state: "active" } })));
    expect(active.items.map((i: any) => i.name).sort()).toEqual(["waiver-a-441", "waiver-b"]);
    const health = JSON.parse(text(await c.callTool({ name: "get_audit_guard_health", arguments: {} })));
    expect(health).toMatchObject({ healthy: true, singleReplicaRisk: true });
    const rs = JSON.parse(text(await c.callTool({ name: "get_configsync_status", arguments: { kind: "RootSync", name: "root-sync" } })));
    expect(rs.inSync).toBe(true);
    await c.close();
  });

  it("every tool is advertised read-only", async () => {
    ctx = await startApp(data);
    const c = await connect(ctx.url, await ctx.sign({ groups: ["platform-oncall"] }));
    for (const t of (await c.listTools()).tools) {
      expect(t.annotations?.readOnlyHint, t.name).toBe(true);
      expect(t.annotations?.destructiveHint, t.name).toBe(false);
    }
    await c.close();
  });

  it("tenant is confined to their namespaces and cannot see platform-only tools", async () => {
    ctx = await startApp(data);
    const c = await connect(ctx.url, await ctx.sign({ groups: ["tenant-viewer"], k8s_namespaces: ["team-a"] }));
    expect((await c.listTools()).tools.map((t) => t.name)).not.toContain("get_audit_guard_health");

    const own = JSON.parse(text(await c.callTool({ name: "list_audit_exceptions", arguments: { namespace: "team-a" } })));
    expect(own.items.every((i: any) => i.namespace === "team-a")).toBe(true);

    const other = await c.callTool({ name: "list_audit_exceptions", arguments: { namespace: "team-b" } });
    expect(other.isError).toBe(true);
    expect(text(other)).toMatch(/^forbidden/);

    const noNs = await c.callTool({ name: "list_audit_exceptions", arguments: {} });
    expect(noNs.isError).toBe(true); // cluster-wide listing is not allowed for tenants

    const root = await c.callTool({ name: "get_configsync_status", arguments: { kind: "RootSync", name: "root-sync" } });
    expect(root.isError).toBe(true);

    // the forbidden calls never reached the cluster
    expect(ctx.kube.calls.filter((x) => x.includes("team-b") || x.includes("*"))).toEqual([]);
    await c.close();
  });

  it("explain_denial ties the denial to today's waiver state", async () => {
    ctx = await startApp(data);
    const c = await connect(ctx.url, await ctx.sign({ groups: ["tenant-viewer"], k8s_namespaces: ["team-a"] }));
    const r = JSON.parse(text(await c.callTool({ name: "explain_denial", arguments: { namespace: "team-a", workload: "payment-service" } })));
    expect(r.todayUtc).toBe("2026-09-29");
    expect(r.rules).toEqual([expect.objectContaining({ ruleId: "CIS-4.4.1", status: "waived-today" })]);
    await c.close();
  });

  it("validates input and maps upstream 404 without leaking internals", async () => {
    ctx = await startApp(data);
    const c = await connect(ctx.url, await ctx.sign({ groups: ["platform-oncall"] }));
    const nf = await c.callTool({ name: "get_audit_exception", arguments: { namespace: "team-a", name: "nope" } });
    expect(text(nf)).toBe("not_found: Resource not found");
    const bad = await c.callTool({ name: "list_audit_exceptions", arguments: { ruleId: "; drop table" } }).catch((e) => e);
    expect(bad?.isError === true || bad instanceof Error).toBe(true);
    await c.close();
  });
});

describe("audit trail, hardening and limits", () => {
  it("writes an audit record per call with actor, tool and args", async () => {
    ctx = await startApp(data);
    const c = await connect(ctx.url, await ctx.sign({ groups: ["platform-oncall"] }));
    await c.callTool({ name: "list_audit_exceptions", arguments: { namespace: "team-a" } });
    await c.close();
    const rec = ctx.lines.map((l) => JSON.parse(l)).find((l) => l.audit && l.tool === "list_audit_exceptions");
    expect(rec).toMatchObject({ actor: "alice@example.com", outcome: "ok", args: { namespace: "team-a" } });
    expect(rec.requestId).toBeTruthy();
  });

  it("never logs bearer tokens or JWTs", async () => {
    ctx = await startApp(data);
    const token = await ctx.sign({ groups: ["random"] });
    await fetch(`${ctx.url}/mcp`, { method: "POST", body: "{}", headers: { "content-type": "application/json", authorization: `Bearer ${token}` } });
    expect(ctx.lines.join("\n")).not.toContain(token);
  });

  it("redacts secret-looking values from tool output", async () => {
    const leaky = { ...data, events: [{ type: "Warning", message: "Audit-Guard: password=hunter2hunter2 token: abcdef123456", involvedObject: { kind: "Pod", name: "p" } }] };
    ctx = await startApp(leaky);
    const c = await connect(ctx.url, await ctx.sign({ groups: ["platform-oncall"] }));
    const out = text(await c.callTool({ name: "list_events", arguments: { namespace: "team-a" } }));
    expect(out).not.toContain("hunter2");
    expect(out).toContain("[REDACTED]");
    await c.close();
  });

  it("rate limits per subject with Retry-After", async () => {
    ctx = await startApp(data, { RATE_LIMIT_MAX: "2" });
    const t = await ctx.sign({ groups: ["platform-oncall"] });
    const hit = () => fetch(`${ctx!.url}/mcp`, { method: "POST", body: "{}", headers: { "content-type": "application/json", authorization: `Bearer ${t}` } });
    await hit();
    await hit();
    const r = await hit();
    expect(r.status).toBe(429);
    expect(Number(r.headers.get("retry-after"))).toBeGreaterThan(0);
  });

  it("rejects oversize bodies, and GET/DELETE (stateless)", async () => {
    ctx = await startApp(data, { MAX_BODY_BYTES: "100" });
    const big = await fetch(`${ctx.url}/mcp`, { method: "POST", body: "x".repeat(500), headers: { "content-type": "application/json" } });
    expect(big.status).toBe(413);
    expect((await fetch(`${ctx.url}/mcp`)).status).toBe(405);
    expect((await fetch(`${ctx.url}/mcp`, { method: "DELETE" })).status).toBe(405);
    expect((await fetch(`${ctx.url}/healthz`)).status).toBe(200);
  });
});
