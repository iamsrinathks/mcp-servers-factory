# k8s-governance-mcp

Read-only MCP server that lets platform on-call (and, optionally, tenants) ask questions about
Audit-Guard denials, `AuditException` waivers, Config Sync and workload health on the shared GKE cluster.
Built to sit **behind your MCP Gateway** at `/mcp/k8s-governance`.

```
MCP client ──► MCP Gateway (/mcp/k8s-governance, per-IP rate limit, Authorization pass-through)
                    │  Streamable HTTP
                    ▼
        k8s-governance-mcp  ×3 replicas (stateless)
          1. validate JWT (issuer, audience, alg allow-list, exp)   ← the gateway does not
          2. per-user rate limit
          3. role → namespace authorisation
          4. tool runs against KubeReader (get/list only)
          5. redact → bound output → audit log
                    ▼
        Kubernetes API (ClusterRole: get/list on 6 resources, no Secrets)
```

## Tools (all annotated `readOnlyHint: true`)

| Tool | Who | Purpose |
|---|---|---|
| `list_audit_exceptions` | platform, tenant (own ns) | Waivers with computed state: active / expired / future |
| `get_audit_exception` | platform, tenant (own ns) | One waiver |
| `explain_denial` | platform, tenant (own ns) | Denial events + per-rule waiver status + next step |
| `get_workload_status` | platform, tenant (own ns) | Deployment rollout + pod phase/restarts |
| `list_events` | platform, tenant (own ns) | Recent events, optionally warnings only |
| `get_configsync_status` | RepoSync: tenant; RootSync: platform | Did the merged exception reach the cluster? |
| `get_audit_guard_health` | platform only (hidden from tenants) | Webhook replicas; warns on single replica |

## Banking-grade controls

- **AuthN enforced here, not at the gateway** (the gateway forwards `Authorization` untouched). JWKS-verified, `iss`/`aud` pinned, algorithm allow-list (no `none`), required `sub/exp/iat`, opaque failure messages.
- **AuthZ**: roles from the token map to platform (all namespaces) or tenant (only namespaces in the `k8s_namespaces` claim). Denied calls never reach the cluster (tested).
- **Least privilege, twice**: `KubeReader` has no write/Secrets method, *and* RBAC grants only `get`/`list` on `auditexceptions, rootsyncs, reposyncs, events, pods, deployments`. No `secrets`, `pods/log`, `pods/exec`.
- **Audit trail**: one JSON `audit` record per tool call (actor, roles, tool, args, outcome, duration, request id). Ship to Cloud Logging with a locked retention bucket.
- **Data protection**: tokens/JWTs/keys/`password=` patterns redacted from logs and tool output; output capped at 60 KB; list limits capped.
- **Availability**: stateless (any replica serves any call), 3 replicas, PDB `minAvailable: 2`, zone spread, graceful SIGTERM drain, K8s call timeouts.
- **Hardening**: distroless non-root image, read-only rootfs, drop ALL caps, seccomp, restricted Pod Security, default-deny NetworkPolicy, `/metrics` on a separate port not exposed by the Service, body-size limit, fail-fast config validation.
- **Observability**: Prometheus `mcp_tool_calls_total`, `mcp_tool_duration_seconds`, `mcp_auth_failures_total`, `mcp_rate_limited_total`.

## Run / test

```bash
npm ci && npm test && npm run build
AUTH_ISSUER=... AUTH_AUDIENCE=... AUTH_JWKS_URI=... npm start   # uses your kubeconfig locally
```

Deployment (gateway + server, localhost → sandbox → production): see `../DEPLOYMENT.md`.

## Before production — open items

1. Set `AUTH_*` to your IdP (and confirm which claim carries groups/roles — Azure AD often uses `roles` or a group-object-id).
2. Fill the `TODO` namespaces in the NetworkPolicy and tighten API/IdP egress to real CIDRs/FQDNs.
3. Build/push the image, pin by digest, sign it (Binary Authorization), scan in CI.
4. Verify CRD group/version/plural against your real `AuditException` and the Config Sync `v1beta1` API on your cluster.
5. Per-replica rate limiting is in-memory; the gateway provides the fleet-wide limit.
6. Deliberately not included: pod log access (high leak risk), any write path. Adding either needs a security review.
