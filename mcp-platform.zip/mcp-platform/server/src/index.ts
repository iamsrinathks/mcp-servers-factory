import { readFileSync } from "node:fs";
import { createServer } from "node:https";
import { createServer as createHttpServer } from "node:http";
import { createAuthenticator } from "./auth.js";
import { loadConfig } from "./config.js";
import { createKubeReader } from "./kube.js";
import { createLogger } from "./logger.js";
import { createApp, createMetricsApp } from "./server.js";

const cfg = loadConfig();
const log = createLogger(cfg.LOG_LEVEL);

const app = createApp({ cfg, log, kube: createKubeReader(cfg), auth: createAuthenticator(cfg) });
const tls = cfg.TLS_CERT_FILE && cfg.TLS_KEY_FILE
  ? { cert: readFileSync(cfg.TLS_CERT_FILE), key: readFileSync(cfg.TLS_KEY_FILE), minVersion: "TLSv1.2" as const }
  : undefined;
if (!tls) log.warn("serving plain HTTP — acceptable only on loopback or behind mesh mTLS");
const main = (tls ? createServer(tls, app) : createHttpServer(app)).listen(cfg.PORT, cfg.HOST, () => log.info("listening", { port: cfg.PORT, tls: !!tls }));
const metrics = createMetricsApp().listen(cfg.METRICS_PORT, cfg.HOST);

main.requestTimeout = 30_000;
main.headersTimeout = 10_000;
main.keepAliveTimeout = 65_000; // > typical LB idle timeout to avoid spurious 502s

let closing = false;
function shutdown(signal: string) {
  if (closing) return;
  closing = true;
  log.info("shutdown_start", { signal });
  // Stop accepting new connections, let in-flight calls finish, then exit.
  main.close(() => {
    metrics.close();
    log.info("shutdown_complete");
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 20_000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("unhandledRejection", (e) => log.error("unhandled_rejection", { err: String(e) }));
process.on("uncaughtException", (e) => {
  log.error("uncaught_exception", { err: String(e) });
  shutdown("uncaughtException");
});
