import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { AuthError, type Principal } from "./auth.js";
import type { Config } from "./config.js";
import type { KubeReader } from "./kube.js";
import { redactDeep, type Logger } from "./logger.js";
import { toolCalls, toolLatency } from "./metrics.js";
import { tools, type ToolContext } from "./tools.js";

const MAX_OUTPUT_CHARS = 60_000;

export interface McpDeps {
  cfg: Config;
  kube: KubeReader;
  log: Logger;
  now?: () => Date;
}

function classify(err: unknown): { code: string; message: string } {
  if (err instanceof AuthError) return { code: "forbidden", message: err.message };
  const status = (err as any)?.code ?? (err as any)?.statusCode ?? (err as any)?.response?.status;
  if (status === 404) return { code: "not_found", message: "Resource not found" };
  if (status === 403) return { code: "upstream_forbidden", message: "Service account lacks access to that resource" };
  if (/timeout/i.test((err as Error)?.message ?? "")) return { code: "timeout", message: "Kubernetes API timed out" };
  if ((err as any)?.name === "ZodError") return { code: "invalid_input", message: "Invalid input" };
  // Never leak internals to the caller; the detail goes to the log only.
  return { code: "internal", message: "Internal error" };
}

/** A fresh, stateless server per request → horizontally scalable, no sticky sessions. */
export function buildMcpServer(deps: McpDeps, principal: Principal, requestId: string): McpServer {
  const { cfg, kube, log } = deps;
  const now = deps.now ?? (() => new Date());
  const server = new McpServer({ name: "k8s-governance-mcp", version: "0.1.0" });
  const ctx: ToolContext = { kube, cfg, principal, now };

  for (const t of tools) {
    if (t.platformOnly && !principal.platform) continue; // hidden from tenants entirely

    server.registerTool(
      t.name,
      {
        title: t.title,
        description: t.description,
        inputSchema: t.input,
        annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
      },
      async (args: any) => {
        const started = process.hrtime.bigint();
        let outcome = "ok";
        try {
          const result = redactDeep(await t.handler(args, ctx));
          let text = JSON.stringify(result, null, 2);
          if (text.length > MAX_OUTPUT_CHARS) text = text.slice(0, MAX_OUTPUT_CHARS) + "\n…[truncated]";
          return { content: [{ type: "text" as const, text }] };
        } catch (err) {
          const { code, message } = classify(err);
          outcome = code;
          if (code === "internal") log.error("tool_failed", { tool: t.name, requestId, err: String((err as Error)?.stack ?? err) });
          return { isError: true, content: [{ type: "text" as const, text: `${code}: ${message}` }] };
        } finally {
          const seconds = Number(process.hrtime.bigint() - started) / 1e9;
          toolCalls.inc({ tool: t.name, outcome });
          toolLatency.observe({ tool: t.name }, seconds);
          // Immutable audit trail: who called what, with which args, and the outcome.
          log.info("audit", {
            audit: true,
            requestId,
            actor: principal.subject,
            roles: principal.roles,
            tool: t.name,
            args,
            outcome,
            durationMs: Math.round(seconds * 1000),
          });
        }
      },
    );
  }
  return server;
}
