import { createRemoteJWKSet, jwtVerify, type JWTVerifyGetKey } from "jose";
import type { Config } from "./config.js";

export interface Principal {
  subject: string;
  roles: string[];
  /** true → may read every namespace (platform on-call). */
  platform: boolean;
  /** namespaces a tenant may read; ignored when platform=true */
  namespaces: string[];
  tokenId?: string;
}

export class AuthError extends Error {
  constructor(
    message: string,
    readonly status: 401 | 403 = 401,
  ) {
    super(message);
  }
}

export interface Authenticator {
  authenticate(authorizationHeader: string | undefined): Promise<Principal>;
}

export function createAuthenticator(cfg: Config, keyResolver?: JWTVerifyGetKey): Authenticator {
  const getKey =
    keyResolver ??
    createRemoteJWKSet(new URL(cfg.AUTH_JWKS_URI), {
      cooldownDuration: 30_000,
      timeoutDuration: 3_000,
    });

  return {
    async authenticate(header) {
      const m = /^Bearer\s+(\S+)$/i.exec(header ?? "");
      if (!m?.[1]) throw new AuthError("Missing bearer token");

      let payload;
      try {
        ({ payload } = await jwtVerify(m[1], getKey, {
          issuer: cfg.AUTH_ISSUER,
          audience: cfg.AUTH_AUDIENCE,
          algorithms: cfg.AUTH_ALLOWED_ALGS, // never trust the token's own alg claim
          clockTolerance: cfg.AUTH_CLOCK_TOLERANCE_S,
          requiredClaims: ["sub", "exp", "iat"],
        }));
      } catch {
        // Deliberately opaque: don't leak why validation failed to the caller.
        throw new AuthError("Invalid token");
      }

      const asList = (v: unknown): string[] =>
        Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
      const roles = asList(payload[cfg.AUTH_ROLES_CLAIM]);
      const platform = roles.includes(cfg.AUTH_PLATFORM_ROLE);
      const tenant = roles.includes(cfg.AUTH_TENANT_ROLE);
      if (!platform && !tenant) throw new AuthError("Not authorised for this service", 403);

      return {
        subject: String(payload.sub),
        roles,
        platform,
        namespaces: platform ? [] : asList(payload[cfg.AUTH_NAMESPACES_CLAIM]),
        tokenId: typeof payload.jti === "string" ? payload.jti : undefined,
      };
    },
  };
}

/** Central namespace authorisation used by every tool. */
export function assertNamespaceAllowed(p: Principal, namespace: string | undefined): void {
  if (p.platform) return;
  if (!namespace) {
    throw new AuthError("A namespace is required for your role", 403);
  }
  if (!p.namespaces.includes(namespace)) {
    throw new AuthError(`No access to namespace '${namespace}'`, 403);
  }
}
