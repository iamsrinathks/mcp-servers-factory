/** Minimal Prometheus text-format registry (no dependency, no surprises). */
type Labels = Record<string, string>;
const key = (l: Labels) => JSON.stringify(Object.entries(l).sort());

class Counter {
  private v = new Map<string, { l: Labels; n: number }>();
  constructor(readonly name: string, readonly help: string) {}
  inc(l: Labels = {}, by = 1) {
    const k = key(l);
    const e = this.v.get(k) ?? { l, n: 0 };
    e.n += by;
    this.v.set(k, e);
  }
  render() {
    const rows = [...this.v.values()].map((e) => `${this.name}${fmt(e.l)} ${e.n}`);
    return [`# HELP ${this.name} ${this.help}`, `# TYPE ${this.name} counter`, ...rows].join("\n");
  }
}

class Summary {
  private v = new Map<string, { l: Labels; sum: number; count: number }>();
  constructor(readonly name: string, readonly help: string) {}
  observe(l: Labels, x: number) {
    const k = key(l);
    const e = this.v.get(k) ?? { l, sum: 0, count: 0 };
    e.sum += x;
    e.count += 1;
    this.v.set(k, e);
  }
  render() {
    const rows = [...this.v.values()].flatMap((e) => [
      `${this.name}_sum${fmt(e.l)} ${e.sum}`,
      `${this.name}_count${fmt(e.l)} ${e.count}`,
    ]);
    return [`# HELP ${this.name} ${this.help}`, `# TYPE ${this.name} summary`, ...rows].join("\n");
  }
}

const fmt = (l: Labels) => {
  const parts = Object.entries(l).map(([k, v]) => `${k}="${v.replace(/["\\\n]/g, "_")}"`);
  return parts.length ? `{${parts.join(",")}}` : "";
};

export const toolCalls = new Counter("mcp_tool_calls_total", "Tool invocations by tool and outcome");
export const toolLatency = new Summary("mcp_tool_duration_seconds", "Tool latency in seconds");
export const authFailures = new Counter("mcp_auth_failures_total", "Rejected requests by HTTP status");
export const rateLimited = new Counter("mcp_rate_limited_total", "Requests rejected by rate limiter");

export const renderMetrics = () =>
  [toolCalls, toolLatency, authFailures, rateLimited].map((m) => m.render()).join("\n") + "\n";
