import * as k8s from "@kubernetes/client-node";
import type { Config } from "./config.js";

/**
 * The ONLY door to the cluster. It exposes a handful of read methods and nothing
 * that can mutate state or touch Secrets — enforced structurally (no such method
 * exists) and again by RBAC (no such verb/resource is granted).
 */
export interface KubeReader {
  listCustom(a: { group: string; version: string; plural: string; namespace?: string; limit: number }): Promise<Obj[]>;
  getCustom(a: { group: string; version: string; plural: string; namespace?: string; name: string }): Promise<Obj>;
  listEvents(a: { namespace: string; fieldSelector?: string; limit: number }): Promise<K8sEvent[]>;
  getDeployment(a: { namespace: string; name: string }): Promise<Obj>;
  listPods(a: { namespace: string; labelSelector?: string; limit: number }): Promise<Obj[]>;
}

export type Obj = Record<string, any>;
export interface K8sEvent {
  type?: string;
  reason?: string;
  message?: string;
  count?: number;
  lastTimestamp?: string;
  involvedObject?: { kind?: string; name?: string };
}

function withTimeout<T>(p: Promise<T>, ms: number, what: string): Promise<T> {
  let t: NodeJS.Timeout;
  const timeout = new Promise<never>((_, rej) => {
    t = setTimeout(() => rej(new Error(`Kubernetes API timeout (${what})`)), ms);
  });
  return Promise.race([p, timeout]).finally(() => clearTimeout(t));
}

export function createKubeReader(cfg: Config): KubeReader {
  const kc = new k8s.KubeConfig();
  kc.loadFromDefault(); // in-cluster ServiceAccount / Workload Identity in GKE
  const custom = kc.makeApiClient(k8s.CustomObjectsApi);
  const core = kc.makeApiClient(k8s.CoreV1Api);
  const apps = kc.makeApiClient(k8s.AppsV1Api);
  const T = cfg.K8S_TIMEOUT_MS;

  return {
    async listCustom({ group, version, plural, namespace, limit }) {
      const res: any = await withTimeout(
        namespace
          ? custom.listNamespacedCustomObject({ group, version, namespace, plural, limit })
          : custom.listClusterCustomObject({ group, version, plural, limit }),
        T,
        `list ${plural}`,
      );
      return res.items ?? [];
    },
    async getCustom({ group, version, plural, namespace, name }) {
      return (await withTimeout(
        namespace
          ? custom.getNamespacedCustomObject({ group, version, namespace, plural, name })
          : custom.getClusterCustomObject({ group, version, plural, name }),
        T,
        `get ${plural}/${name}`,
      )) as Obj;
    },
    async listEvents({ namespace, fieldSelector, limit }) {
      const res = await withTimeout(
        core.listNamespacedEvent({ namespace, fieldSelector, limit }),
        T,
        "list events",
      );
      return (res.items ?? []).map((e) => ({
        type: e.type,
        reason: e.reason,
        message: e.message,
        count: e.count,
        lastTimestamp: (e.lastTimestamp ?? e.eventTime)?.toString(),
        involvedObject: { kind: e.involvedObject?.kind, name: e.involvedObject?.name },
      }));
    },
    async getDeployment({ namespace, name }) {
      return (await withTimeout(
        apps.readNamespacedDeployment({ name, namespace }),
        T,
        `get deployment ${name}`,
      )) as unknown as Obj;
    },
    async listPods({ namespace, labelSelector, limit }) {
      const res = await withTimeout(
        core.listNamespacedPod({ namespace, labelSelector, limit }),
        T,
        "list pods",
      );
      return (res.items ?? []) as unknown as Obj[];
    },
  };
}
