import { randomUUID } from "node:crypto";
import express, { type NextFunction, type Request, type Response } from "express";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { AuthError, type Authenticator } from "./auth.js";
import { buildMcpServer, type McpDeps } from "./mcp.js";
import { authFailures, rateLimited, renderMetrics } from "./metrics.js";
import { RateLimiter } from "./ratelimit.js";

export interface AppDeps extends McpDeps {
  auth: Authenticator;
  limiter?: RateLimiter;
}

export function createApp(deps: AppDeps) {
  const { cfg, log, auth } = deps;
  const limiter = deps.limiter ?? new RateLimiter(cfg.RATE_LIMIT_WINDOW_MS, cfg.RATE_LIMIT_MAX);
  const app = express();

  app.disable("x-powered-by");
  app.set("trust proxy", cfg.TRUST_PROXY_HOPS);

  app.use((req, res, next) => {
    // Correlate with the gateway's request id when present.
    const id = (req.header("x-request-id") ?? "").slice(0, 64).replace(/[^\w-]/g, "") || randomUUID();
    res.locals.requestId = id;
    res.setHeader("X-Request-Id", id);
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Strict-Transport-Security", "max-age=63072000; includeSubDomains");
    next();
  });

  // Liveness / readiness: unauthenticated, no data, no upstream calls.
  app.get("/healthz", (_req, res) => void res.json({ status: "ok" }));
  app.get("/readyz", (_req, res) => void res.json({ status: "ready" }));

  app.post("/mcp", express.json({ limit: cfg.MAX_BODY_BYTES }), async (req: Request, res: Response) => {
    const requestId = res.locals.requestId as string;
    try {
      // The gateway forwards Authorization untouched, so this service is the enforcement point.
      const principal = await auth.authenticate(req.header("authorization"));

      const wait = limiter.check(principal.subject);
      if (wait > 0) {
        rateLimited.inc();
        res.setHeader("Retry-After", String(wait));
        return void res.status(429).json({ error: "Rate limit exceeded" });
      }

      const server = buildMcpServer(deps, principal, requestId);
      const transport = new StreamableHTTPServerTransport({
        sessionIdGenerator: undefined, // stateless: any replica can serve any call
        enableJsonResponse: true,
      });
      res.on("close", () => {
        void transport.close();
        void server.close();
      });
      await server.connect(transport);
      await transport.handleRequest(req, res, req.body);
    } catch (err) {
      if (err instanceof AuthError) {
        authFailures.inc({ status: String(err.status) });
        log.warn("auth_rejected", { requestId, status: err.status, ip: req.ip });
        if (!res.headersSent) {
          res.setHeader("WWW-Authenticate", 'Bearer realm="k8s-governance-mcp"');
          res.status(err.status).json({ error: err.status === 401 ? "Unauthorized" : "Forbidden" });
        }
        return;
      }
      log.error("request_failed", { requestId, err: String((err as Error)?.stack ?? err) });
      if (!res.headersSent) res.status(500).json({ error: "Internal error" });
    }
  });

  // Stateless server: no SSE stream, no session termination.
  const notAllowed = (_req: Request, res: Response) => {
    res.setHeader("Allow", "POST");
    res.status(405).json({ error: "Method not allowed" });
  };
  app.get("/mcp", notAllowed);
  app.delete("/mcp", notAllowed);

  // Body-parser errors (too large / malformed) → clean JSON, no stack traces.
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err?.status === 413 ? 413 : err?.status === 400 ? 400 : 500;
    if (status === 500) log.error("unhandled", { err: String(err?.stack ?? err) });
    res.status(status).json({ error: status === 413 ? "Payload too large" : status === 400 ? "Bad request" : "Internal error" });
  });

  return app;
}

/** Separate listener so /metrics is never exposed through the gateway or Service. */
export function createMetricsApp() {
  const app = express();
  app.disable("x-powered-by");
  app.get("/metrics", (_req, res) => void res.type("text/plain; version=0.0.4").send(renderMetrics()));
  return app;
}
