import { z } from "zod";
import { assertNamespaceAllowed, AuthError, type Principal } from "./auth.js";
import type { Config } from "./config.js";
import type { K8sEvent, KubeReader, Obj } from "./kube.js";

export interface ToolContext {
  kube: KubeReader;
  cfg: Config;
  principal: Principal;
  now: () => Date;
}

export interface ToolDef<S extends z.ZodRawShape = z.ZodRawShape> {
  name: string;
  title: string;
  description: string;
  input: S;
  /** Platform-only tools are hidden from tenants and rejected if called. */
  platformOnly?: boolean;
  handler(args: z.infer<z.ZodObject<S>>, ctx: ToolContext): Promise<unknown>;
}

const k8sName = z.string().regex(/^[a-z0-9]([-a-z0-9.]*[a-z0-9])?$/).max(253);
const ruleId = z.string().regex(/^CIS-\d+(\.\d+)+$/, "expected e.g. CIS-4.4.1");

const utcDay = (d: Date) => d.toISOString().slice(0, 10);

/** Mirrors the webhook's decision so on-call sees exactly what Audit-Guard sees. */
export function exceptionState(validDate: string | undefined, today: string): "active" | "expired" | "future" | "invalid" {
  if (!validDate || !/^\d{4}-\d{2}-\d{2}$/.test(validDate)) return "invalid";
  if (validDate === today) return "active";
  return validDate < today ? "expired" : "future";
}

function summariseException(o: Obj, today: string) {
  const s = o.spec ?? {};
  return {
    name: o.metadata?.name,
    namespace: o.metadata?.namespace,
    ruleId: s.ruleId,
    workloadName: s.workloadName ?? null,
    validDate: s.validDate,
    state: exceptionState(s.validDate, today),
    jiraTicket: s.jiraTicket,
    approvedBy: s.approvedBy,
    reason: s.reason,
  };
}

const cond = (o: Obj) =>
  (o.status?.conditions ?? []).map((c: Obj) => ({
    type: c.type,
    status: c.status,
    reason: c.reason,
    message: c.message,
    lastTransitionTime: c.lastTransitionTime,
  }));

function defineTool<S extends z.ZodRawShape>(t: ToolDef<S>): ToolDef<any> {
  return t as ToolDef<any>;
}

export const tools: ToolDef<any>[] = [
  defineTool({
    name: "list_audit_exceptions",
    title: "List AuditException waivers",
    description:
      "List Audit-Guard AuditException waivers with computed state (active = valid today UTC, expired, future). Tenants must pass a namespace they own.",
    input: {
      namespace: k8sName.optional(),
      ruleId: ruleId.optional(),
      state: z.enum(["active", "expired", "future", "all"]).default("all"),
    },
    async handler({ namespace, ruleId, state }, { kube, cfg, principal, now }) {
      assertNamespaceAllowed(principal, namespace);
      const items = await kube.listCustom({
        group: cfg.AUDIT_EXCEPTION_GROUP,
        version: cfg.AUDIT_EXCEPTION_VERSION,
        plural: cfg.AUDIT_EXCEPTION_PLURAL,
        namespace,
        limit: cfg.MAX_ITEMS,
      });
      const today = utcDay(now());
      const rows = items
        .map((i) => summariseException(i, today))
        .filter((r) => (!ruleId || r.ruleId === ruleId) && (state === "all" || r.state === state));
      return { todayUtc: today, count: rows.length, truncated: items.length >= cfg.MAX_ITEMS, items: rows };
    },
  }),
  defineTool({
    name: "get_audit_exception",
    title: "Get one AuditException",
    description: "Fetch a single AuditException by namespace and name, with computed state.",
    input: { namespace: k8sName, name: k8sName },
    async handler({ namespace, name }, { kube, cfg, principal, now }) {
      assertNamespaceAllowed(principal, namespace);
      const o = await kube.getCustom({
        group: cfg.AUDIT_EXCEPTION_GROUP,
        version: cfg.AUDIT_EXCEPTION_VERSION,
        plural: cfg.AUDIT_EXCEPTION_PLURAL,
        namespace,
        name,
      });
      return summariseException(o, utcDay(now()));
    },
  }),
  defineTool({
    name: "explain_denial",
    title: "Explain why a deployment was denied",
    description:
      "For a namespace (and optional workload), show recent Audit-Guard denial events and whether a valid same-day AuditException exists per CIS rule, with the next step.",
    input: { namespace: k8sName, workload: k8sName.optional() },
    async handler({ namespace, workload }, { kube, cfg, principal, now }) {
      assertNamespaceAllowed(principal, namespace);
      const [events, exceptions] = await Promise.all([
        kube.listEvents({ namespace, limit: cfg.MAX_ITEMS }),
        kube.listCustom({
          group: cfg.AUDIT_EXCEPTION_GROUP,
          version: cfg.AUDIT_EXCEPTION_VERSION,
          plural: cfg.AUDIT_EXCEPTION_PLURAL,
          namespace,
          limit: cfg.MAX_ITEMS,
        }),
      ]);
      const today = utcDay(now());
      const denials = events
        .filter((e) => /audit-guard/i.test(e.message ?? "") || /audit-?guard/i.test(e.reason ?? ""))
        .filter((e) => !workload || e.involvedObject?.name?.startsWith(workload))
        .slice(0, 20);
      const rules = new Set<string>();
      for (const d of denials) for (const m of (d.message ?? "").matchAll(/CIS-\d+(?:\.\d+)+/g)) rules.add(m[0]);

      const ex = exceptions.map((i) => summariseException(i, today));
      const perRule = [...rules].map((r) => {
        const matching = ex.filter((e) => e.ruleId === r && (!e.workloadName || !workload || e.workloadName === workload));
        const active = matching.find((e) => e.state === "active");
        const expired = matching.find((e) => e.state === "expired");
        return {
          ruleId: r,
          status: active ? "waived-today" : expired ? "waiver-expired" : "no-waiver",
          nextStep: active
            ? `Waiver ${active.name} (${active.jiraTicket}) is valid until 00:00 UTC; remediate before it lapses.`
            : "Fix the manifest, or raise a same-day AuditException PR in the platform GitOps repo with a Jira ticket.",
        };
      });
      return { todayUtc: today, deniedEvents: denials.map(briefEvent), rules: perRule };
    },
  }),
  defineTool({
    name: "get_workload_status",
    title: "Deployment and pod status",
    description: "Summarise a Deployment's rollout and its pods (phase, restarts, waiting reasons).",
    input: { namespace: k8sName, name: k8sName },
    async handler({ namespace, name }, { kube, cfg, principal }) {
      assertNamespaceAllowed(principal, namespace);
      const d = await kube.getDeployment({ namespace, name });
      const selector = Object.entries(d.spec?.selector?.matchLabels ?? {})
        .map(([k, v]) => `${k}=${v}`)
        .join(",");
      const pods = await kube.listPods({ namespace, labelSelector: selector || undefined, limit: cfg.MAX_ITEMS });
      return {
        desired: d.spec?.replicas,
        ready: d.status?.readyReplicas ?? 0,
        updated: d.status?.updatedReplicas ?? 0,
        available: d.status?.availableReplicas ?? 0,
        conditions: cond(d),
        pods: pods.map((p) => ({
          name: p.metadata?.name,
          phase: p.status?.phase,
          restarts: (p.status?.containerStatuses ?? []).reduce((n: number, c: Obj) => n + (c.restartCount ?? 0), 0),
          waiting: (p.status?.containerStatuses ?? [])
            .map((c: Obj) => c.state?.waiting?.reason)
            .filter(Boolean),
        })),
      };
    },
  }),
  defineTool({
    name: "list_events",
    title: "Recent namespace events",
    description: "Recent Kubernetes events in a namespace, newest first. Optionally only warnings or for one object.",
    input: {
      namespace: k8sName,
      kind: z.string().max(63).optional(),
      name: k8sName.optional(),
      warningsOnly: z.boolean().default(false),
    },
    async handler({ namespace, kind, name, warningsOnly }, { kube, cfg, principal }) {
      assertNamespaceAllowed(principal, namespace);
      const sel = [kind && `involvedObject.kind=${kind}`, name && `involvedObject.name=${name}`]
        .filter(Boolean)
        .join(",");
      const events = await kube.listEvents({ namespace, fieldSelector: sel || undefined, limit: cfg.MAX_ITEMS });
      return events
        .filter((e) => !warningsOnly || e.type === "Warning")
        .sort((a, b) => (b.lastTimestamp ?? "").localeCompare(a.lastTimestamp ?? ""))
        .slice(0, 50)
        .map(briefEvent);
    },
  }),
  defineTool({
    name: "get_configsync_status",
    title: "Config Sync status",
    description:
      "Status of a Config Sync RootSync (platform only) or RepoSync (tenant namespace): synced commit, conditions and errors. Answers 'did my merged exception reach the cluster?'.",
    input: {
      kind: z.enum(["RootSync", "RepoSync"]),
      name: k8sName.default("root-sync"),
      namespace: k8sName.default("config-management-system"),
    },
    async handler({ kind, name, namespace }, { kube, cfg, principal }) {
      if (kind === "RootSync") {
        if (!principal.platform) throw new AuthError("RootSync is platform-only", 403);
      } else {
        assertNamespaceAllowed(principal, namespace);
      }
      const o = await kube.getCustom({
        group: cfg.CONFIGSYNC_GROUP,
        version: "v1beta1",
        plural: kind === "RootSync" ? "rootsyncs" : "reposyncs",
        namespace,
        name,
      });
      return {
        kind,
        name,
        namespace,
        sourceCommit: o.status?.source?.commit,
        syncCommit: o.status?.sync?.commit,
        lastSyncedAt: o.status?.sync?.lastUpdate,
        inSync: !!o.status?.sync?.commit && o.status?.sync?.commit === o.status?.source?.commit,
        conditions: cond(o),
        errors: [o.status?.source?.errors, o.status?.rendering?.errors, o.status?.sync?.errors]
          .flat()
          .filter(Boolean)
          .slice(0, 10)
          .map((e: Obj) => ({ code: e.code, message: e.errorMessage })),
      };
    },
  }),
  defineTool({
    name: "get_audit_guard_health",
    title: "Audit-Guard webhook health",
    description:
      "Platform-only. Replica readiness of the Audit-Guard admission webhook. failurePolicy=Fail means an unhealthy webhook blocks tenant deployments.",
    input: {},
    platformOnly: true,
    async handler(_a, { kube, cfg }) {
      const namespace = cfg.AUDIT_GUARD_NAMESPACE;
      const d = await kube.getDeployment({ namespace, name: cfg.AUDIT_GUARD_DEPLOYMENT });
      const desired = d.spec?.replicas ?? 0;
      const ready = d.status?.readyReplicas ?? 0;
      return {
        desired,
        ready,
        healthy: desired > 0 && ready === desired,
        singleReplicaRisk: desired < 2,
        blocksTenantsIfDown: true,
        conditions: cond(d),
      };
    },
  }),
];

function briefEvent(e: K8sEvent) {
  return {
    time: e.lastTimestamp,
    type: e.type,
    reason: e.reason,
    object: `${e.involvedObject?.kind ?? "?"}/${e.involvedObject?.name ?? "?"}`,
    count: e.count,
    message: (e.message ?? "").slice(0, 800),
  };
}
