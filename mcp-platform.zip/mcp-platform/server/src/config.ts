import { z } from "zod";

const csv = z
  .string()
  .default("")
  .transform((s) => s.split(",").map((x) => x.trim()).filter(Boolean));

const schema = z.object({
  PORT: z.coerce.number().int().default(8080),
  HOST: z.string().default("0.0.0.0"),
  METRICS_PORT: z.coerce.number().int().default(9090),
  TLS_CERT_FILE: z.string().optional(), // set both to serve HTTPS (cert-manager / internal CA)
  TLS_KEY_FILE: z.string().optional(),
  LOG_LEVEL: z.enum(["debug", "info", "warn", "error"]).default("info"),

  // --- AuthN (the gateway passes Authorization through untouched, so we validate here) ---
  AUTH_ISSUER: z.string().url(),
  AUTH_AUDIENCE: z.string().min(1),
  AUTH_JWKS_URI: z.string().url(),
  AUTH_ALLOWED_ALGS: csv.transform((a) => (a.length ? a : ["RS256", "ES256"])),
  AUTH_ROLES_CLAIM: z.string().default("groups"),
  AUTH_NAMESPACES_CLAIM: z.string().default("k8s_namespaces"),
  AUTH_PLATFORM_ROLE: z.string().default("platform-oncall"),
  AUTH_TENANT_ROLE: z.string().default("tenant-viewer"),
  AUTH_CLOCK_TOLERANCE_S: z.coerce.number().int().min(0).max(60).default(5),

  // --- Domain ---
  AUDIT_GUARD_NAMESPACE: z.string().default("audit-guard-system"),
  AUDIT_GUARD_DEPLOYMENT: z.string().default("audit-guard-webhook"),
  AUDIT_EXCEPTION_GROUP: z.string().default("governance.platform.example.com"),
  AUDIT_EXCEPTION_VERSION: z.string().default("v1alpha1"),
  AUDIT_EXCEPTION_PLURAL: z.string().default("auditexceptions"),
  CONFIGSYNC_GROUP: z.string().default("configsync.gke.io"),

  // --- Guard rails ---
  MAX_ITEMS: z.coerce.number().int().min(1).max(500).default(100),
  MAX_BODY_BYTES: z.coerce.number().int().default(64 * 1024),
  K8S_TIMEOUT_MS: z.coerce.number().int().default(5000),
  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().default(60_000),
  RATE_LIMIT_MAX: z.coerce.number().int().default(120),
  TRUST_PROXY_HOPS: z.coerce.number().int().default(1),
});

export type Config = z.infer<typeof schema>;

export function loadConfig(env: NodeJS.ProcessEnv = process.env): Config {
  const parsed = schema.safeParse(env);
  if (!parsed.success) {
    // Fail fast and loudly: a banking control must never start half-configured.
    const detail = parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
    throw new Error(`Invalid configuration: ${detail}`);
  }
  return parsed.data;
}
