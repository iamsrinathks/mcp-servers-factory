// LOCAL DEV ONLY: runs the real MCP server against canned cluster data (no cluster needed).
import { createAuthenticator } from "../src/auth.js";
import { loadConfig } from "../src/config.js";
import { createLogger } from "../src/logger.js";
import { createApp } from "../src/server.js";
import type { KubeReader } from "../src/kube.js";

const today = new Date().toISOString().slice(0, 10);
const ex = (ns: string, name: string, ruleId: string, validDate: string) => ({
  metadata: { name, namespace: ns },
  spec: { ruleId, validDate, jiraTicket: "SVC-10097", approvedBy: "platform-oncall@example.com", reason: "Sprint 42 remediation" },
});
const exceptions = [ex("team-a", "waiver-team-a-cis-4-4-1", "CIS-4.4.1", today), ex("team-a", "old-waiver", "CIS-4.4.1", "2026-09-20"), ex("team-b", "waiver-team-b", "CIS-4.1.5", today)];
const nf = () => Object.assign(new Error("not found"), { code: 404 });

const kube: KubeReader = {
  listCustom: async ({ namespace }) => exceptions.filter((e) => !namespace || e.metadata.namespace === namespace),
  getCustom: async ({ plural, namespace, name }) => {
    if (plural === "rootsyncs") return { status: { source: { commit: "a1b2c3" }, sync: { commit: "a1b2c3", lastUpdate: new Date().toISOString() } } };
    const e = exceptions.find((x) => x.metadata.name === name && x.metadata.namespace === namespace);
    if (!e) throw nf();
    return e;
  },
  listEvents: async ({ namespace }) =>
    namespace === "team-a"
      ? [{ type: "Warning", reason: "FailedCreate", message: "DENIED by Audit-Guard Webhook:\n- [CIS-4.4.1] Container 'app' uses secretKeyRef for env DATABASE_PASSWORD", lastTimestamp: new Date().toISOString(), involvedObject: { kind: "ReplicaSet", name: "payment-service-7d9f" } }]
      : [],
  getDeployment: async ({ namespace, name }) => {
    if (namespace === "audit-guard-system" && name === "audit-guard-webhook") return { spec: { replicas: 1 }, status: { readyReplicas: 1 } };
    throw nf();
  },
  listPods: async () => [],
};

const cfg = loadConfig();
const app = createApp({ cfg, log: createLogger(cfg.LOG_LEVEL), kube, auth: createAuthenticator(cfg) });
app.listen(cfg.PORT, "127.0.0.1", () => console.log(`dev mcp server (fixture data) on :${cfg.PORT}`));
