// LOCAL DEV ONLY: a tiny fake IdP. Serves a JWKS and mints tokens. Never deploy this.
import express from "express";
import { exportJWK, generateKeyPair, SignJWT } from "jose";

const PORT = Number(process.env.IDP_PORT ?? 4000);
const ISSUER = process.env.IDP_ISSUER ?? `http://localhost:${PORT}`;
const AUDIENCE = process.env.IDP_AUDIENCE ?? "mcp-gateway";

const { publicKey, privateKey } = await generateKeyPair("RS256");
const jwk = { ...(await exportJWK(publicKey)), kid: "dev", alg: "RS256", use: "sig" };

const app = express();
app.get("/jwks", (_q, r) => void r.json({ keys: [jwk] }));
// GET /token?role=platform-oncall            → platform on-call
// GET /token?role=tenant-viewer&ns=team-a    → tenant confined to team-a
app.get("/token", async (q, r) => {
  const role = String(q.query.role ?? "platform-oncall");
  const ns = String(q.query.ns ?? "").split(",").filter(Boolean);
  const token = await new SignJWT({ groups: [role], k8s_namespaces: ns })
    .setProtectedHeader({ alg: "RS256", kid: "dev" })
    .setSubject(String(q.query.sub ?? `dev-${role}@example.com`))
    .setIssuer(ISSUER).setAudience(AUDIENCE).setIssuedAt().setExpirationTime("1h").sign(privateKey);
  r.type("text/plain").send(token);
});
app.listen(PORT, "127.0.0.1", () => console.log(`dev-idp on ${ISSUER}  (issuer=${ISSUER} audience=${AUDIENCE})`));
