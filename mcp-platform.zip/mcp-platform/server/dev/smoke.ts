// Calls the stack THROUGH THE GATEWAY like a real MCP client.  npx tsx dev/smoke.ts
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

const GATEWAY = process.env.GATEWAY_URL ?? "http://127.0.0.1:3000";
const IDP = process.env.IDP_URL ?? "http://127.0.0.1:4000";

async function as(query: string) {
  const token = await (await fetch(`${IDP}/token?${query}`)).text();
  const c = new Client({ name: "smoke", version: "1.0.0" });
  await c.connect(new StreamableHTTPClientTransport(new URL(`${GATEWAY}/mcp/k8s-governance`), { requestInit: { headers: { Authorization: `Bearer ${token}` } } }));
  return c;
}
const show = (t: string, r: any) => console.log(`\n== ${t}\n${r.content[0].text}`);

const platform = await as("role=platform-oncall");
console.log("platform tools:", (await platform.listTools()).tools.map((t) => t.name).join(", "));
show("platform: audit-guard health", await platform.callTool({ name: "get_audit_guard_health", arguments: {} }));
show("platform: active waivers", await platform.callTool({ name: "list_audit_exceptions", arguments: { state: "active" } }));

const tenant = await as("role=tenant-viewer&ns=team-a");
console.log("\ntenant tools:", (await tenant.listTools()).tools.map((t) => t.name).join(", "));
show("tenant team-a: why was payment-service denied?", await tenant.callTool({ name: "explain_denial", arguments: { namespace: "team-a", workload: "payment-service" } }));
show("tenant asking for team-b (must be forbidden)", await tenant.callTool({ name: "list_audit_exceptions", arguments: { namespace: "team-b" } }));
await platform.close(); await tenant.close();
