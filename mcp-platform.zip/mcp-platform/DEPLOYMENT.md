# MCP platform: gateway + k8s-governance server

```
 MCP client (Claude Code / agent)
        │  HTTPS + Bearer JWT  (via internal LB, VPC-private)
        ▼
 ┌────────────────────────────  mcp-gateway  (×3, stateless)  ────────────────────────────┐
 │ request-id · pre-auth IP limit · JWT check (iss/aud/alg/exp) · per-server role check     │
 │ per-user rate limit · circuit breaker · header allow-list · SSE passthrough · access log │
 └──────────────────────────────────────────┬───────────────────────────────────────────────┘
                                            │  HTTPS (internal CA), same token forwarded
                                            ▼
 ┌─────────────────────  k8s-governance-mcp  (×3, stateless)  ─────────────────────┐
 │ re-validates JWT · namespace authz · read-only tools · redaction · audit log      │
 └───────────────────────────────────────────┬──────────────────────────────────────┘
                                             ▼  get/list only, no Secrets
                                     Kubernetes API (shared GKE)
```

The gateway authenticates at the edge **and** the server re-validates the same token, so neither is a single point of trust.
Both are stateless (no session table), which is what lets you run several replicas without sticky sessions.

## Where should I deploy it?

**Start on localhost. Move to a sandbox cluster next. Production only after that.** Three stages, each proving something different:

| Stage | Where | What it proves | Touches real cluster? |
|---|---|---|---|
| 0 | Your laptop, `make dev-up` | Protocol, auth, routing, tools work end to end | No (fixture data) |
| 1 | kind/minikube or a GKE **sandbox** cluster | Real RBAC, real Audit-Guard/Config Sync objects, TLS, NetworkPolicy | Sandbox only |
| 2 | The shared multi-tenant GKE cluster | Production | Yes |

**In-cluster or not?** The MCP *server* must live where it can reach the Kubernetes API, so it goes in-cluster (a platform-owned namespace, own ServiceAccount, read-only ClusterRole). The *gateway* can start in the **same cluster** in its own namespace (`mcp-gateway`) exposed on an **internal** load balancer only. That is the simplest thing that works and is fine for the first rollout.

Know the trade-off: if the shared cluster is degraded, the tool you'd use to diagnose it is degraded too. Once more MCP servers exist, move the gateway to a small management cluster or a separate platform project so it doesn't share fate with the tenants' cluster. The config doesn't change; only the backend URLs do.

Do not point localhost at the production cluster with an admin kubeconfig. If you want localhost against a real cluster, use a kubeconfig for the read-only ServiceAccount from `server/deploy/01-rbac.yaml`.

---

## Stage 0: localhost (about 5 minutes)

Needs Node 22+. No Docker, no cluster.

```bash
cd mcp-platform
make install
make dev-up      # fake IdP :4000, MCP server :8080 (fixtures), gateway :3000
make smoke       # MCP client → gateway → server, as platform on-call and as a tenant
make dev-down
```

`make smoke` should show: platform sees 7 tools, tenant sees 6 (no `get_audit_guard_health`), and a tenant asking for another team's namespace gets `forbidden`.

Use it from Claude Code:

```bash
claude mcp add --transport http k8s-governance \
  http://127.0.0.1:3000/mcp/k8s-governance \
  --header "Authorization: Bearer $(curl -s 'localhost:4000/token?role=platform-oncall')"
```

Dev tokens last 1 hour. The fake IdP (`server/dev/idp.ts`) is for loopback only; never deploy it.

## Stage 1: sandbox cluster

Prereqs: `kubectl` pointed at the **sandbox**, [cert-manager](https://cert-manager.io) installed, a registry you can push to, and your IdP details (issuer, audience, JWKS URL, and the claim carrying groups/roles).

```bash
# 1. Build and push (pin by digest afterwards)
docker build -t REGISTRY/k8s-governance-mcp:0.1.0 server  && docker push REGISTRY/k8s-governance-mcp:0.1.0
docker build -t REGISTRY/mcp-gateway:0.1.0        gateway && docker push REGISTRY/mcp-gateway:0.1.0

# 2. Edit the TODOs: image names, AUTH_* values (server/deploy/02-deployment.yaml, gateway/deploy/01-gateway.yaml),
#    namespace names in server/deploy/03-networkpolicy.yaml.
#    The token audience must be the same in both (they share one token).

# 3. MCP server (needs your CRDs: AuditException, Config Sync)
kubectl apply -f server/deploy/00-namespace.yaml -f server/deploy/01-rbac.yaml
kubectl apply -f server/deploy/04-certificate.yaml           # cert-manager CA + server cert
kubectl apply -f server/deploy/02-deployment.yaml -f server/deploy/03-networkpolicy.yaml
kubectl -n mcp-k8s-governance rollout status deploy/k8s-governance-mcp

# 4. Trust the internal CA in the gateway, and load its config
kubectl apply -f gateway/deploy/00-namespace.yaml
kubectl -n mcp-k8s-governance get secret mcp-internal-ca -o jsonpath='{.data.ca\.crt}' | base64 -d > /tmp/ca.crt
kubectl -n mcp-gateway create configmap mcp-internal-ca --from-file=ca.crt=/tmp/ca.crt
kubectl -n mcp-gateway create configmap mcp-gateway-config --from-file=gateway.yaml=gateway/config/gateway.yaml

# 5. Gateway
kubectl apply -f gateway/deploy/01-gateway.yaml
kubectl -n mcp-gateway rollout status deploy/mcp-gateway

# 6. Test without exposing anything
kubectl -n mcp-gateway port-forward svc/mcp-gateway 3000:80 &
curl -i localhost:3000/healthz                          # 200
curl -i -X POST localhost:3000/mcp/k8s-governance       # 401 (no token)
# then connect a client with a real token from your IdP
```

The gateway `Service` is `type: LoadBalancer` with the GKE **Internal** annotation: it gets a private VPC address only. Put TLS in front of it (internal HTTPS load balancer or Gateway API with a managed certificate) before real users send tokens.

If something fails: `kubectl logs` on either deployment. The gateway logs `auth_rejected`, `upstream_error` (with `kind`: connect, timeout, redirect) and one `access` line per request; the server logs one `audit` line per tool call. Correlate with `requestId`.

## Stage 2: production checklist

- [ ] IdP: real issuer/audience/JWKS; confirm the roles claim name; groups mapped to `platform-oncall` / `tenant-viewer`; tenant tokens carry `k8s_namespaces`.
- [ ] Internal HTTPS load balancer with a managed cert; no public IP; source ranges limited to corporate/VPN. Update the gateway NetworkPolicy ingress to those ranges.
- [ ] Images: built in CI, scanned, signed, **pinned by digest**, admitted only via Binary Authorization.
- [ ] Logs: ship both services' JSON logs to a locked, retention-controlled bucket (the server's `audit` lines are your evidence trail).
- [ ] Alerts on: `gateway_auth_failures_total` spike, `gateway_circuit_open_total` > 0, `gateway_upstream_errors_total`, 5xx rate, `mcp_tool_calls_total{outcome="internal"}`, single-replica Audit-Guard.
- [ ] Pen-test / security review, including the RBAC (no Secrets, no logs, no writes) and the tenant-isolation tests.
- [ ] Runbook: how to disable a backend (remove it from `gateway.yaml`, roll the gateway) and how to rotate the internal CA.
- [ ] Canary: platform team only for 2 weeks before opening `tenant-viewer`.

## Operating notes

**Add another MCP server to the gateway:** add an entry under `servers:` (unique `id`, `https://` url, `allowed_roles`), update the ConfigMap, `kubectl rollout restart deploy/mcp-gateway`. Clients reach it at `/mcp/<id>`. Add its namespace to the gateway egress NetworkPolicy.

**Rollback:** `kubectl rollout undo` on either deployment; both are stateless.

**Rate limits:** the gateway limits per user per server (and per IP before auth). Counters are per replica, so effective limits scale with replica count. If you need exact fleet-wide limits, add a shared store (Redis) later.

## What was built, and what was left out on purpose

| Practice | How |
|---|---|
| One endpoint per backend | `/mcp/:serverId`, config-validated ids |
| Edge auth + backend re-auth | JWT (JWKS, iss/aud/alg allow-list) at both hops; token forwarded unmodified |
| Least exposure | `allowed_roles` per server; unknown vs forbidden both return 404 |
| Request hygiene | Header allow-lists both directions; no cookies, no host forwarding; body-size cap; method allow-list |
| SSRF resistance | Backends only from config; redirects never followed; https required unless explicitly allowed |
| Resilience | Circuit breaker per backend, connect/header/idle timeouts, client-abort propagation, graceful drain |
| Abuse control | Pre-auth IP limit, per-user per-server limit, `Retry-After` |
| Observability | Request-id propagation, access log (no tokens/bodies), Prometheus on a private port |
| TLS | Custom CA is added to trust; verification is never disabled; `allow_insecure_backends` refused in prod unless set |
| Fail fast | Config validation at startup; undefined `${ENV}` aborts; edge auth cannot be disabled when `NODE_ENV=production` |

Left out deliberately: the reference gateway's **REST-to-MCP (OpenAPI) transport** (not needed for this backend, adds attack surface) and **in-memory session tracking** (breaks with multiple replicas; `Mcp-Session-Id` is passed through instead, and the server is stateless anyway).
