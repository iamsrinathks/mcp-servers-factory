import { afterEach, describe, expect, it } from "vitest";
import { parseConfig } from "../src/config.js";
import { post, startGateway, startUpstream, type Upstream } from "./helpers.js";

const cleanups: (() => Promise<unknown>)[] = [];
afterEach(async () => { while (cleanups.length) await cleanups.pop()!(); });
async function setup(up?: Upstream["handler"], extra = "", opts: Parameters<typeof startGateway>[2] = {}) {
  const upstream = await startUpstream(up);
  const gw = await startGateway(upstream.url, extra, opts);
  cleanups.push(gw.close, upstream.close);
  return { upstream, gw };
}

describe("config validation (fail fast)", () => {
  const base = `gateway:\n  auth: { issuer: "https://i.example.com", audiences: [a], jwks_uri: "https://i.example.com/j" }\n`;
  it("rejects plaintext backends unless explicitly allowed", () => {
    expect(() => parseConfig(base + "servers:\n  - { id: a, url: http://x/mcp }", {})).toThrow(/https/);
  });
  it("rejects duplicate ids and bad ids", () => {
    expect(() => parseConfig(base + "servers:\n  - { id: a, url: https://x }\n  - { id: a, url: https://y }", {})).toThrow(/duplicate/);
    expect(() => parseConfig(base + "servers:\n  - { id: ../etc, url: https://x }", {})).toThrow();
  });
  it("fails on undefined env vars rather than silently blanking", () => {
    expect(() => parseConfig(base + "servers:\n  - { id: a, url: '${NOPE}' }", {})).toThrow(/NOPE/);
  });
  it("cannot disable auth in production", () => {
    const prev = process.env.NODE_ENV;
    process.env.NODE_ENV = "production";
    try {
      expect(() => parseConfig(base.replace("auth: {", "auth: { enabled: false,") + "servers:\n  - { id: a, url: https://x }", {})).toThrow(/production/);
    } finally { process.env.NODE_ENV = prev; }
  });
});

describe("routing and edge auth", () => {
  it("401 without token, and the backend is never called", async () => {
    const { gw, upstream } = await setup();
    const r = await post(`${gw.url}/mcp/k8s`);
    expect(r.status).toBe(401);
    expect(r.headers.get("www-authenticate")).toContain("Bearer");
    expect(upstream.hits).toHaveLength(0);
  });
  it("rejects a token with the wrong audience", async () => {
    const { gw, upstream } = await setup();
    expect((await post(`${gw.url}/mcp/k8s`, await gw.sign({}, { aud: "other" }))).status).toBe(401);
    expect(upstream.hits).toHaveLength(0);
  });
  it("404 for unknown server, 405 for other methods", async () => {
    const { gw } = await setup();
    const t = await gw.sign();
    expect((await post(`${gw.url}/mcp/nope`, t)).status).toBe(404);
    expect((await fetch(`${gw.url}/mcp/k8s`, { method: "PUT", headers: { authorization: `Bearer ${t}` } })).status).toBe(405);
  });
  it("forwards the token untouched plus MCP headers, and drops everything else", async () => {
    const { gw, upstream } = await setup();
    const t = await gw.sign();
    const r = await post(`${gw.url}/mcp/k8s`, t, undefined, { "mcp-session-id": "abc", cookie: "a=b", "x-evil": "1", "x-request-id": "req-1", accept: "application/json, text/event-stream" });
    expect(r.status).toBe(200);
    expect(await r.json()).toMatchObject({ result: { ok: true } });
    const h = upstream.hits[0]!.headers;
    expect(h.authorization).toBe(`Bearer ${t}`);
    expect(h["mcp-session-id"]).toBe("abc");
    expect(h["x-request-id"]).toBe("req-1");
    expect(h.cookie).toBeUndefined();
    expect(h["x-evil"]).toBeUndefined();
    expect(upstream.hits[0]!.body).toContain("tools/list");
    // response side: session id passes through, cookies do not
    expect(r.headers.get("mcp-session-id")).toBe("sess-123");
    expect(r.headers.get("set-cookie")).toBeNull();
  });
  it("hides servers the caller's roles do not permit (same 404 as unknown)", async () => {
    const { gw } = await setup(undefined, "", { serverExtra: "    allowed_roles: [platform-oncall]" });
    expect((await post(`${gw.url}/mcp/k8s`, await gw.sign({ groups: ["tenant-viewer"] }))).status).toBe(404);
    expect((await post(`${gw.url}/mcp/k8s`, await gw.sign({ groups: ["platform-oncall"] }))).status).toBe(200);
    const list = await fetch(`${gw.url}/servers`, { headers: { authorization: `Bearer ${await gw.sign({ groups: ["tenant-viewer"] })}` } });
    expect((await list.json()).servers).toEqual([]);
  });
});

describe("protection", () => {
  it("rate limits per user+server with Retry-After", async () => {
    const { gw } = await setup(undefined, "  rate_limit: { window_ms: 60000, max_requests: 2 }");
    const t = await gw.sign();
    await post(`${gw.url}/mcp/k8s`, t);
    await post(`${gw.url}/mcp/k8s`, t);
    const r = await post(`${gw.url}/mcp/k8s`, t);
    expect(r.status).toBe(429);
    expect(Number(r.headers.get("retry-after"))).toBeGreaterThan(0);
  });
  it("rejects oversize bodies", async () => {
    const { gw } = await setup(undefined, "  max_body_bytes: 200");
    expect((await post(`${gw.url}/mcp/k8s`, await gw.sign(), { pad: "x".repeat(1000) })).status).toBe(413);
  });
  it("never follows redirects from a backend", async () => {
    const { gw } = await setup((_q, res) => { res.statusCode = 302; res.setHeader("location", "http://169.254.169.254/"); res.end(); });
    expect((await post(`${gw.url}/mcp/k8s`, await gw.sign())).status).toBe(502);
  });
  it("returns 502 when the backend is down", async () => {
    const { gw, upstream } = await setup();
    await upstream.close();
    cleanups.length = 0; cleanups.push(gw.close);
    expect((await post(`${gw.url}/mcp/k8s`, await gw.sign())).status).toBe(502);
  });
  it("opens the circuit after repeated failures, then recovers after the reset window", async () => {
    let clock = 1_000_000;
    let healthy = false;
    const { gw, upstream } = await setup((_q, res) => { res.statusCode = healthy ? 200 : 503; res.end("{}"); }, "  breaker: { failure_threshold: 3, reset_ms: 10000 }\n  rate_limit: { max_requests: 0 }", { now: () => clock });
    const t = await gw.sign();
    for (let i = 0; i < 3; i++) expect((await post(`${gw.url}/mcp/k8s`, t)).status).toBe(503);
    expect(upstream.hits).toHaveLength(3);
    const open = await post(`${gw.url}/mcp/k8s`, t);
    expect(open.status).toBe(503);
    expect(Number(open.headers.get("retry-after"))).toBeGreaterThan(0);
    expect(upstream.hits).toHaveLength(3); // fast-fail: backend not touched
    clock += 11_000; healthy = true;
    expect((await post(`${gw.url}/mcp/k8s`, t)).status).toBe(200); // half-open probe succeeds
    expect(gw.breakers.get("k8s")!.isOpen).toBe(false);
  });
});

describe("streaming and logging", () => {
  it("streams SSE through without buffering", async () => {
    const { gw } = await setup((_q, res) => {
      res.writeHead(200, { "content-type": "text/event-stream" });
      res.write("data: first\n\n");
      setTimeout(() => { res.write("data: second\n\n"); res.end(); }, 400);
    });
    const t0 = Date.now();
    const r = await fetch(`${gw.url}/mcp/k8s`, { headers: { authorization: `Bearer ${await gw.sign()}`, accept: "text/event-stream" } });
    const reader = r.body!.getReader();
    const first = new TextDecoder().decode((await reader.read()).value);
    expect(first).toContain("first");
    expect(Date.now() - t0).toBeLessThan(350); // arrived before upstream finished
    await reader.cancel();
  });
  it("logs access records but never tokens", async () => {
    const { gw } = await setup();
    const t = await gw.sign();
    await post(`${gw.url}/mcp/k8s`, t);
    const joined = gw.lines.join("\n");
    expect(joined).not.toContain(t);
    expect(JSON.parse(gw.lines.find((l) => l.includes('"access"'))!)).toMatchObject({ server: "k8s", status: 200, sub: "alice" });
  });
});
