import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import type { AddressInfo } from "node:net";
import { createLocalJWKSet, exportJWK, generateKeyPair, SignJWT, type JWK } from "jose";
import { Agent } from "undici";
import { createAuthenticator } from "../src/auth.js";
import { parseConfig } from "../src/config.js";
import { createLogger } from "../src/logger.js";
import { createApp } from "../src/server.js";

export const ISSUER = "https://idp.example.com";
export const AUD = "mcp-gateway";

export async function makeKeys() {
  const { publicKey, privateKey } = await generateKeyPair("RS256");
  const jwk: JWK = { ...(await exportJWK(publicKey)), kid: "k1", alg: "RS256", use: "sig" };
  return {
    resolver: createLocalJWKSet({ keys: [jwk] }),
    sign: (claims: Record<string, unknown> = {}, o: { aud?: string } = {}) =>
      new SignJWT(claims).setProtectedHeader({ alg: "RS256", kid: "k1" }).setSubject("alice").setIssuer(ISSUER).setAudience(o.aud ?? AUD).setIssuedAt().setExpirationTime("5m").sign(privateKey),
  };
}

export interface Upstream {
  url: string;
  hits: { method?: string; headers: IncomingMessage["headers"]; body: string }[];
  handler: (req: IncomingMessage, res: ServerResponse) => void;
  close: () => Promise<void>;
}

export async function startUpstream(handler?: Upstream["handler"]): Promise<Upstream> {
  const hits: Upstream["hits"] = [];
  const u: Upstream = {
    url: "",
    hits,
    handler:
      handler ??
      ((_req, res) => {
        res.setHeader("content-type", "application/json");
        res.setHeader("mcp-session-id", "sess-123");
        res.setHeader("set-cookie", "leak=1"); // must NOT be forwarded to the client
        res.end(JSON.stringify({ jsonrpc: "2.0", id: 1, result: { ok: true } }));
      }),
    close: () => new Promise((r) => srv.close(() => r())),
  };
  const srv: Server = createServer((req, res) => {
    const chunks: Buffer[] = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => {
      hits.push({ method: req.method, headers: req.headers, body: Buffer.concat(chunks).toString() });
      u.handler(req, res);
    });
  });
  await new Promise<void>((r) => srv.listen(0, "127.0.0.1", r));
  u.url = `http://127.0.0.1:${(srv.address() as AddressInfo).port}/mcp`;
  return u;
}

export async function startGateway(upstreamUrl: string, extraYaml = "", opts: { now?: () => number; serverExtra?: string } = {}) {
  const config = parseConfig(
    `
gateway:
  allow_insecure_backends: true
  trust_proxy_hops: 0
  auth:
    issuer: ${ISSUER}
    audiences: [${AUD}]
    jwks_uri: https://idp.example.com/jwks
    roles_claim: groups
${extraYaml}
servers:
  - id: k8s
    url: ${upstreamUrl}
${opts.serverExtra ?? ""}
`,
    {},
  );
  const keys = await makeKeys();
  const lines: string[] = [];
  const dispatcher = new Agent();
  const { app, breakers } = createApp({
    config,
    auth: createAuthenticator(config.gateway.auth, keys.resolver),
    dispatcher,
    log: createLogger("debug", (l) => lines.push(l)),
    now: opts.now,
  });
  const server = app.listen(0, "127.0.0.1");
  await new Promise((r) => server.once("listening", r));
  const url = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  return { url, sign: keys.sign, lines, breakers, close: async () => { server.closeAllConnections(); await new Promise((r) => server.close(r)); await dispatcher.close(); } };
}

export const post = (url: string, token?: string, body: unknown = { jsonrpc: "2.0", id: 1, method: "tools/list" }, headers: Record<string, string> = {}) =>
  fetch(url, { method: "POST", body: JSON.stringify(body), headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers } });
