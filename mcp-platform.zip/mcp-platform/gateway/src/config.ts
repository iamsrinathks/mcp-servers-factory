import { readFileSync } from "node:fs";
import { parse } from "yaml";
import { z } from "zod";

const rateLimit = z.object({
  window_ms: z.number().int().positive().default(60_000),
  max_requests: z.number().int().min(0).default(100), // 0 = unlimited (per-server only)
});

const schema = z
  .object({
    gateway: z
      .object({
        port: z.number().int().default(3000),
        host: z.string().default("0.0.0.0"),
        metrics_port: z.number().int().default(9091),
        log_level: z.enum(["debug", "info", "warn", "error"]).default("info"),
        timeout_ms: z.number().int().positive().default(30_000),
        stream_idle_timeout_ms: z.number().int().positive().default(300_000),
        max_body_bytes: z.number().int().positive().default(1024 * 1024),
        trust_proxy_hops: z.number().int().min(0).default(1),
        /** true only for localhost/dev or when a mesh provides mTLS. */
        allow_insecure_backends: z.boolean().default(false),
        tls: z.object({ ca_path: z.string() }).optional(),
        ip_rate_limit: rateLimit.default({ window_ms: 60_000, max_requests: 600 }),
        rate_limit: rateLimit.default({ window_ms: 60_000, max_requests: 100 }),
        breaker: z
          .object({
            failure_threshold: z.number().int().positive().default(5),
            reset_ms: z.number().int().positive().default(30_000),
          })
          .default({ failure_threshold: 5, reset_ms: 30_000 }),
        auth: z.object({
          enabled: z.boolean().default(true),
          issuer: z.string().url(),
          audiences: z.array(z.string()).min(1),
          jwks_uri: z.string().url(),
          algorithms: z.array(z.string()).default(["RS256", "ES256"]),
          roles_claim: z.string().default("groups"),
          clock_tolerance_s: z.number().int().min(0).max(60).default(5),
        }),
      })
      .default({} as never),
    servers: z
      .array(
        z.object({
          id: z.string().regex(/^[a-z0-9][a-z0-9-]{0,62}$/, "lowercase letters, digits, hyphens"),
          type: z.literal("remote").default("remote"),
          url: z.string().url(),
          timeout_ms: z.number().int().positive().optional(),
          /** Token must carry at least one of these roles/groups to reach this server. */
          allowed_roles: z.array(z.string()).default([]),
          rate_limit: rateLimit.optional(),
        }),
      )
      .min(1),
  })
  .superRefine((c, ctx) => {
    const seen = new Set<string>();
    c.servers.forEach((s, i) => {
      if (seen.has(s.id)) ctx.addIssue({ code: "custom", path: ["servers", i, "id"], message: `duplicate id '${s.id}'` });
      seen.add(s.id);
      if (!c.gateway.allow_insecure_backends && !s.url.startsWith("https://"))
        ctx.addIssue({
          code: "custom",
          path: ["servers", i, "url"],
          message: "backend must be https:// (set gateway.allow_insecure_backends only for local dev / mesh mTLS)",
        });
    });
    if (!c.gateway.auth.enabled && process.env.NODE_ENV === "production")
      ctx.addIssue({ code: "custom", path: ["gateway", "auth", "enabled"], message: "edge auth cannot be disabled in production" });
  });

export type GatewayConfig = z.infer<typeof schema>;
export type ServerConfig = GatewayConfig["servers"][number];

/** ${VAR} interpolation so secrets/URLs come from the environment, not the file. */
export function interpolate(raw: string, env: NodeJS.ProcessEnv): string {
  return raw.replace(/\$\{([A-Z0-9_]+)\}/g, (_m, name: string) => {
    const v = env[name];
    if (v === undefined) throw new Error(`Config references undefined environment variable ${name}`);
    return v;
  });
}

export function parseConfig(raw: string, env: NodeJS.ProcessEnv = process.env): GatewayConfig {
  const parsed = schema.safeParse(parse(interpolate(raw, env)));
  if (!parsed.success) {
    const detail = parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
    throw new Error(`Invalid gateway configuration: ${detail}`); // fail fast
  }
  return parsed.data;
}

export const loadConfig = (path = process.env.GATEWAY_CONFIG ?? "config/gateway.yaml") =>
  parseConfig(readFileSync(path, "utf8"));
