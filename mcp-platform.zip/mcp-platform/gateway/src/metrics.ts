type Labels = Record<string, string>;
const key = (l: Labels) => JSON.stringify(Object.entries(l).sort());
const fmt = (l: Labels) => {
  const p = Object.entries(l).map(([k, v]) => `${k}="${v.replace(/["\\\n]/g, "_")}"`);
  return p.length ? `{${p.join(",")}}` : "";
};

class Counter {
  private v = new Map<string, { l: Labels; n: number }>();
  constructor(readonly name: string, readonly help: string) {}
  inc(l: Labels = {}) {
    const k = key(l);
    const e = this.v.get(k) ?? { l, n: 0 };
    e.n += 1;
    this.v.set(k, e);
  }
  render() {
    return [`# HELP ${this.name} ${this.help}`, `# TYPE ${this.name} counter`, ...[...this.v.values()].map((e) => `${this.name}${fmt(e.l)} ${e.n}`)].join("\n");
  }
}
class Summary {
  private v = new Map<string, { l: Labels; sum: number; count: number }>();
  constructor(readonly name: string, readonly help: string) {}
  observe(l: Labels, x: number) {
    const k = key(l);
    const e = this.v.get(k) ?? { l, sum: 0, count: 0 };
    e.sum += x;
    e.count += 1;
    this.v.set(k, e);
  }
  render() {
    return [`# HELP ${this.name} ${this.help}`, `# TYPE ${this.name} summary`, ...[...this.v.values()].flatMap((e) => [`${this.name}_sum${fmt(e.l)} ${e.sum}`, `${this.name}_count${fmt(e.l)} ${e.count}`])].join("\n");
  }
}

export const requests = new Counter("gateway_requests_total", "Requests by server, method and status class");
export const duration = new Summary("gateway_request_duration_seconds", "End-to-end latency by server");
export const authFailures = new Counter("gateway_auth_failures_total", "Edge auth rejections by status");
export const rateLimited = new Counter("gateway_rate_limited_total", "Requests rejected by a rate limiter, by scope");
export const breakerRejects = new Counter("gateway_circuit_open_total", "Requests rejected by an open circuit, by server");
export const upstreamErrors = new Counter("gateway_upstream_errors_total", "Upstream transport failures by server and kind");

export const renderMetrics = () =>
  [requests, duration, authFailures, rateLimited, breakerRejects, upstreamErrors].map((m) => m.render()).join("\n") + "\n";
