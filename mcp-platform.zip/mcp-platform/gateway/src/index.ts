import { readFileSync } from "node:fs";
import { Agent } from "undici";
import { createAuthenticator } from "./auth.js";
import { loadConfig } from "./config.js";
import { createLogger } from "./logger.js";
import { createApp, createMetricsApp } from "./server.js";

const config = loadConfig();
const gw = config.gateway;
const log = createLogger(gw.log_level);

// Custom CA is *added* for outbound TLS; certificate verification is never disabled.
const dispatcher = new Agent({
  connect: { timeout: 5_000, ...(gw.tls ? { ca: readFileSync(gw.tls.ca_path) } : {}) },
  headersTimeout: gw.timeout_ms,
  bodyTimeout: gw.stream_idle_timeout_ms, // idle timeout for long-lived SSE streams
  keepAliveTimeout: 30_000,
});

if (!gw.auth.enabled) log.warn("EDGE AUTH DISABLED — development only");
const { app } = createApp({ config, auth: gw.auth.enabled ? createAuthenticator(gw.auth) : null, dispatcher, log });

const main = app.listen(gw.port, gw.host, () => log.info("listening", { port: gw.port, servers: config.servers.map((s) => s.id) }));
const metrics = createMetricsApp().listen(gw.metrics_port, gw.host);
main.requestTimeout = 0; // SSE streams are long-lived; upstream idle timeout governs instead
main.headersTimeout = 10_000;
main.keepAliveTimeout = 65_000;

let closing = false;
function shutdown(signal: string) {
  if (closing) return;
  closing = true;
  log.info("shutdown_start", { signal });
  main.close(() => {
    metrics.close();
    void dispatcher.close().finally(() => {
      log.info("shutdown_complete");
      process.exit(0);
    });
  });
  main.closeIdleConnections();
  setTimeout(() => process.exit(1), 25_000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("unhandledRejection", (e) => log.error("unhandled_rejection", { err: String(e) }));
process.on("uncaughtException", (e) => {
  log.error("uncaught_exception", { err: String(e) });
  shutdown("uncaughtException");
});
