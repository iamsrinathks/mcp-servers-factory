import { createRemoteJWKSet, jwtVerify, type JWTVerifyGetKey } from "jose";
import type { GatewayConfig } from "./config.js";

export interface Principal {
  subject: string;
  roles: string[];
}

export class AuthError extends Error {
  constructor(message: string, readonly status: 401 | 403 = 401) {
    super(message);
  }
}

export interface Authenticator {
  authenticate(header: string | undefined): Promise<Principal>;
}

/**
 * Edge authentication. The token is still forwarded untouched so each backend
 * re-validates it (defence in depth): a compromised or misrouted gateway cannot
 * mint trust, and backends stay safe if they are ever reached another way.
 */
export function createAuthenticator(cfg: GatewayConfig["gateway"]["auth"], keys?: JWTVerifyGetKey): Authenticator {
  const getKey = keys ?? createRemoteJWKSet(new URL(cfg.jwks_uri), { cooldownDuration: 30_000, timeoutDuration: 3_000 });
  return {
    async authenticate(header) {
      const m = /^Bearer\s+(\S+)$/i.exec(header ?? "");
      if (!m?.[1]) throw new AuthError("Missing bearer token");
      try {
        const { payload } = await jwtVerify(m[1], getKey, {
          issuer: cfg.issuer,
          audience: cfg.audiences,
          algorithms: cfg.algorithms,
          clockTolerance: cfg.clock_tolerance_s,
          requiredClaims: ["sub", "exp", "iat"],
        });
        const raw = payload[cfg.roles_claim];
        return {
          subject: String(payload.sub),
          roles: Array.isArray(raw) ? raw.filter((r): r is string => typeof r === "string") : [],
        };
      } catch {
        throw new AuthError("Invalid token"); // opaque on purpose
      }
    },
  };
}
