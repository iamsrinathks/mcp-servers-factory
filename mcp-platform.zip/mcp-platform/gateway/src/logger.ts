type Level = "debug" | "info" | "warn" | "error";
const order: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };

// Defence in depth: even though this server never reads Secrets, anything that looks
// like a credential is scrubbed before it reaches logs or tool output.
const PATTERNS: [RegExp, string][] = [
  [/Bearer\s+[A-Za-z0-9\-._~+/]+=*/gi, "Bearer [REDACTED]"],
  [/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}/g, "[REDACTED_JWT]"],
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g, "[REDACTED_KEY]"],
  [/(password|passwd|secret|token|api[_-]?key)(["'\s:=]+)([^\s"',;}]{4,})/gi, "$1$2[REDACTED]"],
  [/AKIA[0-9A-Z]{16}/g, "[REDACTED_AWS_KEY]"],
];

export function redact(input: string): string {
  return PATTERNS.reduce((acc, [re, rep]) => acc.replace(re, rep), input);
}

export function redactDeep<T>(value: T): T {
  if (typeof value === "string") return redact(value) as T;
  if (Array.isArray(value)) return value.map(redactDeep) as T;
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([k, v]) => [k, redactDeep(v)]),
    ) as T;
  }
  return value;
}

export interface Logger {
  debug(msg: string, f?: Record<string, unknown>): void;
  info(msg: string, f?: Record<string, unknown>): void;
  warn(msg: string, f?: Record<string, unknown>): void;
  error(msg: string, f?: Record<string, unknown>): void;
  child(f: Record<string, unknown>): Logger;
}

export function createLogger(
  level: Level = "info",
  sink: (line: string) => void = (l) => process.stdout.write(l + "\n"),
  base: Record<string, unknown> = {},
): Logger {
  const emit = (lvl: Level, msg: string, fields: Record<string, unknown> = {}) => {
    if (order[lvl] < order[level]) return;
    sink(
      JSON.stringify(
        redactDeep({ ts: new Date().toISOString(), level: lvl, msg, ...base, ...fields }),
      ),
    );
  };
  return {
    debug: (m, f) => emit("debug", m, f),
    info: (m, f) => emit("info", m, f),
    warn: (m, f) => emit("warn", m, f),
    error: (m, f) => emit("error", m, f),
    child: (f) => createLogger(level, sink, { ...base, ...f }),
  };
}
