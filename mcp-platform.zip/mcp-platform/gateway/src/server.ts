import { randomUUID } from "node:crypto";
import express, { type NextFunction, type Request, type Response } from "express";
import { AuthError, type Authenticator, type Principal } from "./auth.js";
import { CircuitBreaker } from "./breaker.js";
import type { GatewayConfig } from "./config.js";
import type { Logger } from "./logger.js";
import { authFailures, duration, rateLimited, renderMetrics, requests } from "./metrics.js";
import { proxy } from "./proxy.js";
import { RateLimiter } from "./ratelimit.js";
import type { Dispatcher } from "undici";

export interface GatewayDeps {
  config: GatewayConfig;
  auth: Authenticator | null;
  dispatcher: Dispatcher;
  log: Logger;
  now?: () => number;
}

export function createApp(deps: GatewayDeps) {
  const { config, auth, dispatcher, log } = deps;
  const gw = config.gateway;
  const servers = new Map(config.servers.map((s) => [s.id, s]));
  const breakers = new Map([...servers.keys()].map((id) => [id, new CircuitBreaker(gw.breaker.failure_threshold, gw.breaker.reset_ms, deps.now)]));
  const ipLimiter = new RateLimiter(gw.ip_rate_limit.window_ms, gw.ip_rate_limit.max_requests, deps.now);
  const serverLimiters = new Map(
    config.servers.map((s) => {
      const rl = s.rate_limit ?? gw.rate_limit;
      return [s.id, rl.max_requests === 0 ? null : new RateLimiter(rl.window_ms, rl.max_requests, deps.now)] as const;
    }),
  );

  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", gw.trust_proxy_hops);

  app.use((req, res, next) => {
    const id = (req.header("x-request-id") ?? "").slice(0, 64).replace(/[^\w-]/g, "") || randomUUID();
    res.locals.requestId = id;
    res.setHeader("X-Request-Id", id);
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Strict-Transport-Security", "max-age=63072000; includeSubDomains");
    res.setHeader("Cache-Control", "no-store");
    next();
  });

  app.get("/healthz", (_req, res) => void res.json({ status: "ok" }));
  app.get("/readyz", (_req, res) => void res.json({ status: "ready", servers: servers.size }));

  const guard = async (req: Request, res: Response): Promise<Principal | null> => {
    const wait = ipLimiter.check(req.ip ?? "unknown"); // cheap pre-auth cap protects JWT verification
    if (wait > 0) {
      rateLimited.inc({ scope: "ip" });
      res.setHeader("Retry-After", String(wait));
      res.status(429).json({ error: "Rate limit exceeded" });
      return null;
    }
    if (!auth) return { subject: `ip:${req.ip}`, roles: [] };
    try {
      return await auth.authenticate(req.header("authorization"));
    } catch (err) {
      const status = err instanceof AuthError ? err.status : 401;
      authFailures.inc({ status: String(status) });
      log.warn("auth_rejected", { requestId: res.locals.requestId, status, ip: req.ip, path: req.path });
      res.setHeader("WWW-Authenticate", 'Bearer realm="mcp-gateway"');
      res.status(status).json({ error: status === 401 ? "Unauthorized" : "Forbidden" });
      return null;
    }
  };

  app.get("/servers", async (req, res) => {
    const p = await guard(req, res);
    if (!p) return;
    res.json({ servers: [...servers.values()].filter((s) => !s.allowed_roles.length || s.allowed_roles.some((r) => p.roles.includes(r))).map((s) => ({ id: s.id, type: s.type })) });
  });

  app.all("/mcp/:serverId", express.raw({ type: () => true, limit: gw.max_body_bytes }), async (req, res) => {
    const started = process.hrtime.bigint();
    const serverId = String(req.params.serverId);
    let status = 500;
    let subject = "-";
    try {
      const server = servers.get(serverId);
      if (!["POST", "GET", "DELETE"].includes(req.method)) {
        res.setHeader("Allow", "POST, GET, DELETE");
        return void res.status((status = 405)).json({ error: "Method not allowed" });
      }
      const principal = await guard(req, res);
      if (!principal) return void (status = res.statusCode);
      subject = principal.subject;

      // Same response for "unknown" and "not permitted": don't reveal which backends exist.
      if (!server || (server.allowed_roles.length && !server.allowed_roles.some((r) => principal.roles.includes(r)))) {
        return void res.status((status = 404)).json({ error: "Server not found" });
      }
      const limiter = serverLimiters.get(serverId);
      const wait = limiter?.check(`${principal.subject}:${serverId}`) ?? 0;
      if (wait > 0) {
        rateLimited.inc({ scope: "server" });
        res.setHeader("Retry-After", String(wait));
        return void res.status((status = 429)).json({ error: "Rate limit exceeded" });
      }
      status = await proxy({ cfg: gw, dispatcher, breakers, log }, server, req, res);
    } catch (err) {
      log.error("gateway_error", { requestId: res.locals.requestId, err: String((err as Error)?.stack ?? err) });
      if (!res.headersSent) res.status((status = 500)).json({ error: "Internal error" });
    } finally {
      const seconds = Number(process.hrtime.bigint() - started) / 1e9;
      requests.inc({ server: serverId.slice(0, 63), method: req.method, class: `${Math.floor(status / 100)}xx` });
      duration.observe({ server: serverId.slice(0, 63) }, seconds);
      // Access log. Never includes Authorization or bodies.
      log.info("access", { requestId: res.locals.requestId, server: serverId, method: req.method, status, sub: subject, ip: req.ip, ms: Math.round(seconds * 1000) });
    }
  });

  app.use((_req, res) => void res.status(404).json({ error: "Not found" }));
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err?.status === 413 ? 413 : err?.status === 400 ? 400 : 500;
    if (status === 500) log.error("unhandled", { err: String(err?.stack ?? err) });
    res.status(status).json({ error: status === 413 ? "Payload too large" : status === 400 ? "Bad request" : "Internal error" });
  });
  return { app, breakers };
}

export function createMetricsApp() {
  const app = express();
  app.disable("x-powered-by");
  app.get("/metrics", (_req, res) => void res.type("text/plain; version=0.0.4").send(renderMetrics()));
  return app;
}
