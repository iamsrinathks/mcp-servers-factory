/** Per-backend circuit breaker: stop hammering a dead backend, fail fast, probe to recover. */
export class CircuitBreaker {
  private failures = 0;
  private openedAt = 0;
  private probing = false;
  constructor(
    private threshold: number,
    private resetMs: number,
    private now: () => number = Date.now,
  ) {}

  /** returns 0 if the call may proceed, else seconds until the next probe */
  guard(): number {
    if (this.openedAt === 0) return 0;
    const elapsed = this.now() - this.openedAt;
    if (elapsed >= this.resetMs && !this.probing) {
      this.probing = true; // half-open: let exactly one request through
      return 0;
    }
    return Math.max(1, Math.ceil((this.resetMs - elapsed) / 1000));
  }
  success() {
    this.failures = 0;
    this.openedAt = 0;
    this.probing = false;
  }
  failure() {
    this.failures += 1;
    this.probing = false;
    if (this.failures >= this.threshold || this.openedAt !== 0) this.openedAt = this.now();
  }
  get isOpen() {
    return this.openedAt !== 0;
  }
}
