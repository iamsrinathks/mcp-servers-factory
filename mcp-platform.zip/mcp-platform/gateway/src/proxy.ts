import { Readable } from "node:stream";
import type { Request, Response } from "express";
import { fetch, type Dispatcher } from "undici";
import type { GatewayConfig, ServerConfig } from "./config.js";
import type { CircuitBreaker } from "./breaker.js";
import type { Logger } from "./logger.js";
import { breakerRejects, upstreamErrors } from "./metrics.js";

// Explicit allow-lists: anything not listed (Cookie, Host, X-Forwarded-*, hop-by-hop…) is dropped.
const REQUEST_HEADERS = ["authorization", "content-type", "accept", "mcp-session-id", "mcp-protocol-version", "last-event-id", "traceparent", "tracestate"];
const RESPONSE_HEADERS = ["content-type", "mcp-session-id", "cache-control", "retry-after", "www-authenticate", "allow"];

export interface ProxyDeps {
  cfg: GatewayConfig["gateway"];
  dispatcher: Dispatcher;
  breakers: Map<string, CircuitBreaker>;
  log: Logger;
}

const fail = (res: Response, status: number, msg: string) => {
  if (!res.headersSent) res.status(status).json({ error: msg });
  else res.destroy();
};

/** Streamable-HTTP reverse proxy. Bytes in, bytes out: the JSON-RPC body is never parsed or altered. */
export async function proxy(deps: ProxyDeps, server: ServerConfig, req: Request, res: Response): Promise<number> {
  const { cfg, dispatcher, breakers, log } = deps;
  const requestId = res.locals.requestId as string;
  const breaker = breakers.get(server.id)!;

  const wait = breaker.guard();
  if (wait > 0) {
    breakerRejects.inc({ server: server.id });
    res.setHeader("Retry-After", String(wait));
    fail(res, 503, "Backend temporarily unavailable");
    return 503;
  }

  const headers: Record<string, string> = {
    "x-request-id": requestId,
    "user-agent": "mcp-gateway/0.1",
    "x-forwarded-for": req.ip ?? "",
    "x-forwarded-proto": req.protocol,
  };
  for (const h of REQUEST_HEADERS) {
    const v = req.headers[h];
    if (typeof v === "string") headers[h] = v;
  }

  const abort = new AbortController();
  res.on("close", () => {
    if (!res.writableEnded) abort.abort(); // client went away → stop the upstream call
  });

  let upstream;
  try {
    upstream = await fetch(server.url, {
      method: req.method,
      headers,
      body: req.method === "POST" ? (req.body as Buffer) : undefined,
      redirect: "manual", // never follow: a redirect could pivot to an internal host (SSRF)
      signal: abort.signal,
      dispatcher,
    });
  } catch (err) {
    if (abort.signal.aborted) return 499; // client closed request
    const kind = /timeout/i.test(String((err as any)?.cause?.code ?? (err as Error).message)) ? "timeout" : "connect";
    upstreamErrors.inc({ server: server.id, kind });
    breaker.failure();
    log.warn("upstream_error", { requestId, server: server.id, kind, err: String((err as any)?.cause?.code ?? (err as Error).message) });
    fail(res, kind === "timeout" ? 504 : 502, kind === "timeout" ? "Backend timed out" : "Backend unreachable");
    return kind === "timeout" ? 504 : 502;
  }

  if (upstream.status >= 300 && upstream.status < 400) {
    upstreamErrors.inc({ server: server.id, kind: "redirect" });
    breaker.failure();
    await upstream.body?.cancel();
    fail(res, 502, "Backend returned an unexpected redirect");
    return 502;
  }

  if (upstream.status === 502 || upstream.status === 503 || upstream.status === 504) breaker.failure();
  else breaker.success();

  res.status(upstream.status);
  for (const h of RESPONSE_HEADERS) {
    const v = upstream.headers.get(h);
    if (v) res.setHeader(h, v);
  }

  if (!upstream.body) {
    res.end();
    return upstream.status;
  }
  const stream = Readable.fromWeb(upstream.body as never);
  stream.on("error", () => res.destroy()); // mid-stream failure: drop the connection, client will retry
  res.on("close", () => stream.destroy());
  res.flushHeaders(); // let SSE events flow immediately
  stream.pipe(res);
  return upstream.status;
}
