/**
 * Sliding-window limiter keyed by authenticated subject (not IP: behind the gateway
 * every request shares the gateway's IP). Per-replica; the gateway enforces the
 * fleet-wide per-IP limit in front of this.
 */
export class RateLimiter {
  private hits = new Map<string, number[]>();
  constructor(
    private windowMs: number,
    private max: number,
    private now: () => number = Date.now,
  ) {}

  /** returns 0 if allowed, else seconds to wait */
  check(key: string): number {
    const t = this.now();
    const arr = (this.hits.get(key) ?? []).filter((x) => t - x < this.windowMs);
    if (arr.length >= this.max) {
      this.hits.set(key, arr);
      return Math.max(1, Math.ceil((arr[0]! + this.windowMs - t) / 1000));
    }
    arr.push(t);
    this.hits.set(key, arr);
    if (this.hits.size > 10_000) this.gc(t);
    return 0;
  }

  private gc(t: number) {
    for (const [k, v] of this.hits) if (v.every((x) => t - x >= this.windowMs)) this.hits.delete(k);
  }
}
