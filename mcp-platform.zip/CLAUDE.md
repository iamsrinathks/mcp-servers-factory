# CLAUDE.md: guide for AI agents working in this repo

Read `docs/PROBLEM_STATEMENT.md` for the *why*. This file is the *how to work here*.

## What this is

Four independent TypeScript services supporting the Audit-Guard admission-webhook rollout on a shared GKE cluster: `server/` (read-only MCP tools), `gateway/` (MCP reverse proxy with auth), `pr-drafter/` (denial → draft remediation PR), `exception-triage/` (waiver PR → advisory comment). Proof of concept; nothing has run against real infrastructure.

## Non-negotiable rules

Do not weaken these, even if a task seems to call for it. If a request requires it, stop and ask.

1. No component may merge, approve, or write an `AuditException`, or read/handle Secret objects. Do not add such code paths, RBAC verbs (`secrets`, `create`, `update`, `delete`, `patch` on the server role), or GitHub permissions (only what each `github.ts` already requests; PR drafter: contents W + pull_requests W; triage: contents R + PR R + issues W).
2. The verdict/fix logic stays **deterministic** (no LLM in the decision path). An LLM may only add clearly-labelled extra text.
3. Missing evidence must surface as a warning or a skip, never as a pass.
4. Writers default to `DRY_RUN=true`; pilot-namespace / allowed-owner / rate-cap guardrails must stay enforced in code, and each has a test.
5. Auth cannot be disabled in production (`NODE_ENV=production`): JWT on server/gateway, Pub/Sub OIDC on the drafter, webhook HMAC on triage. Redirects are never followed by the gateway proxy or Jira client.
6. Never log tokens, keys or Secret values; logs go through `logger.ts` redaction.

## Layout and commands

```
server/            MCP server. src/tools.ts = the 7 tools; src/kube.ts = KubeReader (get/list only); dev/ = fake IdP, fixtures, smoke test
gateway/           src/proxy.ts (forwarding), auth.ts, breaker.ts, ratelimit.ts; config/gateway*.yaml
pr-drafter/        src/events.ts (parse denial) → backstage.ts (owner) → drafter.ts (guardrails) → remediate.ts (YAML edit) → github.ts
exception-triage/  src/triage.ts (orchestration) → policy.ts (all checks, pure) → comment.ts; model.ts parses AuditException YAML
docs/              PROBLEM_STATEMENT.md          DEPLOYMENT.md  MCP server + gateway rollout
```

```bash
make install && make test            # everything; or `cd <pkg> && npm test`
cd <pkg> && npx tsc --noEmit         # typecheck (must be clean)
make dev-up / make smoke / make dev-down    # localhost server+gateway, PID files in .dev/
npm run drill -- <file> ...          # offline demo in pr-drafter and exception-triage
```

Each package: `src/config.ts` (zod env validation, fails fast) is the source of truth for configuration; `deploy/` has manifests with `TODO` placeholders; `test/` uses vitest with injected fakes (`GitHub`, `OwnerResolver`, `Jira`, `KubeReader` interfaces), so tests need no network.

## Conventions

- Node 22+, ESM, TypeScript strict (`noUncheckedIndexedAccess`), `"types": ["node"]` is required in tsconfig. zod v4, express 5, vitest.
- Dependencies are injected via small interfaces (see above); add a fake to tests instead of mocking modules.
- Add a test with every behaviour change; guardrails and "unknown is not OK" paths especially.
- Packages do not import from each other. Copying a tiny helper is preferred over creating a shared package.
- Keep comments for *why* (security reasoning, non-obvious constraints). Keep READMEs honest about what is untested.

## Gotchas learned the hard way

- `npm install` may be OOM-killed in constrained sandboxes; install packages one at a time.
- Don't use `pkill -f` for dev processes (kills the shell); use `make dev-down` (PID files).
- `remediate.ts` edits only the target YAML document via the `yaml` Document API and re-serialises just that range, to keep diffs minimal and comments intact. It mirrors sequence indentation style (`usesUnindentedSeqs`). If you change it, rerun the golden tests and the drill.
- `pr-drafter/src/checks.ts` deliberately mirrors what the Audit-Guard webhook enforces; if Audit-Guard's rules change, change it in the same PR and keep `residualViolations` validation.
- zod v4: apply `.default()` before `.transform()` (see the `bool()` helper in config files).
- Exception `validDate` semantics: a waiver is honoured only when it equals today's UTC date.

## Known assumptions (verify before relying on them)

- `AuditException` CRD: `governance.platform.example.com/v1alpha1`, spec `ruleId, workloadName, validDate, jiraTicket, approvedBy, reason`.
- Backstage catalog annotations: `backstage.io/kubernetes-namespace`, `backstage.io/kubernetes-id`, `github.com/project-slug`, `jira/project-key`, `audit-guard/manifest-path`.
- Audit-Guard emits `{"event":"admission_denied","namespace","workload","rules":[...]}` (needs a small change in its `server.py`; legacy text is also parsed).
- Waiver history in `exception-triage` only sees `AuditException` files still present on the base branch.

## Good next tasks

Build/scan/sign images and apply manifests on a sandbox cluster; gateway OAuth discovery + mTLS to backends; a `make dev-real` target using a read-only kubeconfig; a git-log based waiver history counter; surfacing triage results as an MCP tool. Not in scope: auto-merge, auto-approve, or any Secret access.
