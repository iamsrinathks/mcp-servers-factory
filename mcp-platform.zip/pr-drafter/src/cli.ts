// Offline drill: see exactly what the drafter would change in a manifest, with no network and no repo.
//   npm run drill -- examples/payment-service.yaml --workload payment-service --namespace team-a --rules CIS-4.4.1,CIS-4.1.5
import { readFileSync } from "node:fs";
import { createTwoFilesPatch } from "diff";
import { isSupportedRule, type RuleId } from "./checks.js";
import { residualViolations } from "./drafter.js";
import { candidateNames } from "./events.js";
import { remediateManifest } from "./remediate.js";

const args = process.argv.slice(2);
const file = args.find((a) => !a.startsWith("--"));
const opt = (n: string, d?: string) => {
  const i = args.indexOf(`--${n}`);
  return i >= 0 ? args[i + 1] : d;
};
if (!file || !opt("workload")) {
  console.error("usage: drill <manifest.yaml> --workload <name> [--namespace <ns>] [--rules CIS-4.4.1,CIS-4.1.5]");
  process.exit(2);
}
const rules = (opt("rules", "CIS-4.4.1,CIS-4.1.5") as string).split(",").filter(isSupportedRule) as RuleId[];
const names = candidateNames(opt("workload")!);
const src = readFileSync(file, "utf8");
const r = remediateManifest(src, { names, namespace: opt("namespace", "default")!, rules });

if (!r.changed) {
  console.log("No change.", r.skipped.join("; ") || "");
  process.exit(1);
}
console.log(createTwoFilesPatch(file, file, src, r.text, "before", "after", { context: 3 }));
console.log("Changes:\n" + r.changes.map((c) => `  • [${c.rule}] ${c.description}`).join("\n"));
console.log("\nCheck before merging:\n" + [...new Set(r.warnings)].map((w) => `  ! ${w}`).join("\n"));
const residual = residualViolations(r.text, names, rules);
console.log(residual.length ? `\nVALIDATION FAILED: ${residual.join("; ")}` : "\nValidation: the fixed workload passes the same rules Audit-Guard enforces.");
process.exit(residual.length ? 1 : 0);
