/**
 * Mirrors the Audit-Guard webhook's rule semantics (server.py) so a fix that passes here
 * would pass admission. Keep these in lock-step with the webhook.
 */
export type RuleId = "CIS-4.4.1" | "CIS-4.1.5";
export const SUPPORTED_RULES: readonly RuleId[] = ["CIS-4.4.1", "CIS-4.1.5"];
export const isSupportedRule = (r: string): r is RuleId => (SUPPORTED_RULES as readonly string[]).includes(r);

type Obj = Record<string, any>;

/** Path from a workload object to its PodSpec. */
export const POD_SPEC_PATH: Record<string, string[]> = {
  Pod: ["spec"],
  Deployment: ["spec", "template", "spec"],
  StatefulSet: ["spec", "template", "spec"],
  DaemonSet: ["spec", "template", "spec"],
  ReplicaSet: ["spec", "template", "spec"],
  Job: ["spec", "template", "spec"],
  CronJob: ["spec", "jobTemplate", "spec", "template", "spec"],
};

export function podSpecOf(obj: Obj): Obj | undefined {
  const path = POD_SPEC_PATH[obj?.kind];
  if (!path) return undefined;
  return path.reduce<any>((o, k) => o?.[k], obj);
}

export interface Violation {
  ruleId: RuleId;
  detail: string;
}

export function findViolations(podSpec: Obj): Violation[] {
  const out: Violation[] = [];
  const containers: Obj[] = [...(podSpec.containers ?? []), ...(podSpec.initContainers ?? [])];
  for (const c of containers) {
    for (const e of c.env ?? []) {
      if (e?.valueFrom?.secretKeyRef)
        out.push({ ruleId: "CIS-4.4.1", detail: `container '${c.name}' env ${e.name} uses secretKeyRef` });
    }
    for (const ef of c.envFrom ?? []) {
      if (ef?.secretRef) out.push({ ruleId: "CIS-4.4.1", detail: `container '${c.name}' uses envFrom.secretRef ${ef.secretRef.name}` });
    }
  }
  // Webhook treats True *or omitted* as a violation; only an explicit false passes.
  if (podSpec.automountServiceAccountToken !== false)
    out.push({ ruleId: "CIS-4.1.5", detail: "automountServiceAccountToken is true or omitted" });
  return out;
}
