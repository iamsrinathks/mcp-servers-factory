import express, { type NextFunction, type Request, type Response } from "express";
import { createRemoteJWKSet, jwtVerify } from "jose";
import type { Config } from "./config.js";
import type { Drafter } from "./drafter.js";
import { parseDenial } from "./events.js";
import type { Logger } from "./logger.js";

export type Verifier = (authorization: string | undefined) => Promise<void>;

/** Pub/Sub push subscriptions sign each request with a Google OIDC token for a service account you choose. */
export function createPubSubVerifier(cfg: Config): Verifier {
  if (!cfg.PUBSUB_VERIFY) return async () => undefined; // local dev only (refused when NODE_ENV=production)
  const jwks = createRemoteJWKSet(new URL("https://www.googleapis.com/oauth2/v3/certs"));
  return async (header) => {
    const m = /^Bearer\s+(\S+)$/i.exec(header ?? "");
    if (!m?.[1]) throw new Error("missing token");
    const { payload } = await jwtVerify(m[1], jwks, { issuer: ["https://accounts.google.com", "accounts.google.com"], audience: cfg.PUBSUB_AUDIENCE });
    if (payload.email !== cfg.PUBSUB_INVOKER_SA || payload.email_verified !== true) throw new Error("unexpected caller");
  };
}

export function createApp(deps: { drafter: Drafter; verify: Verifier; log: Logger }) {
  const { drafter, verify, log } = deps;
  const app = express();
  app.disable("x-powered-by");
  app.get("/healthz", (_q, r) => void r.json({ status: "ok" }));

  app.post("/pubsub", express.json({ limit: "512kb" }), async (req: Request, res: Response) => {
    try {
      await verify(req.header("authorization"));
    } catch {
      log.warn("pubsub_auth_rejected", { ip: req.ip });
      return void res.status(401).json({ error: "Unauthorized" });
    }

    const msg = req.body?.message;
    const messageId: string = msg?.messageId ?? "?";
    let payload: unknown;
    try {
      payload = JSON.parse(Buffer.from(String(msg?.data ?? ""), "base64").toString("utf8"));
    } catch {
      log.warn("ignored", { messageId, reason: "not_json" });
      return void res.status(200).json({ status: "ignored" }); // ack: retrying garbage never helps
    }
    const event = parseDenial(payload);
    if (!event) {
      log.debug("ignored", { messageId, reason: "not_a_denial" });
      return void res.status(200).json({ status: "ignored" });
    }
    try {
      const outcome = await drafter.handle(event);
      log.info("drafter_outcome", { audit: true, messageId, namespace: event.namespace, workload: event.workload, rules: event.rules, ...summarise(outcome) });
      // Every outcome, including validation errors, is final → ack. Only exceptions are retried.
      res.status(200).json({ status: outcome.status });
    } catch (err) {
      log.error("drafter_failed", { messageId, namespace: event.namespace, workload: event.workload, err: String((err as Error)?.message ?? err) });
      res.status(500).json({ error: "retry" }); // transient (GitHub/Backstage down) → Pub/Sub redelivers, then dead-letters
    }
  });

  app.use((err: any, _q: Request, res: Response, _n: NextFunction) => {
    res.status(err?.status === 413 ? 413 : 400).json({ error: "Bad request" });
  });
  return app;
}

function summarise(o: any) {
  return { status: o.status, reason: o.reason, detail: o.detail, url: o.url, branch: o.branch, files: o.files };
}
