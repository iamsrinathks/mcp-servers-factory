import { z } from "zod";

const csv = z.string().default("").transform((s) => s.split(",").map((x) => x.trim()).filter(Boolean));
const bool = (d: "true" | "false") => z.enum(["true", "false"]).default(d).transform((v) => v === "true");

const schema = z
  .object({
    PORT: z.coerce.number().int().default(8080),
    LOG_LEVEL: z.enum(["debug", "info", "warn", "error"]).default("info"),

    // ---- safety rails (default to the safest setting) ----
    DRY_RUN: bool("true"), // true → compute the fix and log the diff; open nothing
    PILOT_NAMESPACES: csv, // only these namespaces are ever touched
    ALLOWED_REPO_OWNERS: csv, // GitHub orgs/users the drafter may write to
    MAX_PRS_PER_REPO_PER_DAY: z.coerce.number().int().min(1).default(3),
    MAX_DIFF_LINES: z.coerce.number().int().min(1).default(150),
    MAX_FILES_SCANNED: z.coerce.number().int().min(1).default(300),
    MANIFEST_EXCLUDE: z.string().default("(^|/)(charts?|templates|node_modules|\\.github)/"),

    // ---- Backstage ----
    BACKSTAGE_URL: z.string().url(),
    BACKSTAGE_TOKEN: z.string().optional(),

    // ---- GitHub App ----
    GITHUB_API_URL: z.string().url().default("https://api.github.com"),
    GITHUB_APP_ID: z.string().optional(),
    GITHUB_APP_PRIVATE_KEY: z.string().optional(), // PEM; supply via Secret Manager / mounted secret, never plain env in prod

    // ---- Pub/Sub push authentication ----
    PUBSUB_AUDIENCE: z.string().optional(), // the service URL configured on the push subscription
    PUBSUB_INVOKER_SA: z.string().optional(), // service-account email the subscription signs as
    PUBSUB_VERIFY: bool("true"),
  })
  .superRefine((c, ctx) => {
    if (!c.PILOT_NAMESPACES.length) ctx.addIssue({ code: "custom", path: ["PILOT_NAMESPACES"], message: "required: list the pilot namespaces explicitly" });
    if (!c.ALLOWED_REPO_OWNERS.length) ctx.addIssue({ code: "custom", path: ["ALLOWED_REPO_OWNERS"], message: "required" });
    if (!c.DRY_RUN && (!c.GITHUB_APP_ID || !c.GITHUB_APP_PRIVATE_KEY))
      ctx.addIssue({ code: "custom", path: ["GITHUB_APP_ID"], message: "GITHUB_APP_ID and GITHUB_APP_PRIVATE_KEY are required when DRY_RUN=false" });
    if (c.PUBSUB_VERIFY && (!c.PUBSUB_AUDIENCE || !c.PUBSUB_INVOKER_SA))
      ctx.addIssue({ code: "custom", path: ["PUBSUB_AUDIENCE"], message: "PUBSUB_AUDIENCE and PUBSUB_INVOKER_SA are required (or PUBSUB_VERIFY=false for local dev only)" });
    if (!c.PUBSUB_VERIFY && process.env.NODE_ENV === "production")
      ctx.addIssue({ code: "custom", path: ["PUBSUB_VERIFY"], message: "cannot be disabled in production" });
  });

export type Config = z.infer<typeof schema>;

export function loadConfig(env: NodeJS.ProcessEnv = process.env): Config {
  const parsed = schema.safeParse(env);
  if (!parsed.success) throw new Error("Invalid configuration: " + parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; "));
  return parsed.data;
}
