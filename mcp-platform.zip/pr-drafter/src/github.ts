import { importPKCS8, SignJWT } from "jose";
import type { Config } from "./config.js";

export interface Repo {
  owner: string;
  name: string;
}
export interface TreeEntry {
  path: string;
  type: string;
  size?: number;
}

export interface GitHub {
  getDefaultBranch(r: Repo): Promise<{ name: string; sha: string }>;
  listTree(r: Repo, sha: string): Promise<TreeEntry[]>;
  getFile(r: Repo, path: string, ref: string): Promise<{ content: string; sha: string }>;
  findOpenPr(r: Repo, branch: string): Promise<{ url: string } | null>;
  countRecentPrs(r: Repo, sinceIso: string): Promise<number>;
  createBranch(r: Repo, branch: string, fromSha: string): Promise<void>;
  putFile(r: Repo, a: { path: string; content: string; blobSha: string; branch: string; message: string }): Promise<void>;
  createPr(r: Repo, a: { title: string; body: string; head: string; base: string; labels: string[] }): Promise<{ url: string; number: number }>;
}

export const PR_LABEL = "audit-guard-remediation";

/** GitHub App auth: short-lived JWT → installation token, scoped to one repo, cached until near expiry. */
export function createGitHub(cfg: Config, fetchImpl: typeof fetch = fetch): GitHub {
  const api = cfg.GITHUB_API_URL.replace(/\/$/, "");
  const tokens = new Map<string, { token: string; exp: number }>();

  async function raw(path: string, init: RequestInit & { token?: string; appJwt?: string } = {}) {
    const res = await fetchImpl(`${api}${path}`, {
      ...init,
      headers: {
        accept: "application/vnd.github+json",
        "x-github-api-version": "2022-11-28",
        "user-agent": "audit-guard-pr-drafter",
        ...(init.token ? { authorization: `Bearer ${init.token}` } : {}),
        ...(init.appJwt ? { authorization: `Bearer ${init.appJwt}` } : {}),
        ...(init.body ? { "content-type": "application/json" } : {}),
      },
      signal: AbortSignal.timeout(15000),
    });
    return res;
  }

  async function tokenFor(r: Repo): Promise<string> {
    const key = `${r.owner}/${r.name}`;
    const cached = tokens.get(key);
    if (cached && cached.exp - Date.now() > 60_000) return cached.token;
    const pk = await importPKCS8(cfg.GITHUB_APP_PRIVATE_KEY!.replace(/\\n/g, "\n"), "RS256");
    const now = Math.floor(Date.now() / 1000);
    const appJwt = await new SignJWT({}).setProtectedHeader({ alg: "RS256" }).setIssuer(cfg.GITHUB_APP_ID!).setIssuedAt(now - 60).setExpirationTime(now + 540).sign(pk);
    const inst = await raw(`/repos/${key}/installation`, { appJwt });
    if (!inst.ok) throw new Error(`GitHub App is not installed on ${key} (${inst.status})`);
    const { id } = (await inst.json()) as { id: number };
    const tok = await raw(`/app/installations/${id}/access_tokens`, {
      method: "POST",
      appJwt,
      // Least privilege: only this repository, only what we need.
      body: JSON.stringify({ repositories: [r.name], permissions: { contents: "write", pull_requests: "write", metadata: "read" } }),
    });
    if (!tok.ok) throw new Error(`could not mint installation token (${tok.status})`);
    const j = (await tok.json()) as { token: string; expires_at: string };
    tokens.set(key, { token: j.token, exp: Date.parse(j.expires_at) });
    return j.token;
  }

  async function call<T>(r: Repo, path: string, init: RequestInit = {}, okStatuses: number[] = []): Promise<T> {
    const res = await raw(path, { ...init, token: await tokenFor(r) });
    if (!res.ok && !okStatuses.includes(res.status)) throw new Error(`GitHub ${init.method ?? "GET"} ${path.split("?")[0]} → ${res.status}`);
    return (res.status === 204 ? null : await res.json().catch(() => null)) as T;
  }
  const P = (r: Repo) => `/repos/${r.owner}/${r.name}`;

  return {
    async getDefaultBranch(r) {
      const repo = await call<any>(r, P(r));
      const ref = await call<any>(r, `${P(r)}/git/ref/heads/${repo.default_branch}`);
      return { name: repo.default_branch, sha: ref.object.sha };
    },
    async listTree(r, sha) {
      const t = await call<any>(r, `${P(r)}/git/trees/${sha}?recursive=1`);
      if (t.truncated) throw new Error("repository tree too large to scan; set the audit-guard/manifest-path annotation");
      return t.tree as TreeEntry[];
    },
    async getFile(r, path, ref) {
      const f = await call<any>(r, `${P(r)}/contents/${path.split("/").map(encodeURIComponent).join("/")}?ref=${encodeURIComponent(ref)}`);
      return { content: Buffer.from(f.content, "base64").toString("utf8"), sha: f.sha };
    },
    async findOpenPr(r, branch) {
      const prs = await call<any[]>(r, `${P(r)}/pulls?state=open&head=${encodeURIComponent(`${r.owner}:${branch}`)}`);
      return prs?.[0] ? { url: prs[0].html_url } : null;
    },
    async countRecentPrs(r, sinceIso) {
      const q = encodeURIComponent(`repo:${r.owner}/${r.name} is:pr label:${PR_LABEL} created:>=${sinceIso.slice(0, 10)}`);
      return (await call<any>(r, `/search/issues?q=${q}&per_page=1`)).total_count ?? 0;
    },
    async createBranch(r, branch, fromSha) {
      await call(r, `${P(r)}/git/refs`, { method: "POST", body: JSON.stringify({ ref: `refs/heads/${branch}`, sha: fromSha }) });
    },
    async putFile(r, a) {
      await call(r, `${P(r)}/contents/${a.path.split("/").map(encodeURIComponent).join("/")}`, {
        method: "PUT",
        body: JSON.stringify({ message: a.message, content: Buffer.from(a.content).toString("base64"), sha: a.blobSha, branch: a.branch }),
      });
    },
    async createPr(r, a) {
      // draft: true — a human must mark it ready; nothing here ever merges.
      const pr = await call<any>(r, `${P(r)}/pulls`, { method: "POST", body: JSON.stringify({ title: a.title, body: a.body, head: a.head, base: a.base, draft: true }) });
      await call(r, `${P(r)}/issues/${pr.number}/labels`, { method: "POST", body: JSON.stringify({ labels: a.labels }) }).catch(() => undefined);
      return { url: pr.html_url, number: pr.number };
    },
  };
}
