import { createTwoFilesPatch } from "diff";
import type { OwnerResolver } from "./backstage.js";
import { findViolations, isSupportedRule, podSpecOf, type RuleId } from "./checks.js";
import type { Config } from "./config.js";
import { candidateNames, supportedRules, unsupportedRules, type DenialEvent } from "./events.js";
import { PR_LABEL, type GitHub } from "./github.js";
import type { Logger } from "./logger.js";
import { prBody, prTitle } from "./prbody.js";
import { isTemplated, remediateManifest, type Change } from "./remediate.js";
import { parseAllDocuments } from "yaml";

export type Outcome =
  | { status: "pr_opened"; url: string; branch: string }
  | { status: "dry_run"; branch: string; diff: string; body: string; files: string[] }
  | { status: "skipped"; reason: string; detail?: string }
  | { status: "error"; reason: string; detail?: string };

export interface DrafterDeps {
  cfg: Config;
  owners: OwnerResolver;
  gh: GitHub;
  log: Logger;
  now?: () => Date;
}

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
const isYaml = (p: string) => /\.ya?ml$/i.test(p);

export class Drafter {
  private inflight = new Set<string>();
  constructor(private d: DrafterDeps) {}

  async handle(event: DenialEvent): Promise<Outcome> {
    const { cfg, owners, gh, log } = this.d;
    const now = this.d.now?.() ?? new Date();
    const skip = (reason: string, detail?: string): Outcome => ({ status: "skipped", reason, detail });

    // --- guardrail 1: pilot namespaces only
    if (!cfg.PILOT_NAMESPACES.includes(event.namespace)) return skip("namespace_not_in_pilot");
    const rules = supportedRules(event) as RuleId[];
    const unsupported = unsupportedRules(event);
    if (!rules.length) return skip("no_supported_rules", unsupported.join(","));

    const owner = await owners.resolve(event.namespace, event.workload);
    if (!owner) return skip("owner_unresolved", "Backstage returned no unambiguous component for this namespace/workload");
    // --- guardrail 2: only repos in allowed orgs
    if (!cfg.ALLOWED_REPO_OWNERS.includes(owner.repo.owner)) return skip("repo_owner_not_allowed", owner.repo.owner);

    const branch = `audit-guard/fix-${slug(event.namespace)}-${slug(event.workload)}-${slug(rules.join("-"))}`.slice(0, 200);
    if (this.inflight.has(branch)) return skip("already_in_progress");
    this.inflight.add(branch);
    try {
      // --- dedupe: one open PR per workload+rules
      const existing = await gh.findOpenPr(owner.repo, branch);
      if (existing) return skip("pr_already_open", existing.url);
      // --- guardrail 3: per-repo daily cap
      const since = new Date(now.getTime() - 24 * 3600 * 1000).toISOString();
      if ((await gh.countRecentPrs(owner.repo, since)) >= cfg.MAX_PRS_PER_REPO_PER_DAY) return skip("repo_daily_cap_reached");

      const base = await gh.getDefaultBranch(owner.repo);
      const exclude = new RegExp(cfg.MANIFEST_EXCLUDE);
      const prefix = owner.manifestPath ? owner.manifestPath.replace(/^\/|\/$/g, "") + "/" : "";
      const candidates = (await gh.listTree(owner.repo, base.sha)).filter((t) => t.type === "blob" && isYaml(t.path) && (t.size ?? 0) < 200_000 && t.path.startsWith(prefix) && !exclude.test(t.path));
      if (candidates.length > cfg.MAX_FILES_SCANNED) return skip("repo_too_large_to_scan", `${candidates.length} YAML files; add the audit-guard/manifest-path annotation`);

      const names = candidateNames(event.workload);
      const changes: Change[] = [];
      const warnings: string[] = [];
      const edits: { path: string; before: string; after: string; blobSha: string }[] = [];
      const notes: string[] = [];

      for (const f of candidates) {
        const file = await gh.getFile(owner.repo, f.path, base.name);
        if (!names.some((n) => file.content.includes(n))) continue; // cheap pre-filter
        if (isTemplated(file.content)) {
          notes.push(`${f.path}: helm_templated`);
          continue;
        }
        const r = remediateManifest(file.content, { names, namespace: event.namespace, rules });
        notes.push(...r.skipped.map((s) => `${f.path}: ${s}`));
        if (!r.changed) continue;
        // --- validation: the fixed workload must now pass the same rules the webhook enforces
        const residual = residualViolations(r.text, names, rules);
        if (residual.length) return { status: "error", reason: "validation_failed", detail: `${f.path}: ${residual.join("; ")}` };
        edits.push({ path: f.path, before: file.content, after: r.text, blobSha: file.sha });
        changes.push(...r.changes);
        warnings.push(...r.warnings);
      }

      if (!edits.length) return skip("no_fixable_manifest_found", notes.slice(0, 5).join(" | ") || "no file in the repo defines this workload");
      if (edits.length > 3) return skip("ambiguous_multiple_files", edits.map((e) => e.path).join(", "));

      const diff = edits.map((e) => createTwoFilesPatch(`a/${e.path}`, `b/${e.path}`, e.before, e.after, "", "", { context: 3 })).join("\n");
      const diffLines = diff.split("\n").filter((l) => /^[+-][^+-]/.test(l)).length;
      if (diffLines > cfg.MAX_DIFF_LINES) return skip("diff_too_large", `${diffLines} changed lines > ${cfg.MAX_DIFF_LINES}`);

      const body = prBody({ event, owner, rules, unsupported, changes, warnings, files: edits.map((e) => e.path), diff });
      if (cfg.DRY_RUN) {
        log.info("dry_run_pr", { branch, repo: `${owner.repo.owner}/${owner.repo.name}`, files: edits.map((e) => e.path) });
        return { status: "dry_run", branch, diff, body, files: edits.map((e) => e.path) };
      }

      await gh.createBranch(owner.repo, branch, base.sha);
      for (const e of edits)
        await gh.putFile(owner.repo, { path: e.path, content: e.after, blobSha: e.blobSha, branch, message: `fix(security): ${rules.join(", ")} for ${event.workload}\n\nProposed by audit-guard-pr-drafter after an Audit-Guard denial. Requires human review.` });
      const pr = await gh.createPr(owner.repo, { title: prTitle(event, rules), body, head: branch, base: base.name, labels: [PR_LABEL] });
      return { status: "pr_opened", url: pr.url, branch };
    } finally {
      this.inflight.delete(branch);
    }
  }
}

export function residualViolations(text: string, names: string[], rules: RuleId[]): string[] {
  const out: string[] = [];
  for (const doc of parseAllDocuments(text)) {
    if (doc.errors.length) return ["result is not valid YAML"];
    const js = doc.toJS() as any;
    if (!names.includes(js?.metadata?.name)) continue;
    const ps = podSpecOf(js);
    if (!ps) continue;
    for (const v of findViolations(ps)) if (rules.includes(v.ruleId) && isSupportedRule(v.ruleId)) out.push(`${v.ruleId}: ${v.detail}`);
  }
  return out;
}
