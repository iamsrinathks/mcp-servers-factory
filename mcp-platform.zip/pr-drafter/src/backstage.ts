import type { Config } from "./config.js";
import { candidateNames } from "./events.js";

export interface OwnerInfo {
  component: string;
  repo: { owner: string; name: string };
  ownerRef?: string; // e.g. group:default/payments-team
  jiraProject?: string;
  /** Optional narrowing: annotation `audit-guard/manifest-path` (e.g. deploy/k8s). */
  manifestPath?: string;
}

/** namespace + workload → owning team's repo. Returns null when it cannot be determined unambiguously. */
export interface OwnerResolver {
  resolve(namespace: string, workload: string): Promise<OwnerInfo | null>;
}

const A = {
  ns: "backstage.io/kubernetes-namespace",
  id: "backstage.io/kubernetes-id",
  slug: "github.com/project-slug",
  jira: "jira/project-key",
  path: "audit-guard/manifest-path",
};

export function createBackstageResolver(cfg: Config, fetchImpl: typeof fetch = fetch): OwnerResolver {
  return {
    async resolve(namespace, workload) {
      const url = `${cfg.BACKSTAGE_URL.replace(/\/$/, "")}/api/catalog/entities/by-query?limit=50&filter=${encodeURIComponent(`kind=component,metadata.annotations.${A.ns}=${namespace}`)}`;
      const res = await fetchImpl(url, { headers: cfg.BACKSTAGE_TOKEN ? { authorization: `Bearer ${cfg.BACKSTAGE_TOKEN}` } : {}, signal: AbortSignal.timeout(8000) });
      if (!res.ok) throw new Error(`Backstage catalog returned ${res.status}`); // transient → caller retries
      const items: any[] = ((await res.json()) as any).items ?? [];
      const names = candidateNames(workload);
      // Namespace can host several components; prefer the one whose kubernetes-id matches the workload.
      const byId = items.filter((e) => names.includes(e.metadata?.annotations?.[A.id]));
      const pick = byId.length === 1 ? byId[0] : items.length === 1 ? items[0] : undefined;
      const slug: string | undefined = pick?.metadata?.annotations?.[A.slug];
      if (!pick || !slug || !/^[\w.-]+\/[\w.-]+$/.test(slug)) return null;
      const [owner, name] = slug.split("/") as [string, string];
      return {
        component: pick.metadata.name,
        repo: { owner, name },
        ownerRef: pick.spec?.owner,
        jiraProject: pick.metadata.annotations?.[A.jira],
        manifestPath: pick.metadata.annotations?.[A.path],
      };
    },
  };
}
