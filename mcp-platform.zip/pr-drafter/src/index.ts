import { createBackstageResolver } from "./backstage.js";
import { loadConfig } from "./config.js";
import { Drafter } from "./drafter.js";
import { createGitHub } from "./github.js";
import { createLogger } from "./logger.js";
import { createApp, createPubSubVerifier } from "./server.js";

const cfg = loadConfig();
const log = createLogger(cfg.LOG_LEVEL);
const drafter = new Drafter({ cfg, owners: createBackstageResolver(cfg), gh: createGitHub(cfg), log });
const app = createApp({ drafter, verify: createPubSubVerifier(cfg), log });

const server = app.listen(cfg.PORT, () => log.info("listening", { port: cfg.PORT, dryRun: cfg.DRY_RUN, pilotNamespaces: cfg.PILOT_NAMESPACES }));
if (cfg.DRY_RUN) log.warn("DRY_RUN=true — no branches or PRs will be created");

function shutdown(signal: string) {
  log.info("shutdown_start", { signal });
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 20_000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("unhandledRejection", (e) => log.error("unhandled_rejection", { err: String(e) }));
