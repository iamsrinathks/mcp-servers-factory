import { z } from "zod";
import { isSupportedRule } from "./checks.js";

export const DenialEvent = z.object({
  namespace: z.string().min(1).max(63),
  workload: z.string().min(1).max(253),
  kind: z.string().optional(),
  rules: z.array(z.string()).min(1),
  ticket: z.string().optional(),
  requestUid: z.string().optional(),
  timestamp: z.string().optional(),
});
export type DenialEvent = z.infer<typeof DenialEvent>;

const RULE_RE = /CIS-\d+(?:\.\d+)+/g;

/**
 * Accepts, in order of preference:
 *  1. structured Audit-Guard event  {event:"admission_denied", namespace, workload, rules:[…]}
 *  2. a Cloud Logging LogEntry wrapping (1) in jsonPayload
 *  3. the legacy text line "Denied admission for <ns>/<name>: … [CIS-x.y.z] …"
 * Returns null for anything that is not a usable denial (caller acks and moves on).
 */
export function parseDenial(raw: unknown): DenialEvent | null {
  const entry = (raw && typeof raw === "object" ? (raw as any) : {}) as Record<string, any>;
  const body = entry.jsonPayload ?? entry;
  const ts = entry.timestamp ?? body.timestamp;

  if (body.event === "admission_denied" || (body.namespace && body.workload && body.rules)) {
    const parsed = DenialEvent.safeParse({
      namespace: body.namespace,
      workload: body.workload,
      kind: body.kind,
      rules: body.rules,
      ticket: body.ticket,
      requestUid: body.request_uid ?? body.requestUid,
      timestamp: ts,
    });
    return parsed.success ? parsed.data : null;
  }

  const text: string | undefined = typeof entry.textPayload === "string" ? entry.textPayload : typeof body.message === "string" ? body.message : typeof body.msg === "string" ? body.msg : undefined;
  const m = text && /Denied admission for ([a-z0-9.-]+)\/([A-Za-z0-9._-]+)/.exec(text);
  if (m && text) {
    const rules = [...new Set(text.match(RULE_RE) ?? [])];
    if (rules.length) return DenialEvent.parse({ namespace: m[1], workload: m[2], rules, timestamp: ts });
  }
  return null;
}

/** Deployment 'payment' denied via pods 'payment-7d9f8-x2k4q' → candidates payment-7d9f8-x2k4q, payment-7d9f8, payment. */
export function candidateNames(workload: string): string[] {
  const parts = workload.split("-");
  const out = [workload];
  for (let i = 1; i <= 2 && parts.length - i >= 1; i++) out.push(parts.slice(0, parts.length - i).join("-"));
  return out;
}

export const supportedRules = (e: DenialEvent) => e.rules.filter(isSupportedRule);
export const unsupportedRules = (e: DenialEvent) => e.rules.filter((r) => !isSupportedRule(r));
