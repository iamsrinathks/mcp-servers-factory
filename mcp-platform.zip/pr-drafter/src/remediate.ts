import { Document, isMap, isSeq, parseAllDocuments, YAMLMap, YAMLSeq } from "yaml";
import { findViolations, POD_SPEC_PATH, podSpecOf, type RuleId } from "./checks.js";

export interface Change {
  rule: RuleId;
  workload: string;
  kind: string;
  description: string;
}
export interface RemediationResult {
  /** New file content (only target documents re-serialised; everything else byte-identical). */
  text: string;
  changed: boolean;
  changes: Change[];
  /** Behavioural risks a human must check before merging. */
  warnings: string[];
  /** Reasons a matching workload could not be fixed automatically. */
  skipped: string[];
}

export interface Target {
  names: string[]; // candidate workload names
  namespace: string;
  rules: RuleId[];
}

const dnsLabel = (s: string) => s.toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/^-+|-+$/g, "").slice(0, 63);
const SECRET_ROOT = "/etc/secrets";

/** Helm/Go templates cannot be safely rewritten as YAML. */
export const isTemplated = (text: string) => /\{\{.*?\}\}/s.test(text);

function usesUnindentedSeqs(src: string): boolean {
  return /^(\s*)[A-Za-z_][\w-]*:\s*\n\1- /m.test(src);
}

function ensureSeq(map: YAMLMap, key: string, doc: Document): YAMLSeq {
  const existing: unknown = map.get(key, true);
  if (isSeq(existing)) return existing;
  const seq = doc.createNode([]) as unknown as YAMLSeq;
  map.set(key, seq);
  return seq;
}

export function remediateManifest(original: string, target: Target): RemediationResult {
  const result: RemediationResult = { text: original, changed: false, changes: [], warnings: [], skipped: [] };
  if (isTemplated(original)) {
    result.skipped.push("file contains Helm/Go template syntax; needs a human");
    return result;
  }
  const docs = parseAllDocuments(original);
  if (docs.some((d) => d.errors.length)) {
    result.skipped.push("file has YAML parse errors");
    return result;
  }

  let out = original;
  // Apply from the last document backwards so earlier byte ranges stay valid.
  for (const doc of [...docs].reverse()) {
    const js = doc.toJS() as any;
    if (!js || typeof js !== "object" || !POD_SPEC_PATH[js.kind]) continue;
    if (!target.names.includes(js.metadata?.name)) continue;
    if (js.metadata?.namespace && js.metadata.namespace !== target.namespace) continue;

    const before = podSpecOf(js);
    if (!before) continue;
    const present = new Set(findViolations(before).map((v) => v.ruleId));
    const wanted = target.rules.filter((r) => present.has(r));
    if (!wanted.length) {
      result.skipped.push(`${js.kind}/${js.metadata.name}: no matching violation in this file (already fixed?)`);
      continue;
    }

    const podSpec = doc.getIn(POD_SPEC_PATH[js.kind]!, true);
    if (!isMap(podSpec)) continue;
    const ctx = { doc, podSpec, kind: js.kind as string, name: js.metadata.name as string, result };
    if (wanted.includes("CIS-4.1.5")) fixAutomount(ctx);
    if (wanted.includes("CIS-4.4.1")) fixSecretEnv(ctx);

    const [start, end] = [doc.range![0], doc.range![1]];
    const rendered = doc.toString({ lineWidth: 0, indentSeq: !usesUnindentedSeqs(original.slice(start, end)) });
    out = out.slice(0, start) + rendered.replace(/\n$/, original.slice(start, end).endsWith("\n") ? "\n" : "") + out.slice(end);
  }
  result.text = out;
  result.changed = out !== original;
  return result;
}

interface Ctx {
  doc: Document;
  podSpec: YAMLMap;
  kind: string;
  name: string;
  result: RemediationResult;
}

function fixAutomount({ podSpec, kind, name, result }: Ctx) {
  podSpec.set("automountServiceAccountToken", false);
  result.changes.push({ rule: "CIS-4.1.5", workload: name, kind, description: "set `automountServiceAccountToken: false`" });
  result.warnings.push(
    `${kind}/${name}: pods no longer receive an API token. If the app calls the Kubernetes API (client-go, operators, leader election) it will fail; in that case mount a projected token explicitly instead of merging this change.`,
  );
}

function fixSecretEnv({ doc, podSpec, kind, name, result }: Ctx) {
  const volumes = ensureSeq(podSpec, "volumes", doc);
  const haveVolume = new Set(volumes.items.map((v: any) => (isMap(v) ? v.get("name") : undefined)));
  const ensureVolume = (secretName: string, optional: boolean) => {
    const vol = dnsLabel(`secret-${secretName}`);
    if (!haveVolume.has(vol)) {
      const secret: Record<string, unknown> = { secretName };
      if (optional) secret.optional = true;
      volumes.add(doc.createNode({ name: vol, secret }));
      haveVolume.add(vol);
    }
    return vol;
  };

  for (const group of ["initContainers", "containers"] as const) {
    const list = podSpec.get(group, true);
    if (!isSeq(list)) continue;
    for (const c of list.items) {
      if (!isMap(c)) continue;
      const cname = String(c.get("name"));
      const mounted = new Set<string>();
      const mount = (secretName: string, optional: boolean) => {
        const vol = ensureVolume(secretName, optional);
        if (mounted.has(vol)) return;
        mounted.add(vol);
        ensureSeq(c, "volumeMounts", doc).add(doc.createNode({ name: vol, mountPath: `${SECRET_ROOT}/${secretName}`, readOnly: true }));
      };

      const env = c.get("env", true);
      if (isSeq(env)) {
        const kept: unknown[] = [];
        const added: { name: string; value: string }[] = [];
        for (const item of env.items) {
          const ref = isMap(item) ? (item.getIn(["valueFrom", "secretKeyRef"]) as any) : undefined;
          if (!ref) {
            kept.push(item);
            continue;
          }
          const envName = String((item as YAMLMap).get("name"));
          const secretName = String(ref.get("name"));
          const key = String(ref.get("key"));
          const optional = ref.get("optional") === true;
          mount(secretName, optional);
          added.push({ name: `${envName}_FILE`, value: `${SECRET_ROOT}/${secretName}/${key}` });
          result.changes.push({ rule: "CIS-4.4.1", workload: name, kind, description: `container \`${cname}\`: env \`${envName}\` (secret \`${secretName}\`, key \`${key}\`) → file \`${SECRET_ROOT}/${secretName}/${key}\`, env \`${envName}_FILE\` points to it` });
          result.warnings.push(`${kind}/${name} container \`${cname}\`: the app must read \`${envName}_FILE\` (or the file directly). Anything that reads \`${envName}\` from the environment will now see nothing.`);
        }
        const existing = new Set(kept.map((k: any) => (isMap(k) ? k.get("name") : undefined)));
        const seq = doc.createNode([]) as YAMLSeq;
        for (const k of kept) seq.add(k);
        for (const a of added) if (!existing.has(a.name)) seq.add(doc.createNode(a));
        if (seq.items.length) c.set("env", seq);
        else c.delete("env");
      }

      const envFrom = c.get("envFrom", true);
      if (isSeq(envFrom)) {
        const keep = envFrom.items.filter((i) => !(isMap(i) && i.has("secretRef")));
        for (const i of envFrom.items) {
          if (isMap(i) && i.has("secretRef")) {
            const ref = i.get("secretRef") as YAMLMap;
            const secretName = String(ref.get("name"));
            mount(secretName, ref.get("optional") === true);
            result.changes.push({ rule: "CIS-4.4.1", workload: name, kind, description: `container \`${cname}\`: envFrom secretRef \`${secretName}\` → every key mounted as a file under \`${SECRET_ROOT}/${secretName}/\`` });
            result.warnings.push(`${kind}/${name} container \`${cname}\`: envFrom removed; the app must read each key from \`${SECRET_ROOT}/${secretName}/<KEY>\`.`);
          }
        }
        if (keep.length) c.set("envFrom", doc.createNode(keep.map((k) => (k as any).toJSON?.() ?? k)));
        else c.delete("envFrom");
      }
    }
  }
}
