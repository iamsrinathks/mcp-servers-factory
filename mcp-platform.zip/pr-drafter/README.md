# audit-guard-pr-drafter

When Audit-Guard denies a workload (CIS 4.4.1 secretKeyRef, CIS 4.1.5 automountServiceAccountToken), this service opens a **draft pull request** against the owning team's repo with the minimal manifest fix. **It never merges, never approves, never writes `AuditException`, never reads Secrets.** A person reviews and merges; Config Sync then deploys.

```
Audit-Guard webhook ──JSON log line──▶ Cloud Logging ──sink──▶ Pub/Sub ──push (OIDC)──▶ pr-drafter
                                                                                            │
                Backstage catalog (namespace → repo, owner, Jira) ◀────────────────────────┤
                GitHub App (repo-scoped token; branch + draft PR) ◀────────────────────────┘
```

The fix is **deterministic code, not an LLM**: it edits only the matching workload's document (comments and other documents stay byte-identical), then re-runs the same checks Audit-Guard enforces on its own output and aborts if anything would still be denied.

| Rule | Change | What the reviewer must verify (printed in the PR) |
|---|---|---|
| CIS-4.1.5 | `automountServiceAccountToken: false` | The app doesn't call the Kubernetes API |
| CIS-4.4.1 `env.secretKeyRef` | env entry removed, `<NAME>_FILE` pointing at `/etc/secrets/<secret>/<key>`, read-only volume + mount | The app can read the value from a file |
| CIS-4.4.1 `envFrom.secretRef` | whole-secret file mount | Every key is now a file, not a variable |

Helm/Go-templated files are skipped (flagged in logs). Apps that can't read files need a human, or an `AuditException`, not this tool.

## Try it offline (no GitHub, no cluster)

```bash
npm install && npm test
npm run drill -- examples/payment-service.yaml --workload payment-service --namespace team-a
```

## Guardrails (all enforced in code, all tested)

- `DRY_RUN=true` by default: computes the diff and PR body, logs them, creates nothing.
- Only `PILOT_NAMESPACES`; only repos owned by `ALLOWED_REPO_OWNERS`; owner must resolve unambiguously in Backstage.
- One open PR per workload+rules (deterministic branch name; concurrent duplicates collapse); `MAX_PRS_PER_REPO_PER_DAY` (3); `MAX_DIFF_LINES` (150); ≤3 files; `MAX_FILES_SCANNED`.
- Pub/Sub push verified: Google OIDC token, issuer, audience, `email == PUBSUB_INVOKER_SA`, `email_verified`. Cannot be disabled when `NODE_ENV=production`.
- Bad messages are acked (no poison loop); transient errors (GitHub/Backstage down) return 500 so Pub/Sub retries, then dead-letters.
- GitHub token is minted per repo with `contents:write`, `pull_requests:write`, `metadata:read` only. There is no merge call in the code.

## Setup

**1. Audit-Guard must emit one structured line per denial** (in `server.py`, where it returns the denial). Legacy text lines are also parsed, but structured is reliable:

```python
import json, sys
def log_denial(req, rules):
    print(json.dumps({"event": "admission_denied", "namespace": req.namespace,
        "workload": req.name, "kind": req.kind, "rules": rules,
        "requestUid": req.uid}), file=sys.stdout, flush=True)
```
Use the *owning workload* name if you have it (Deployment, not the Pod hash); otherwise the drafter strips up to two hash suffixes.

**2. Log sink → Pub/Sub → push subscription**

```bash
gcloud pubsub topics create audit-guard-denials
gcloud pubsub topics create audit-guard-denials-dlq
gcloud logging sinks create audit-guard-denials \
  pubsub.googleapis.com/projects/PROJECT/topics/audit-guard-denials \
  --log-filter='resource.type="k8s_container" AND resource.labels.namespace_name="audit-guard" AND jsonPayload.event="admission_denied"'
# grant the sink's writer identity roles/pubsub.publisher on the topic (printed by the command above)

gcloud iam service-accounts create pubsub-invoker
gcloud pubsub subscriptions create audit-guard-denials-push --topic audit-guard-denials \
  --push-endpoint=https://SERVICE_URL/pubsub \
  --push-auth-service-account=pubsub-invoker@PROJECT.iam.gserviceaccount.com \
  --push-auth-token-audience=SERVICE_URL/pubsub \
  --ack-deadline=60 --min-retry-delay=10s --max-retry-delay=600s \
  --dead-letter-topic=audit-guard-denials-dlq --max-delivery-attempts=5
# for Cloud Run also grant pubsub-invoker roles/run.invoker on the service
```
`PUBSUB_AUDIENCE` must equal the audience above. Alert on the DLQ having messages.

**3. GitHub App** (org-owned): permissions Contents RW, Pull requests RW, Metadata R; install on the pilot repos only; store the private key in Secret Manager. Create the label `audit-guard-remediation` (the drafter uses it for the daily cap). Add branch protection / CODEOWNERS so the PR still needs the owning team's approval.

**4. Backstage annotations** (assumed conventions, change `src/backstage.ts` if yours differ). Each component needs: `backstage.io/kubernetes-namespace`, `github.com/project-slug` (`org/repo`), optionally `backstage.io/kubernetes-id` (to disambiguate several components per namespace; if several exist and none matches, the drafter refuses rather than guess), `jira/project-key`, `audit-guard/manifest-path` (restrict scanning to a folder). A read-only catalog token goes in `BACKSTAGE_TOKEN`.

**5. Deploy:** `deploy/cloudrun.yaml` (recommended) or `deploy/gke.yaml`. Build with `docker build -t REGISTRY/audit-guard-pr-drafter:0.1.0 .`

## Rollout

1. `DRY_RUN=true`, one pilot namespace. Read the `drafter_outcome` logs for a week: are the diffs what an engineer would write? Are owners resolving?
2. Flip `DRY_RUN=false` for that namespace. Watch acceptance/rejection of the PRs.
3. Add namespaces gradually. Keep the caps.

## Not verified yet

Built and tested against fakes only (26 tests): never run against real GitHub, Backstage, Pub/Sub, or a built container image. Backstage annotation names, the GitHub search-based cap, and the Cloud Logging payload shape should be confirmed in your environment during the dry-run.
