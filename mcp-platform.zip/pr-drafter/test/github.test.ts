import { exportPKCS8, generateKeyPair } from "jose";
import { describe, expect, it } from "vitest";
import { loadConfig } from "../src/config.js";
import { createGitHub } from "../src/github.js";

describe("GitHub App client", () => {
  it("mints a repo-scoped, least-privilege installation token and opens DRAFT PRs", async () => {
    const { privateKey } = await generateKeyPair("RS256", { extractable: true });
    const pem = await exportPKCS8(privateKey);
    const cfg = loadConfig({ BACKSTAGE_URL: "https://b.example.com", PILOT_NAMESPACES: "a", ALLOWED_REPO_OWNERS: "acme", PUBSUB_VERIFY: "false", DRY_RUN: "false", GITHUB_APP_ID: "42", GITHUB_APP_PRIVATE_KEY: pem });
    const seen: { url: string; method?: string; body?: any; auth?: string }[] = [];
    const f = (async (url: string, init: any = {}) => {
      seen.push({ url, method: init.method, body: init.body ? JSON.parse(init.body) : undefined, auth: init.headers?.authorization });
      if (url.endsWith("/installation")) return new Response(JSON.stringify({ id: 9 }));
      if (url.endsWith("/access_tokens")) return new Response(JSON.stringify({ token: "inst-token", expires_at: new Date(Date.now() + 3600_000).toISOString() }));
      if (url.endsWith("/pulls")) return new Response(JSON.stringify({ html_url: "https://gh/pr/1", number: 1 }));
      return new Response("{}");
    }) as unknown as typeof fetch;
    const gh = createGitHub(cfg, f);
    await gh.createPr({ owner: "acme", name: "payment" }, { title: "t", body: "b", head: "h", base: "main", labels: ["l"] });

    const tokenReq = seen.find((s) => s.url.endsWith("/access_tokens"))!;
    expect(tokenReq.body).toEqual({ repositories: ["payment"], permissions: { contents: "write", pull_requests: "write", metadata: "read" } });
    const pr = seen.find((s) => s.url.endsWith("/pulls"))!;
    expect(pr.body.draft).toBe(true);
    expect(pr.auth).toBe("Bearer inst-token");
    expect(seen.some((s) => /merge/.test(s.url))).toBe(false); // there is no merge call anywhere
  });
});
