import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { candidateNames, parseDenial } from "../src/events.js";
import { residualViolations } from "../src/drafter.js";
import { remediateManifest } from "../src/remediate.js";

const example = readFileSync(new URL("../examples/payment-service.yaml", import.meta.url), "utf8");
const T = { names: ["payment-service"], namespace: "team-a", rules: ["CIS-4.4.1", "CIS-4.1.5"] as ("CIS-4.4.1" | "CIS-4.1.5")[] };

describe("remediateManifest", () => {
  const r = remediateManifest(example, T);

  it("fixes both rules and the result passes the webhook's own checks", () => {
    expect(r.changed).toBe(true);
    expect(residualViolations(r.text, T.names, T.rules)).toEqual([]);
    expect(r.text).toContain("automountServiceAccountToken: false");
    expect(r.text).toContain("DATABASE_PASSWORD_FILE");
    expect(r.text).toContain("value: /etc/secrets/db-credentials/password");
    expect(r.text).not.toContain("secretKeyRef");
    expect(r.text).not.toContain("secretRef");
  });

  it("changes nothing else: comments kept, other documents byte-identical", () => {
    expect(r.text).toContain("- name: LOG_LEVEL # keep me");
    expect(r.text.startsWith(example.slice(0, example.indexOf("apiVersion: apps/v1")))).toBe(true); // ConfigMap doc untouched
    expect(r.text).toContain("configMapRef:"); // unrelated envFrom entry survives
  });

  it("is idempotent", () => {
    const again = remediateManifest(r.text, T);
    expect(again.changed).toBe(false);
  });

  it("warns about the behaviour changes a human must verify", () => {
    const w = r.warnings.join("\n");
    expect(w).toMatch(/Kubernetes API/);
    expect(w).toMatch(/DATABASE_PASSWORD_FILE/);
  });

  it("does not create an empty env/envFrom key when everything was a secret", () => {
    const src = `apiVersion: v1
kind: Pod
metadata: { name: p }
spec:
  automountServiceAccountToken: false
  containers:
    - name: a
      image: x
      env:
        - name: T
          valueFrom: { secretKeyRef: { name: s, key: k } }
      envFrom:
        - secretRef: { name: s2 }
`;
    const out = remediateManifest(src, { names: ["p"], namespace: "n", rules: ["CIS-4.4.1"] });
    expect(out.text).not.toMatch(/envFrom:/);
    expect(residualViolations(out.text, ["p"], ["CIS-4.4.1"])).toEqual([]);
  });

  it("reuses an existing volume/mount instead of duplicating, and covers initContainers", () => {
    const src = `apiVersion: apps/v1
kind: StatefulSet
metadata: { name: db }
spec:
  template:
    spec:
      automountServiceAccountToken: false
      initContainers:
        - name: init
          image: x
          env: [{ name: A, valueFrom: { secretKeyRef: { name: s, key: a } } }]
      containers:
        - name: main
          image: x
          env: [{ name: B, valueFrom: { secretKeyRef: { name: s, key: b } } }]
`;
    const out = remediateManifest(src, { names: ["db"], namespace: "n", rules: ["CIS-4.4.1"] });
    expect(out.text.match(/secretName: s\b/g)).toHaveLength(1); // one volume shared by both containers
    expect(out.text.match(/mountPath: \/etc\/secrets\/s/g)).toHaveLength(2); // one mount per container
    expect(residualViolations(out.text, ["db"], ["CIS-4.4.1"])).toEqual([]);
  });

  it("handles CronJob pod specs", () => {
    const src = `apiVersion: batch/v1
kind: CronJob
metadata: { name: nightly }
spec:
  schedule: "0 1 * * *"
  jobTemplate:
    spec:
      template:
        spec:
          containers: [{ name: c, image: x }]
`;
    const out = remediateManifest(src, { names: ["nightly"], namespace: "n", rules: ["CIS-4.1.5"] });
    expect(out.changed).toBe(true);
    expect(out.text).toContain("automountServiceAccountToken: false");
  });

  it("refuses Helm templates and mismatched namespaces", () => {
    const tpl = remediateManifest("kind: Deployment\nmetadata:\n  name: {{ .Values.name }}\n", T);
    expect(tpl.changed).toBe(false);
    expect(tpl.skipped[0]).toMatch(/template/);
    const other = remediateManifest(example.replace("namespace: team-a", "namespace: team-z"), T);
    expect(other.changed).toBe(false);
  });

  it("preserves unindented-sequence style so the diff stays small", () => {
    const src = `apiVersion: v1
kind: Pod
metadata:
  name: p
spec:
  containers:
  - name: a
    image: x
`;
    const out = remediateManifest(src, { names: ["p"], namespace: "n", rules: ["CIS-4.1.5"] });
    expect(out.text).toContain("  containers:\n  - name: a");
    expect(out.text.split("\n").length - src.split("\n").length).toBeLessThanOrEqual(1);
  });
});

describe("events", () => {
  it("parses structured, log-entry-wrapped and legacy denials; ignores noise", () => {
    const s = { event: "admission_denied", namespace: "team-a", workload: "pay", rules: ["CIS-4.4.1"] };
    expect(parseDenial(s)?.workload).toBe("pay");
    expect(parseDenial({ jsonPayload: s, timestamp: "t" })?.timestamp).toBe("t");
    const legacy = parseDenial({ textPayload: "Denied admission for team-a/pay-7d9f-x2k: DENIED by Audit-Guard [CIS-4.4.1] [CIS-4.1.5]" });
    expect(legacy).toMatchObject({ namespace: "team-a", workload: "pay-7d9f-x2k", rules: ["CIS-4.4.1", "CIS-4.1.5"] });
    expect(parseDenial({ hello: "world" })).toBeNull();
    expect(parseDenial(null)).toBeNull();
  });
  it("derives deployment names from pod names", () => {
    expect(candidateNames("payment-7d9f8-x2k4q")).toEqual(["payment-7d9f8-x2k4q", "payment-7d9f8", "payment"]);
  });
});
