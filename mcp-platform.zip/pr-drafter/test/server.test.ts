import type { AddressInfo } from "node:net";
import { afterEach, describe, expect, it } from "vitest";
import { createLogger } from "../src/logger.js";
import { createApp } from "../src/server.js";
import type { Drafter } from "../src/drafter.js";

let close: (() => Promise<void>) | undefined;
afterEach(async () => void (await close?.(), (close = undefined)));

async function start(handle: Drafter["handle"], verifyOk = true) {
  const drafter = { handle } as Drafter;
  const app = createApp({ drafter, log: createLogger("error", () => {}), verify: async () => { if (!verifyOk) throw new Error("no"); } });
  const s = app.listen(0, "127.0.0.1");
  await new Promise((r) => s.once("listening", r));
  close = () => new Promise((r) => s.close(() => r()));
  const url = `http://127.0.0.1:${(s.address() as AddressInfo).port}/pubsub`;
  const send = (data: unknown) => fetch(url, { method: "POST", headers: { "content-type": "application/json", authorization: "Bearer x" }, body: JSON.stringify({ message: { messageId: "1", data: Buffer.from(typeof data === "string" ? data : JSON.stringify(data)).toString("base64") } }) });
  return { send, url };
}
const denial = { event: "admission_denied", namespace: "team-a", workload: "pay", rules: ["CIS-4.4.1"] };

describe("Pub/Sub push endpoint", () => {
  it("rejects unauthenticated callers with 401 and never calls the drafter", async () => {
    let called = false;
    const { send } = await start(async () => ((called = true), { status: "skipped", reason: "x" }), false);
    expect((await send(denial)).status).toBe(401);
    expect(called).toBe(false);
  });
  it("acks (200) garbage and non-denial messages so they are never redelivered", async () => {
    let n = 0;
    const { send } = await start(async () => (n++, { status: "skipped", reason: "x" }));
    expect((await send("not json {")).status).toBe(200);
    expect((await send({ hello: 1 })).status).toBe(200);
    expect(n).toBe(0);
  });
  it("acks every drafter outcome, but returns 500 on exceptions so Pub/Sub retries", async () => {
    const ok = await start(async () => ({ status: "error", reason: "validation_failed" }));
    expect((await ok.send(denial)).status).toBe(200);
    await close?.();
    const bad = await start(async () => { throw new Error("github 503"); });
    expect((await bad.send(denial)).status).toBe(500);
  });
});
