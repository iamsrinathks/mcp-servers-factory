import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import type { OwnerInfo, OwnerResolver } from "../src/backstage.js";
import { createBackstageResolver } from "../src/backstage.js";
import { loadConfig } from "../src/config.js";
import { Drafter } from "../src/drafter.js";
import type { DenialEvent } from "../src/events.js";
import type { GitHub } from "../src/github.js";
import { createLogger } from "../src/logger.js";

const manifest = readFileSync(new URL("../examples/payment-service.yaml", import.meta.url), "utf8");
const baseEnv = { BACKSTAGE_URL: "https://backstage.example.com", PILOT_NAMESPACES: "team-a", ALLOWED_REPO_OWNERS: "acme", PUBSUB_VERIFY: "false" };
const event: DenialEvent = { namespace: "team-a", workload: "payment-service", rules: ["CIS-4.4.1", "CIS-4.1.5"] };
const owner: OwnerInfo = { component: "payment-service", repo: { owner: "acme", name: "payment" }, ownerRef: "group:default/payments", jiraProject: "SVC" };

function fakeGh(files: Record<string, string>, over: Partial<GitHub> = {}) {
  const calls: string[] = [];
  const created: any[] = [];
  const gh: GitHub = {
    getDefaultBranch: async () => ({ name: "main", sha: "base" }),
    listTree: async () => Object.keys(files).map((path) => ({ path, type: "blob", size: files[path]!.length })),
    getFile: async (_r, path) => ({ content: files[path]!, sha: "blob-" + path }),
    findOpenPr: async () => null,
    countRecentPrs: async () => 0,
    createBranch: async (_r, b) => void calls.push("branch:" + b),
    putFile: async (_r, a) => void calls.push("put:" + a.path),
    createPr: async (_r, a) => (created.push(a), calls.push("pr"), { url: "https://github.com/acme/payment/pull/7", number: 7 }),
    ...over,
  };
  return { gh, calls, created };
}
const resolver = (o: OwnerInfo | null): OwnerResolver => ({ resolve: async () => o });
const mk = (env: Record<string, string>, gh: GitHub, o: OwnerInfo | null = owner) => new Drafter({ cfg: loadConfig({ ...baseEnv, ...env }), owners: resolver(o), gh, log: createLogger("error", () => {}) });

describe("guardrails", () => {
  it("ignores namespaces outside the pilot", async () => {
    const { gh } = fakeGh({});
    expect(await mk({}, gh).handle({ ...event, namespace: "team-b" })).toMatchObject({ status: "skipped", reason: "namespace_not_in_pilot" });
  });
  it("skips when Backstage cannot resolve an owner, or the repo owner is not allowed", async () => {
    const { gh } = fakeGh({});
    expect(await mk({}, gh, null).handle(event)).toMatchObject({ reason: "owner_unresolved" });
    expect(await mk({}, gh, { ...owner, repo: { owner: "evil", name: "x" } }).handle(event)).toMatchObject({ reason: "repo_owner_not_allowed" });
  });
  it("does not open a second PR for the same workload, and respects the daily cap", async () => {
    expect(await mk({}, fakeGh({}, { findOpenPr: async () => ({ url: "u" }) }).gh).handle(event)).toMatchObject({ reason: "pr_already_open" });
    expect(await mk({ MAX_PRS_PER_REPO_PER_DAY: "3" }, fakeGh({}, { countRecentPrs: async () => 3 }).gh).handle(event)).toMatchObject({ reason: "repo_daily_cap_reached" });
  });
  it("refuses live mode without GitHub App credentials", () => {
    expect(() => loadConfig({ ...baseEnv, DRY_RUN: "false" })).toThrow(/GITHUB_APP_ID/);
    expect(() => loadConfig({ ...baseEnv, PILOT_NAMESPACES: "" })).toThrow(/PILOT_NAMESPACES/);
  });
  it("skips Helm-templated files and unknown repos of manifests with a useful reason", async () => {
    const r = await mk({}, fakeGh({ "chart/deploy.yaml": "name: payment-service\n{{ .Values.x }}" }).gh).handle(event);
    expect(r).toMatchObject({ status: "skipped", reason: "no_fixable_manifest_found" });
  });
  it("aborts when the diff is larger than the cap", async () => {
    expect(await mk({ MAX_DIFF_LINES: "3" }, fakeGh({ "k8s/deploy.yaml": manifest }).gh).handle(event)).toMatchObject({ reason: "diff_too_large" });
  });
});

describe("happy paths", () => {
  it("dry-run returns the diff and creates nothing (default mode)", async () => {
    const { gh, calls } = fakeGh({ "k8s/deploy.yaml": manifest, "k8s/other.yaml": "kind: ConfigMap\nmetadata: {name: x}\n" });
    const r = await mk({}, gh).handle(event);
    expect(r).toMatchObject({ status: "dry_run", files: ["k8s/deploy.yaml"] });
    if (r.status === "dry_run") {
      expect(r.diff).toContain("+      automountServiceAccountToken: false");
      expect(r.body).toContain("Check before you merge");
    }
    expect(calls).toEqual([]);
  });
  it("live mode opens a DRAFT PR from a new branch with the label, and never merges", async () => {
    const { gh, calls, created } = fakeGh({ "k8s/deploy.yaml": manifest });
    const r = await mk({ DRY_RUN: "false", GITHUB_APP_ID: "1", GITHUB_APP_PRIVATE_KEY: "k" }, gh).handle(event);
    expect(r).toMatchObject({ status: "pr_opened", url: expect.stringContaining("/pull/7") });
    expect(calls).toEqual(["branch:audit-guard/fix-team-a-payment-service-cis-4-4-1-cis-4-1-5", "put:k8s/deploy.yaml", "pr"]);
    expect(created[0].labels).toEqual(["audit-guard-remediation"]);
    expect(created[0].base).toBe("main");
    expect(created[0].body).toContain("A person must review and merge");
  });
  it("collapses concurrent duplicate deliveries", async () => {
    const slow = fakeGh({ "k8s/deploy.yaml": manifest }, { findOpenPr: async () => (await new Promise((r) => setTimeout(r, 30)), null) });
    const d = mk({}, slow.gh);
    const [a, b] = await Promise.all([d.handle(event), d.handle(event)]);
    expect([a.status, b.status].sort()).toEqual(["dry_run", "skipped"]);
  });
});

describe("backstage resolver", () => {
  const cfg = loadConfig(baseEnv);
  const entity = (name: string, id: string, slug = "acme/" + name) => ({ metadata: { name, annotations: { "backstage.io/kubernetes-id": id, "github.com/project-slug": slug } }, spec: { owner: "group:default/t" } });
  const fetchWith = (items: any[]) => (async () => new Response(JSON.stringify({ items }), { status: 200 })) as unknown as typeof fetch;

  it("picks the component whose kubernetes-id matches; refuses ambiguity", async () => {
    const r = createBackstageResolver(cfg, fetchWith([entity("a", "billing"), entity("b", "payment-service")]));
    expect((await r.resolve("team-a", "payment-service-7d9f-x"))?.repo).toEqual({ owner: "acme", name: "b" });
    const amb = createBackstageResolver(cfg, fetchWith([entity("a", "x"), entity("b", "y")]));
    expect(await amb.resolve("team-a", "payment-service")).toBeNull();
  });
  it("rejects malformed slugs and propagates catalog outages as errors (so Pub/Sub retries)", async () => {
    expect(await createBackstageResolver(cfg, fetchWith([entity("a", "payment-service", "../../etc")])).resolve("team-a", "payment-service")).toBeNull();
    const down = (async () => new Response("", { status: 503 })) as unknown as typeof fetch;
    await expect(createBackstageResolver(cfg, down).resolve("team-a", "x")).rejects.toThrow(/503/);
  });
});
