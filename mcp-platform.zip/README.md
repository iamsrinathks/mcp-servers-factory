# Audit-Guard tooling: MCP server, MCP gateway, PR drafter, exception triage

Tooling for the platform team's Audit-Guard rollout (a validating webhook enforcing CIS 4.4.1 and 4.1.5 on a shared multi-tenant GKE cluster, with GitOps via Config Sync and Backstage). Read **[docs/PROBLEM_STATEMENT.md](docs/PROBLEM_STATEMENT.md)** first for what we are solving and why.

| Component | Dir | Solves | Talks to | Writes anything? |
|---|---|---|---|---|
| Read-only MCP server | `server/` | "Why was I denied? What's the state?" | Kubernetes API (get/list, no Secrets) | No |
| MCP gateway | `gateway/` | Safe, authenticated, rate-limited access to MCP servers | MCP backends | No |
| PR drafter | `pr-drafter/` | Hand-writing the same manifest fix | Pub/Sub, Backstage, GitHub | Draft PRs only |
| Exception triage | `exception-triage/` | Slow, inconsistent waiver review | GitHub, Jira | One PR comment only |

```
 engineer/AI ─▶ gateway ─▶ MCP server ─▶ cluster (read-only)
 Audit-Guard log ─▶ Pub/Sub ─▶ PR drafter ─▶ Backstage (owner) ─▶ GitHub draft PR
 AuditException PR ─▶ webhook ─▶ exception triage ─▶ Jira (ticket) + GitHub (comment)
```

Each component is an independent Node/TypeScript package with its own `package.json`, tests, Dockerfile, deploy manifests and README. They share no code (small files such as `logger.ts` are deliberately copied, to keep each one deployable alone).

## Quick start (no cluster, no Docker, no cloud accounts)

Needs Node 22+.

```bash
make install        # npm ci in all four packages
make test           # server 14, gateway 16, pr-drafter 26, exception-triage 18 tests
make dev-up         # fake IdP :4000, MCP server :8080 (fixture data), gateway :3000
make smoke          # MCP client → gateway → server as platform on-call and as a tenant
make dev-down

cd pr-drafter && npm run drill -- examples/payment-service.yaml --workload payment-service --namespace team-a
cd exception-triage && npm run drill -- examples/bad-exception.yaml --author alice
```

## Where to read next

| You want to | Read |
|---|---|
| Understand the goal and principles | [docs/PROBLEM_STATEMENT.md](docs/PROBLEM_STATEMENT.md) |
| Work on the code as an agent/developer | [CLAUDE.md](CLAUDE.md) |
| Deploy the MCP server + gateway (localhost → sandbox → prod) | [DEPLOYMENT.md](DEPLOYMENT.md) |
| Set up the PR drafter (log sink, Pub/Sub, GitHub App, Backstage) | [pr-drafter/README.md](pr-drafter/README.md) |
| Set up exception triage (GitHub App, Jira, approvers) | [exception-triage/README.md](exception-triage/README.md) |

## Status: proof of concept

Done and locally verified: all four components build, typecheck and pass their tests; the server and gateway were also exercised end to end on localhost (`make smoke`).

**Not done, be honest about it:**
- Docker images have never been built; Kubernetes manifests have never been applied.
- Nothing has run against a real cluster, IdP, Backstage, GitHub, Jira or Pub/Sub. Tests use fakes.
- The gateway lacks OAuth discovery metadata (needed for browser-style SSO in VS Code) and mTLS to backends.
- Assumptions to verify in your environment: the `AuditException` CRD group/version/fields, Backstage annotation names, the Cloud Logging payload of Audit-Guard denials, and the structured `admission_denied` log line the PR drafter expects (snippet in `pr-drafter/README.md`; Audit-Guard's `server.py` must be changed to emit it).

Suggested path: sandbox cluster first; PR drafter and triage in `DRY_RUN=true` on one pilot namespace/repo; compare their output with what humans would have done before enabling anything that writes.
