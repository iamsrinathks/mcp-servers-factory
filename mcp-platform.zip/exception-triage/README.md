# audit-guard-exception-triage

A reviewer aid for `AuditException` pull requests. When someone opens a PR that adds or changes a waiver, it checks the request against policy and posts **one comment** (updated on every push) listing what is wrong, what needs judgement, and what was verified. It can only read the repo and comment: **it cannot approve, request changes, push, merge, or touch the cluster.** The comment says so.

```
GitHub PR event ──webhook (HMAC)──▶ exception-triage ──▶ reads PR files + base branch history (GitHub App, read)
                                          │                reads ticket status (Jira, one GET)
                                          └──▶ one PR comment (issues:write)
```

The checks are deterministic code, so results are explainable and testable. There is no LLM in the loop, and this is intentional: a model cannot tell whether a workload *really* needs a waiver, and a confident-sounding "approve" from one is the wrong failure mode for a control. (If you later want prose like "ask them about X", add it as an extra, clearly-labelled section; keep the verdict deterministic.)

| Check | Result |
|---|---|
| Whole-namespace or wildcard scope (no/`*` `workloadName`) | block |
| Unknown `ruleId`; missing namespace; non-tenant namespace | block / warn |
| `validDate` invalid or in the past | block |
| `validDate` in the future | warn (inert until then); today: note that it expires 00:00 UTC |
| `approvedBy` missing, not on the approver list, or equals the PR author | block |
| Reason empty (block), shorter than `MIN_REASON_CHARS` or a filler word (warn) | block / warn |
| Ticket missing, wrong format, not found, or already Done/Closed | block |
| Ticket status not checked (Jira not configured or down) | info / note |
| Repeat waivers for the same namespace+rule in `REPEAT_WINDOW_DAYS` (≥2 warn, ≥4 block) | warn / block |
| Rule listed in `SECURITY_SIGNOFF_RULES` | warn |

Verdicts: **blocking problems** / **needs your judgement** / **no problems found**. Missing evidence is never treated as OK.

## Try it offline

```bash
npm install && npm test
npm run drill -- examples/bad-exception.yaml --author alice
npm run drill -- examples/good-exception.yaml --author alice
```

## Setup

1. **GitHub App** (org-owned): Contents R, Pull requests R, Issues W (this is what PR comments use), Metadata R; subscribe to **Pull request** events; webhook URL `https://SERVICE_URL/webhook` with a secret (`GITHUB_WEBHOOK_SECRET`). Install on the platform GitOps repo only.
2. **Jira** (optional but recommended): a read-only service account that can browse the relevant projects; `JIRA_URL`, `JIRA_USER`, `JIRA_TOKEN`.
3. **Config**: `WATCHED_REPOS`, `EXCEPTIONS_PATH_PREFIX`, `APPROVERS` (must match what people write in `spec.approvedBy`), `TENANT_NAMESPACE_PREFIXES`. The service refuses to start without approvers, repos, and a webhook secret.
4. **Deploy** `deploy/cloudrun.yaml` (or adapt `../pr-drafter/deploy/gke.yaml`). `docker build -t REGISTRY/audit-guard-exception-triage:0.1.0 .`
5. **Enforce the human step in GitHub, not here**: branch protection requiring a CODEOWNERS review from the platform approvers on the exceptions path. This tool is advice; the branch protection is the control.

## Rollout

`DRY_RUN=true` first: read the `triage_result` logs against real PRs and compare with what your approvers decided. Then flip `DRY_RUN=false` on the one repo.

## Limits to know about

- **Repeat detection only sees waivers still in the base branch's files.** If your process deletes expired `AuditException` files, history is invisible to it (it cannot count what was removed). Keep them, or add a git-log based counter.
- It doesn't check that the workload exists or is actually being denied. An MCP-based check (`explain_denial`, `list_audit_exceptions`) is a natural extension, but would put cluster reads into this service.
- Fork PRs are not reviewed. More than 20 YAML files in one PR: only the first 20 are analysed (and it says so).
- The webhook is acknowledged before analysis finishes; if the service is down, use "Redeliver" in the GitHub App's advanced settings.
- Built and tested against fakes only (18 tests); never run against real GitHub, Jira, or a container image. The `AuditException` field names (`ruleId`, `workloadName`, `validDate`, `jiraTicket`, `approvedBy`, `reason`) come from the Audit-Guard MCP tool; verify against your CRD.
