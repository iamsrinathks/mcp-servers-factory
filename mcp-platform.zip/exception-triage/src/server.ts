import { createHmac, timingSafeEqual } from "node:crypto";
import express from "express";
import type { Config } from "./config.js";
import type { Logger } from "./logger.js";
import type { Triage } from "./triage.js";

const ACTIONS = new Set(["opened", "synchronize", "reopened", "ready_for_review"]);

export function verifySignature(secret: string, raw: Buffer, header: string | undefined): boolean {
  if (!header?.startsWith("sha256=")) return false;
  const want = createHmac("sha256", secret).update(raw).digest();
  const got = Buffer.from(header.slice(7), "hex");
  return got.length === want.length && timingSafeEqual(got, want);
}

export function createApp(d: { cfg: Config; triage: Triage; log: Logger }) {
  const { cfg, triage, log } = d;
  const watched = new Set(cfg.WATCHED_REPOS.map((r) => r.toLowerCase()));
  const app = express();
  app.disable("x-powered-by");
  app.get("/healthz", (_q, r) => void r.send("ok"));

  app.post("/webhook", express.raw({ type: "*/*", limit: "1mb" }), (req, res) => {
    const raw = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
    if (!verifySignature(cfg.GITHUB_WEBHOOK_SECRET!, raw, req.header("x-hub-signature-256"))) {
      log.warn("webhook_bad_signature", {});
      return void res.status(401).send("bad signature");
    }
    if (req.header("x-github-event") !== "pull_request") return void res.status(202).send("ignored");
    let p: any;
    try {
      p = JSON.parse(raw.toString("utf8"));
    } catch {
      return void res.status(400).send("bad json");
    }
    const full = String(p?.repository?.full_name ?? "");
    if (!ACTIONS.has(p?.action) || !watched.has(full.toLowerCase()) || !Number.isInteger(p?.number)) return void res.status(202).send("ignored");
    // GitHub gives webhooks ~10s; analysis can take longer, so answer now and work in the background.
    res.status(202).send("accepted");
    const [owner, name] = full.split("/") as [string, string];
    triage
      .handle({ owner, name }, p.number)
      .then((o) => log.info("triage_outcome", { repo: full, pr: p.number, ...o, body: undefined }))
      .catch((e) => log.error("triage_failed", { repo: full, pr: p.number, err: String(e) }));
  });
  return app;
}
