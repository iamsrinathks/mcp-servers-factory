import { parseAllDocuments } from "yaml";

export const SUPPORTED_RULES = ["CIS-4.4.1", "CIS-4.1.5"] as const;

export interface ExceptionRequest {
  path: string;
  name: string;
  namespace?: string;
  ruleId?: string;
  workloadName?: string;
  validDate?: string;
  jiraTicket?: string;
  approvedBy?: string;
  reason?: string;
}

/** Extract every AuditException document from a (multi-doc) YAML file. Never throws on bad YAML. */
export function parseExceptions(path: string, text: string): { items: ExceptionRequest[]; errors: string[] } {
  const items: ExceptionRequest[] = [];
  const errors: string[] = [];
  if (/\{\{.*\}\}/.test(text)) return { items, errors: [`${path}: templated file, cannot be analysed`] };
  for (const doc of parseAllDocuments(text)) {
    if (doc.errors.length) {
      errors.push(`${path}: ${doc.errors[0]!.message}`);
      continue;
    }
    const js = doc.toJS() as any;
    if (js?.kind !== "AuditException") continue;
    const s = js.spec ?? {};
    const str = (v: unknown) => (typeof v === "string" ? v : v == null ? undefined : String(v));
    items.push({
      path,
      name: str(js.metadata?.name) ?? "(unnamed)",
      namespace: str(js.metadata?.namespace),
      ruleId: str(s.ruleId),
      workloadName: str(s.workloadName),
      validDate: str(s.validDate),
      jiraTicket: str(s.jiraTicket),
      approvedBy: str(s.approvedBy),
      reason: str(s.reason),
    });
  }
  return { items, errors };
}

export const isRecordLike = (o: unknown): o is Record<string, unknown> => typeof o === "object" && o !== null;
