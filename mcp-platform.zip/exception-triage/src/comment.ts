import type { ExceptionRequest } from "./model.js";
import type { Finding, Verdict } from "./policy.js";

export const MARKER = "<!-- audit-guard-exception-triage -->";

const HEAD: Record<Verdict, string> = {
  do_not_approve: "🛑 Automated checks found blocking problems",
  needs_human_judgement: "⚠️ Automated checks found points that need your judgement",
  no_issues_found: "✅ Automated checks found no problems",
};
const ICON = { block: "🛑", warn: "⚠️", info: "ℹ️" } as const;

export interface Analysed {
  request: ExceptionRequest;
  findings: Finding[];
  verdict: Verdict;
}

/** One comment per PR, updated in place. Deliberately worded as a checklist for a human, never as an approval. */
export function renderComment(items: Analysed[], errors: string[], sha: string): string {
  const worst: Verdict = items.some((i) => i.verdict === "do_not_approve") ? "do_not_approve" : items.some((i) => i.verdict === "needs_human_judgement") ? "needs_human_judgement" : "no_issues_found";
  const out = [MARKER, `### ${HEAD[worst]}`, ""];
  for (const it of items) {
    const r = it.request;
    out.push(`**${r.name}** · \`${r.ruleId ?? "?"}\` · \`${r.namespace ?? "?"}/${r.workloadName ?? "(whole namespace)"}\` · valid ${r.validDate ?? "?"} · ${r.jiraTicket ?? "no ticket"}`);
    out.push("");
    for (const f of [...it.findings].sort((a, b) => order(a) - order(b))) out.push(`- ${ICON[f.severity]} ${f.message}`);
    out.push("");
  }
  for (const e of errors) out.push(`- ⚠️ ${e}`);
  out.push(
    "---",
    "_This is an automated read-only review of the policy checks, produced from the files at commit `" + sha.slice(0, 7) + "`. It is **not an approval**: a platform approver still decides, and it re-runs on every push. It cannot see whether the workload really needs the waiver, so it does not judge that._",
  );
  return out.join("\n");
}
const order = (f: Finding) => ({ block: 0, warn: 1, info: 2 })[f.severity];
