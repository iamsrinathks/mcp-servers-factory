import type { Config } from "./config.js";
import { SUPPORTED_RULES, type ExceptionRequest } from "./model.js";

export type Severity = "block" | "warn" | "info";
export interface Finding {
  severity: Severity;
  code: string;
  message: string;
}
export type Verdict = "do_not_approve" | "needs_human_judgement" | "no_issues_found";

export interface JiraIssue {
  key: string;
  status: string;
  summary?: string;
}
export interface Evidence {
  today: string; // UTC yyyy-mm-dd
  prAuthor: string;
  /** Prior exceptions for the same namespace+rule(+workload) inside the repeat window; null = could not be determined. */
  priorCount: number | null;
  /** undefined = Jira not configured, null = ticket not found */
  jira: JiraIssue | null | undefined;
}

const GENERIC = /^(n\/?a|none|tbd|todo|test(ing)?|needed|required|urgent|asap|blocker|temporary|temp|fix|wip|see ticket|as discussed)\W*$/i;
const NS_WIDE = /^(\*|all|any|\.\*)?$/;

/**
 * Deterministic policy checks. The output is advice for the human approver; nothing here can
 * approve anything, and a missing piece of evidence is reported as a warning, never assumed OK.
 */
export function analyse(r: ExceptionRequest, ev: Evidence, cfg: Config): Finding[] {
  const f: Finding[] = [];
  const add = (severity: Severity, code: string, message: string) => f.push({ severity, code, message });

  // --- shape ---
  if (!r.namespace) add("block", "namespace_missing", "metadata.namespace is not set.");
  else if (cfg.TENANT_NAMESPACE_PREFIXES.length && !cfg.TENANT_NAMESPACE_PREFIXES.some((p) => r.namespace!.startsWith(p)))
    add("warn", "namespace_not_tenant", `\`${r.namespace}\` does not look like a tenant namespace (${cfg.TENANT_NAMESPACE_PREFIXES.join(", ")}*). Waivers for platform namespaces need a different process.`);

  if (!r.ruleId) add("block", "rule_missing", "spec.ruleId is not set.");
  else if (!(SUPPORTED_RULES as readonly string[]).includes(r.ruleId)) add("block", "rule_unknown", `Unknown ruleId \`${r.ruleId}\` (supported: ${SUPPORTED_RULES.join(", ")}).`);

  // --- scope: the narrower the better ---
  if (r.workloadName === undefined) add("block", "scope_namespace_wide", "No `workloadName`: this waives the rule for the whole namespace. Scope it to the single workload that needs it.");
  else if (NS_WIDE.test(r.workloadName.trim()) || /[*?]/.test(r.workloadName)) add("block", "scope_wildcard", `workloadName \`${r.workloadName}\` is a wildcard/empty: scope it to one workload.`);

  // --- validity window (Audit-Guard only honours a waiver whose validDate is today, UTC) ---
  if (!r.validDate || !/^\d{4}-\d{2}-\d{2}$/.test(r.validDate)) add("block", "date_invalid", `validDate \`${r.validDate ?? ""}\` is not yyyy-mm-dd.`);
  else if (r.validDate < ev.today) add("block", "date_past", `validDate ${r.validDate} is already in the past (today is ${ev.today} UTC): this waiver would never be honoured.`);
  else if (r.validDate > ev.today) add("warn", "date_future", `validDate ${r.validDate} is not today (${ev.today} UTC). The waiver is inert until then; confirm the PR should merge on that day.`);
  else add("info", "date_today", `validDate is today (${ev.today} UTC). It expires at 00:00 UTC, so merge and sync must complete before then.`);

  // --- governance ---
  if (!r.approvedBy) add("block", "approver_missing", "spec.approvedBy is not set.");
  else {
    if (!cfg.APPROVERS.map((a) => a.toLowerCase()).includes(r.approvedBy.toLowerCase()))
      add("block", "approver_not_authorised", `\`${r.approvedBy}\` is not on the platform approver list.`);
    if (r.approvedBy.toLowerCase() === ev.prAuthor.toLowerCase()) add("block", "self_approval", "approvedBy is the PR author: waivers must be approved by someone else.");
  }
  if (cfg.SECURITY_SIGNOFF_RULES.includes(r.ruleId ?? "")) add("warn", "security_signoff", `${r.ruleId} is configured to also need security sign-off.`);

  // --- justification ---
  const reason = (r.reason ?? "").trim();
  if (!reason) add("block", "reason_missing", "spec.reason is empty.");
  else if (GENERIC.test(reason) || reason.length < cfg.MIN_REASON_CHARS)
    add("warn", "reason_weak", `Reason is too thin to audit later (${reason.length} chars, minimum ${cfg.MIN_REASON_CHARS}). It should say why the workload cannot comply and what the plan to fix it is.`);

  // --- ticket ---
  if (!r.jiraTicket) add("block", "ticket_missing", "spec.jiraTicket is not set.");
  else if (!new RegExp(cfg.JIRA_KEY_REGEX).test(r.jiraTicket)) add("block", "ticket_format", `\`${r.jiraTicket}\` does not match the ticket format.`);
  else if (ev.jira === undefined) add("info", "ticket_unverified", "Jira is not configured here; ticket existence and status were not checked.");
  else if (ev.jira === null) add("block", "ticket_not_found", `${r.jiraTicket} was not found in Jira.`);
  else if (cfg.JIRA_CLOSED_STATUSES.includes(ev.jira.status.toLowerCase())) add("block", "ticket_closed", `${r.jiraTicket} is already "${ev.jira.status}": a waiver must be tied to open work.`);
  else add("info", "ticket_ok", `${r.jiraTicket} is open ("${ev.jira.status}"${ev.jira.summary ? `: ${ev.jira.summary}` : ""}).`);

  // --- history ---
  if (ev.priorCount === null) add("warn", "history_unknown", "Could not determine whether this workload has been waived before.");
  else if (ev.priorCount >= cfg.REPEAT_BLOCK_AT) add("block", "repeat_offender", `${ev.priorCount} earlier waivers for this rule in this namespace in the last ${cfg.REPEAT_WINDOW_DAYS} days. A permanent fix is overdue; a waiver is no longer the answer.`);
  else if (ev.priorCount >= cfg.REPEAT_WARN_AT) add("warn", "repeat_waiver", `${ev.priorCount} earlier waivers for this rule in this namespace in the last ${cfg.REPEAT_WINDOW_DAYS} days. Ask for a remediation plan.`);

  return f;
}

export function verdictOf(findings: Finding[]): Verdict {
  if (findings.some((x) => x.severity === "block")) return "do_not_approve";
  if (findings.some((x) => x.severity === "warn")) return "needs_human_judgement";
  return "no_issues_found";
}
