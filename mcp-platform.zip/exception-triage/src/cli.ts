// Offline drill: npm run drill -- examples/bad-exception.yaml --author alice [--today 2026-09-29] [--prior 0]
import { readFileSync } from "node:fs";
import { renderComment } from "./comment.js";
import { loadConfig } from "./config.js";
import { parseExceptions } from "./model.js";
import { analyse, verdictOf } from "./policy.js";

const args = process.argv.slice(2);
const file = args.find((a) => !a.startsWith("--"));
const opt = (n: string, d: string) => (args.includes(`--${n}`) ? args[args.indexOf(`--${n}`) + 1]! : d);
if (!file) {
  console.error("usage: drill <file.yaml> [--author login] [--today yyyy-mm-dd] [--prior N]");
  process.exit(2);
}
const cfg = loadConfig({
  WATCHED_REPOS: "x/y", APPROVERS: opt("approvers", "platform-lead,sre-oncall"), GITHUB_APP_ID: "0", GITHUB_APP_PRIVATE_KEY: "x", GITHUB_WEBHOOK_SECRET: "x",
  TENANT_NAMESPACE_PREFIXES: "team-", SECURITY_SIGNOFF_RULES: "CIS-4.4.1", ...process.env,
});
const today = opt("today", new Date().toISOString().slice(0, 10));
const { items, errors } = parseExceptions(file, readFileSync(file, "utf8"));
const analysed = items.map((request) => {
  const findings = analyse(request, { today, prAuthor: opt("author", "someone"), priorCount: Number(opt("prior", "0")), jira: undefined }, cfg);
  return { request, findings, verdict: verdictOf(findings) };
});
console.log(renderComment(analysed, errors, "0000000"));
