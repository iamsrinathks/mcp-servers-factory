import { importPKCS8, SignJWT } from "jose";
import type { Config } from "./config.js";

export interface Repo {
  owner: string;
  name: string;
}
export interface PrInfo {
  number: number;
  author: string;
  state: string;
  headSha: string;
  headRepo: string; // owner/name of the head branch's repo (forks differ from base)
  baseRef: string;
}
export interface PrFile {
  path: string;
  status: string;
}
export interface GitHub {
  getPr(r: Repo, n: number): Promise<PrInfo>;
  listPrFiles(r: Repo, n: number): Promise<PrFile[]>;
  getFile(r: Repo, path: string, ref: string): Promise<string>;
  listYamlFiles(r: Repo, ref: string): Promise<string[]>;
  upsertComment(r: Repo, n: number, marker: string, body: string): Promise<{ created: boolean }>;
}

/** GitHub App auth. The token is restricted to one repo and to read + PR-comment permissions: no way to push, approve or merge. */
export function createGitHub(cfg: Config, fetchImpl: typeof fetch = fetch): GitHub {
  const api = cfg.GITHUB_API_URL.replace(/\/$/, "");
  const tokens = new Map<string, { token: string; exp: number }>();

  const raw = (path: string, init: RequestInit & { token?: string; appJwt?: string } = {}) =>
    fetchImpl(`${api}${path}`, {
      ...init,
      headers: {
        accept: "application/vnd.github+json",
        "x-github-api-version": "2022-11-28",
        "user-agent": "audit-guard-exception-triage",
        authorization: `Bearer ${init.token ?? init.appJwt}`,
        ...(init.body ? { "content-type": "application/json" } : {}),
      },
      signal: AbortSignal.timeout(15000),
    });

  async function tokenFor(r: Repo): Promise<string> {
    const key = `${r.owner}/${r.name}`;
    const c = tokens.get(key);
    if (c && c.exp - Date.now() > 60_000) return c.token;
    const pk = await importPKCS8(cfg.GITHUB_APP_PRIVATE_KEY!.replace(/\\n/g, "\n"), "RS256");
    const now = Math.floor(Date.now() / 1000);
    const appJwt = await new SignJWT({}).setProtectedHeader({ alg: "RS256" }).setIssuer(cfg.GITHUB_APP_ID!).setIssuedAt(now - 60).setExpirationTime(now + 540).sign(pk);
    const inst = await raw(`/repos/${key}/installation`, { appJwt });
    if (!inst.ok) throw new Error(`GitHub App is not installed on ${key} (${inst.status})`);
    const { id } = (await inst.json()) as { id: number };
    const tok = await raw(`/app/installations/${id}/access_tokens`, {
      method: "POST",
      appJwt,
      body: JSON.stringify({ repositories: [r.name], permissions: { contents: "read", pull_requests: "read", issues: "write", metadata: "read" } }),
    });
    if (!tok.ok) throw new Error(`could not mint installation token (${tok.status})`);
    const j = (await tok.json()) as { token: string; expires_at: string };
    tokens.set(key, { token: j.token, exp: Date.parse(j.expires_at) });
    return j.token;
  }

  async function call<T>(r: Repo, path: string, init: RequestInit = {}): Promise<T> {
    const res = await raw(path, { ...init, token: await tokenFor(r) });
    if (!res.ok) throw new Error(`GitHub ${init.method ?? "GET"} ${path.split("?")[0]} → ${res.status}`);
    return (await res.json()) as T;
  }
  const P = (r: Repo) => `/repos/${r.owner}/${r.name}`;

  return {
    async getPr(r, n) {
      const p = await call<any>(r, `${P(r)}/pulls/${n}`);
      return { number: n, author: p.user?.login ?? "", state: p.state, headSha: p.head.sha, headRepo: p.head.repo?.full_name ?? "", baseRef: p.base.ref };
    },
    async listPrFiles(r, n) {
      const out: PrFile[] = [];
      for (let page = 1; page <= 3; page++) {
        const batch = await call<any[]>(r, `${P(r)}/pulls/${n}/files?per_page=100&page=${page}`);
        out.push(...batch.map((f) => ({ path: f.filename, status: f.status })));
        if (batch.length < 100) break;
      }
      return out;
    },
    async getFile(r, path, ref) {
      const j = await call<any>(r, `${P(r)}/contents/${path.split("/").map(encodeURIComponent).join("/")}?ref=${encodeURIComponent(ref)}`);
      if (j.encoding !== "base64" || typeof j.content !== "string") throw new Error(`unexpected content response for ${path}`);
      return Buffer.from(j.content, "base64").toString("utf8");
    },
    async listYamlFiles(r, ref) {
      const t = await call<any>(r, `${P(r)}/git/trees/${encodeURIComponent(ref)}?recursive=1`);
      return (t.tree as any[]).filter((e) => e.type === "blob" && /\.ya?ml$/i.test(e.path)).map((e) => e.path as string);
    },
    async upsertComment(r, n, marker, body) {
      const existing = (await call<any[]>(r, `${P(r)}/issues/${n}/comments?per_page=100`)).find((c) => typeof c.body === "string" && c.body.startsWith(marker) && c.user?.type === "Bot");
      if (existing) {
        if (existing.body !== body) await call(r, `${P(r)}/issues/comments/${existing.id}`, { method: "PATCH", body: JSON.stringify({ body }) });
        return { created: false };
      }
      await call(r, `${P(r)}/issues/${n}/comments`, { method: "POST", body: JSON.stringify({ body }) });
      return { created: true };
    },
  };
}
