import type { Config } from "./config.js";
import type { JiraIssue } from "./policy.js";

export interface Jira {
  /** null = not found. Throws on outages so the caller can say "unverified" instead of guessing. */
  getIssue(key: string): Promise<JiraIssue | null>;
}

/** Read-only: a single GET. Use a Jira account that can only browse the relevant projects. */
export function createJira(cfg: Config, fetchImpl: typeof fetch = fetch): Jira | undefined {
  if (!cfg.JIRA_URL || !cfg.JIRA_TOKEN) return undefined;
  const base = cfg.JIRA_URL.replace(/\/$/, "");
  const auth = cfg.JIRA_USER ? `Basic ${Buffer.from(`${cfg.JIRA_USER}:${cfg.JIRA_TOKEN}`).toString("base64")}` : `Bearer ${cfg.JIRA_TOKEN}`;
  return {
    async getIssue(key) {
      if (!/^[A-Z][A-Z0-9]+-\d+$/.test(key)) return null; // never put unvalidated text in a URL
      const res = await fetchImpl(`${base}/rest/api/3/issue/${key}?fields=status,summary`, { headers: { authorization: auth, accept: "application/json" }, redirect: "error", signal: AbortSignal.timeout(10000) });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error(`Jira → ${res.status}`);
      const j = (await res.json()) as any;
      return { key, status: String(j.fields?.status?.name ?? "unknown"), summary: j.fields?.summary };
    },
  };
}
