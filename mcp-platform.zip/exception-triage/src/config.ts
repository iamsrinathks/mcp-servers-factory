import { z } from "zod";

const bool = (d: string) => z.string().default(d).transform((v) => /^(1|true|yes)$/i.test(v));
const csv = z.string().default("").transform((v) => v.split(",").map((s) => s.trim()).filter(Boolean));

const schema = z
  .object({
    NODE_ENV: z.string().default("development"),
    PORT: z.coerce.number().int().default(8080),
    LOG_LEVEL: z.enum(["debug", "info", "warn", "error"]).default("info"),
    DRY_RUN: bool("true"), // true = analyse and log, never post the comment

    // Which repos we review, and where AuditException files live.
    WATCHED_REPOS: csv, // owner/name,owner/name
    EXCEPTIONS_PATH_PREFIX: z.string().default(""), // e.g. "exceptions/" ("" = anywhere)
    TENANT_NAMESPACE_PREFIXES: csv, // namespaces that are tenant-owned, e.g. team-,app-
    // Policy
    APPROVERS: csv, // approvedBy must be one of these (platform-governed waivers)
    JIRA_KEY_REGEX: z.string().default("^[A-Z][A-Z0-9]+-\\d+$"),
    MIN_REASON_CHARS: z.coerce.number().int().default(40),
    REPEAT_WINDOW_DAYS: z.coerce.number().int().default(30),
    REPEAT_WARN_AT: z.coerce.number().int().default(2),
    REPEAT_BLOCK_AT: z.coerce.number().int().default(4),
    MAX_HISTORY_FILES: z.coerce.number().int().default(200),
    SECURITY_SIGNOFF_RULES: csv, // rules that also want security review, e.g. CIS-4.4.1

    // Jira (optional; read-only)
    JIRA_URL: z.string().url().optional(),
    JIRA_USER: z.string().optional(),
    JIRA_TOKEN: z.string().optional(),
    JIRA_CLOSED_STATUSES: z.string().default("Done,Closed,Resolved,Cancelled").transform((v) => v.split(",").map((s) => s.trim().toLowerCase())),

    // GitHub App (permissions: Contents R, Pull requests R, Issues W [for comments], Metadata R)
    GITHUB_API_URL: z.string().url().default("https://api.github.com"),
    GITHUB_APP_ID: z.string().optional(),
    GITHUB_APP_PRIVATE_KEY: z.string().optional(),
    GITHUB_WEBHOOK_SECRET: z.string().optional(),
  })
  .superRefine((c, ctx) => {
    const bad = (path: string, message: string) => ctx.addIssue({ code: "custom", path: [path], message });
    if (!c.WATCHED_REPOS.length) bad("WATCHED_REPOS", "required (owner/name list)");
    if (!c.APPROVERS.length) bad("APPROVERS", "required: without an approver list the approvedBy check cannot work");
    if (!c.GITHUB_APP_ID || !c.GITHUB_APP_PRIVATE_KEY) bad("GITHUB_APP_ID", "GITHUB_APP_ID and GITHUB_APP_PRIVATE_KEY are required (reads PR files even in dry-run)");
    if (!c.GITHUB_WEBHOOK_SECRET) bad("GITHUB_WEBHOOK_SECRET", "required: webhook signatures are always verified");
    if (!!c.JIRA_URL !== !!c.JIRA_TOKEN) bad("JIRA_URL", "JIRA_URL and JIRA_TOKEN must be set together");
    try {
      new RegExp(c.JIRA_KEY_REGEX);
    } catch {
      bad("JIRA_KEY_REGEX", "not a valid regex");
    }
  });

export type Config = z.infer<typeof schema>;

export function loadConfig(env: Record<string, string | undefined> = process.env): Config {
  const r = schema.safeParse(env);
  if (!r.success) throw new Error("Invalid configuration:\n" + r.error.issues.map((i) => `  ${i.path.join(".")}: ${i.message}`).join("\n"));
  return r.data;
}
