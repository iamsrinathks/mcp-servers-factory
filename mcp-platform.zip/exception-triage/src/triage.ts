import { renderComment, MARKER, type Analysed } from "./comment.js";
import type { Config } from "./config.js";
import type { GitHub, Repo } from "./github.js";
import type { Jira } from "./jira.js";
import type { Logger } from "./logger.js";
import { parseExceptions, type ExceptionRequest } from "./model.js";
import { analyse, verdictOf, type JiraIssue } from "./policy.js";

export type Outcome =
  | { status: "commented"; verdict: string; created: boolean }
  | { status: "dry_run"; verdict: string; body: string }
  | { status: "skipped"; reason: string };

const MAX_FILES = 20;

export class Triage {
  private inflight = new Set<string>();
  constructor(private d: { cfg: Config; gh: GitHub; jira?: Jira | undefined; log: Logger; now?: () => Date }) {}

  async handle(repo: Repo, number: number): Promise<Outcome> {
    const { cfg, gh, jira, log } = this.d;
    const key = `${repo.owner}/${repo.name}#${number}`;
    if (this.inflight.has(key)) return { status: "skipped", reason: "already_running" };
    this.inflight.add(key);
    try {
      const pr = await gh.getPr(repo, number);
      if (pr.state !== "open") return { status: "skipped", reason: "pr_not_open" };
      if (pr.headRepo.toLowerCase() !== `${repo.owner}/${repo.name}`.toLowerCase()) return { status: "skipped", reason: "fork_pr_not_reviewed" };

      const files = (await gh.listPrFiles(repo, number)).filter((f) => f.status !== "removed" && /\.ya?ml$/i.test(f.path) && f.path.startsWith(cfg.EXCEPTIONS_PATH_PREFIX));
      const errors: string[] = [];
      const requests: ExceptionRequest[] = [];
      for (const f of files.slice(0, MAX_FILES)) {
        const p = parseExceptions(f.path, await gh.getFile(repo, f.path, pr.headSha));
        requests.push(...p.items);
        if (p.items.length) errors.push(...p.errors); // a broken YAML file with no AuditException is not our business
      }
      if (files.length > MAX_FILES) errors.push(`Only the first ${MAX_FILES} of ${files.length} YAML files were analysed.`);
      if (!requests.length) return { status: "skipped", reason: "no_audit_exception_in_pr" };

      const today = (this.d.now?.() ?? new Date()).toISOString().slice(0, 10);
      const history = await this.history(repo, pr.baseRef, new Set(files.map((f) => f.path)), today);
      const analysed: Analysed[] = [];
      for (const r of requests) {
        let issue: JiraIssue | null | undefined;
        if (jira && r.jiraTicket && new RegExp(cfg.JIRA_KEY_REGEX).test(r.jiraTicket)) {
          try {
            issue = await jira.getIssue(r.jiraTicket);
          } catch (e) {
            log.warn("jira_lookup_failed", { ticket: r.jiraTicket, err: String(e) });
            errors.push(`Jira lookup for ${r.jiraTicket} failed; ticket status was not verified.`);
          }
        }
        const prior = history === null ? null : history.filter((h) => h.namespace === r.namespace && h.ruleId === r.ruleId).length;
        const findings = analyse(r, { today, prAuthor: pr.author, priorCount: prior, jira: issue }, cfg);
        analysed.push({ request: r, findings, verdict: verdictOf(findings) });
      }

      const body = renderComment(analysed, errors, pr.headSha);
      const verdict = analysed.map((a) => a.verdict).sort().join(",");
      log.info("triage_result", { repo: `${repo.owner}/${repo.name}`, pr: number, verdicts: analysed.map((a) => a.verdict), dryRun: cfg.DRY_RUN });
      if (cfg.DRY_RUN) return { status: "dry_run", verdict, body };
      const { created } = await gh.upsertComment(repo, number, MARKER, body);
      return { status: "commented", verdict, created };
    } finally {
      this.inflight.delete(key);
    }
  }

  /** Earlier waivers still present on the base branch inside the repeat window. null = could not tell. */
  private async history(repo: Repo, baseRef: string, thisPr: Set<string>, today: string): Promise<ExceptionRequest[] | null> {
    const { cfg, gh, log } = this.d;
    try {
      const paths = (await gh.listYamlFiles(repo, baseRef)).filter((p) => p.startsWith(cfg.EXCEPTIONS_PATH_PREFIX) && !thisPr.has(p));
      if (paths.length > cfg.MAX_HISTORY_FILES) return null;
      const since = new Date(Date.parse(today) - cfg.REPEAT_WINDOW_DAYS * 86400_000).toISOString().slice(0, 10);
      const out: ExceptionRequest[] = [];
      for (const p of paths) {
        for (const e of parseExceptions(p, await gh.getFile(repo, p, baseRef)).items) if (e.validDate && e.validDate >= since && e.validDate <= today) out.push(e);
      }
      return out;
    } catch (e) {
      log.warn("history_failed", { err: String(e) });
      return null;
    }
  }
}
