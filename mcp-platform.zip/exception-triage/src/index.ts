import { loadConfig } from "./config.js";
import { createGitHub } from "./github.js";
import { createJira } from "./jira.js";
import { createLogger } from "./logger.js";
import { createApp } from "./server.js";
import { Triage } from "./triage.js";

const cfg = loadConfig();
const log = createLogger(cfg.LOG_LEVEL);
if (cfg.DRY_RUN) log.warn("dry_run", { note: "DRY_RUN=true: analysing only, no comments will be posted" });
const triage = new Triage({ cfg, gh: createGitHub(cfg), jira: createJira(cfg), log });
const server = createApp({ cfg, triage, log }).listen(cfg.PORT, () => log.info("listening", { port: cfg.PORT }));
for (const sig of ["SIGTERM", "SIGINT"] as const) process.on(sig, () => server.close(() => process.exit(0)));
