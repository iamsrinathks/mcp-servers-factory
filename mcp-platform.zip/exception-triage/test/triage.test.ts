import { createHmac } from "node:crypto";
import type { AddressInfo } from "node:net";
import { afterEach, describe, expect, it } from "vitest";
import { loadConfig } from "../src/config.js";
import type { GitHub } from "../src/github.js";
import { createLogger } from "../src/logger.js";
import { parseExceptions } from "../src/model.js";
import { analyse, verdictOf, type Evidence } from "../src/policy.js";
import { createApp, verifySignature } from "../src/server.js";
import { Triage } from "../src/triage.js";

const env = { WATCHED_REPOS: "acme/gitops", APPROVERS: "platform-lead,sre", GITHUB_APP_ID: "1", GITHUB_APP_PRIVATE_KEY: "k", GITHUB_WEBHOOK_SECRET: "whsec", TENANT_NAMESPACE_PREFIXES: "team-", SECURITY_SIGNOFF_RULES: "CIS-4.4.1", EXCEPTIONS_PATH_PREFIX: "exceptions/" };
const cfg = loadConfig(env);
const TODAY = "2026-09-29";
const yaml = (o: Record<string, unknown> = {}) => {
  const s = { ruleId: "CIS-4.1.5", workloadName: "pay", validDate: TODAY, jiraTicket: "PLAT-1", approvedBy: "platform-lead", reason: "Legacy agent calls the API at startup; rewrite tracked in PLAT-1 for next sprint.", ...o };
  const body = Object.entries(s).filter(([, v]) => v !== undefined).map(([k, v]) => `  ${k}: ${JSON.stringify(v)}`).join("\n");
  return `apiVersion: governance.platform.example.com/v1alpha1\nkind: AuditException\nmetadata:\n  name: e1\n  namespace: team-a\nspec:\n${body}\n`;
};
const ev = (o: Partial<Evidence> = {}): Evidence => ({ today: TODAY, prAuthor: "dev", priorCount: 0, jira: { key: "PLAT-1", status: "In Progress" }, ...o });
const codes = (spec: Record<string, unknown>, e = ev()) => analyse(parseExceptions("f.yaml", yaml(spec)).items[0]!, e, cfg).map((f) => `${f.severity}:${f.code}`);

describe("policy", () => {
  it("a well-formed, narrow, same-day, approved waiver has no blockers or warnings", () => {
    const f = analyse(parseExceptions("f", yaml()).items[0]!, ev(), cfg);
    expect(verdictOf(f)).toBe("no_issues_found");
  });
  it("blocks namespace-wide and wildcard scope", () => {
    expect(codes({ workloadName: undefined })).toContain("block:scope_namespace_wide");
    expect(codes({ workloadName: "pay-*" })).toContain("block:scope_wildcard");
  });
  it("blocks past dates, warns on future dates, notes today's expiry", () => {
    expect(codes({ validDate: "2026-09-28" })).toContain("block:date_past");
    expect(codes({ validDate: "2026-09-30" })).toContain("warn:date_future");
    expect(codes({})).toContain("info:date_today");
    expect(codes({ validDate: "tomorrow" })).toContain("block:date_invalid");
  });
  it("enforces approver list and no self-approval (case-insensitive)", () => {
    expect(codes({ approvedBy: "mallory" })).toContain("block:approver_not_authorised");
    expect(codes({ approvedBy: "Platform-Lead" }, ev({ prAuthor: "platform-lead" }))).toContain("block:self_approval");
    expect(codes({ approvedBy: undefined })).toContain("block:approver_missing");
  });
  it("checks the ticket: format, existence, closed", () => {
    expect(codes({ jiraTicket: "fix it" })).toContain("block:ticket_format");
    expect(codes({}, ev({ jira: null }))).toContain("block:ticket_not_found");
    expect(codes({}, ev({ jira: { key: "PLAT-1", status: "Done" } }))).toContain("block:ticket_closed");
    expect(codes({}, ev({ jira: undefined }))).toContain("info:ticket_unverified");
  });
  it("flags thin reasons and repeat waivers; unknown history is a warning, never assumed fine", () => {
    expect(codes({ reason: "needed" })).toContain("warn:reason_weak");
    expect(codes({}, ev({ priorCount: 2 }))).toContain("warn:repeat_waiver");
    expect(codes({}, ev({ priorCount: 4 }))).toContain("block:repeat_offender");
    expect(codes({}, ev({ priorCount: null }))).toContain("warn:history_unknown");
  });
  it("asks for security sign-off on configured rules", () => {
    expect(codes({ ruleId: "CIS-4.4.1" })).toContain("warn:security_signoff");
  });
  it("rejects unknown rules and non-tenant namespaces", () => {
    expect(codes({ ruleId: "CIS-9.9.9" })).toContain("block:rule_unknown");
    const r = parseExceptions("f", yaml().replace("team-a", "kube-system")).items[0]!;
    expect(analyse(r, ev(), cfg).map((x) => x.code)).toContain("namespace_not_tenant");
  });
});

describe("parseExceptions", () => {
  it("ignores other kinds, survives broken YAML and templates", () => {
    expect(parseExceptions("f", "kind: ConfigMap\n").items).toEqual([]);
    expect(parseExceptions("f", "kind: [unclosed").errors).toHaveLength(1);
    expect(parseExceptions("f", "name: {{ .Values.x }}").errors[0]).toMatch(/templated/);
    expect(parseExceptions("f", yaml() + "---\n" + yaml({ ruleId: "CIS-4.4.1" })).items).toHaveLength(2);
  });
});

function fakeGh(prFiles: Record<string, string>, base: Record<string, string> = {}, over: Partial<GitHub> = {}) {
  const comments: string[] = [];
  const gh: GitHub = {
    getPr: async (_r, n) => ({ number: n, author: "dev", state: "open", headSha: "abc1234", headRepo: "acme/gitops", baseRef: "main" }),
    listPrFiles: async () => Object.keys(prFiles).map((path) => ({ path, status: "added" })),
    getFile: async (_r, p, ref) => (ref === "main" ? base[p]! : prFiles[p]!),
    listYamlFiles: async () => Object.keys(base),
    upsertComment: async (_r, _n, _m, body) => (comments.push(body), { created: true }),
    ...over,
  };
  return { gh, comments };
}
const mk = (gh: GitHub, e: Record<string, string> = {}) => new Triage({ cfg: loadConfig({ ...env, ...e }), gh, log: createLogger("error", () => {}), now: () => new Date(`${TODAY}T10:00:00Z`) });
const repo = { owner: "acme", name: "gitops" };

describe("Triage", () => {
  it("dry-run (default) analyses but posts nothing", async () => {
    const { gh, comments } = fakeGh({ "exceptions/e1.yaml": yaml() });
    const r = await mk(gh).handle(repo, 5);
    expect(r).toMatchObject({ status: "dry_run", verdict: "no_issues_found" });
    expect(comments).toEqual([]);
  });
  it("live mode posts one comment with the marker, worded as not-an-approval", async () => {
    const { gh, comments } = fakeGh({ "exceptions/e1.yaml": yaml({ approvedBy: "dev" }) });
    const r = await mk(gh, { DRY_RUN: "false" }).handle(repo, 5);
    expect(r).toMatchObject({ status: "commented" });
    expect(comments[0]).toContain("<!-- audit-guard-exception-triage -->");
    expect(comments[0]).toContain("not an approval");
    expect(comments[0]).toContain("self-approval".replace("self-approval", "approvedBy is the PR author"));
  });
  it("counts prior waivers on the base branch from other files", async () => {
    const prior = (n: string, d: string) => yaml({ validDate: d }).replace("name: e1", `name: ${n}`);
    const { gh } = fakeGh({ "exceptions/e1.yaml": yaml() }, { "exceptions/a.yaml": prior("a", "2026-09-20"), "exceptions/b.yaml": prior("b", "2026-09-10"), "exceptions/old.yaml": prior("c", "2026-01-01") });
    const r = await mk(gh).handle(repo, 5);
    expect(r.status === "dry_run" && r.body).toContain("2 earlier waivers");
  });
  it("history it cannot compute becomes a warning, not a silent pass", async () => {
    const { gh } = fakeGh({ "exceptions/e1.yaml": yaml() }, {}, { listYamlFiles: async () => { throw new Error("boom"); } });
    const r = await mk(gh).handle(repo, 5);
    expect(r.status === "dry_run" && r.body).toContain("Could not determine");
  });
  it("skips PRs with no AuditException, closed PRs, forks, and files outside the path prefix", async () => {
    expect(await mk(fakeGh({ "exceptions/x.yaml": "kind: ConfigMap\n" }).gh).handle(repo, 1)).toMatchObject({ reason: "no_audit_exception_in_pr" });
    expect(await mk(fakeGh({ "other/e.yaml": yaml() }).gh).handle(repo, 1)).toMatchObject({ reason: "no_audit_exception_in_pr" });
    const closed = fakeGh({}, {}, { getPr: async () => ({ number: 1, author: "d", state: "closed", headSha: "s", headRepo: "acme/gitops", baseRef: "main" }) });
    expect(await mk(closed.gh).handle(repo, 1)).toMatchObject({ reason: "pr_not_open" });
    const fork = fakeGh({}, {}, { getPr: async () => ({ number: 1, author: "d", state: "open", headSha: "s", headRepo: "evil/gitops", baseRef: "main" }) });
    expect(await mk(fork.gh).handle(repo, 1)).toMatchObject({ reason: "fork_pr_not_reviewed" });
  });
  it("uses Jira when configured and degrades to a note when Jira is down", async () => {
    const { gh } = fakeGh({ "exceptions/e1.yaml": yaml() });
    const down = new Triage({ cfg, gh, jira: { getIssue: async () => { throw new Error("503"); } }, log: createLogger("error", () => {}), now: () => new Date(`${TODAY}T10:00:00Z`) });
    const r = await down.handle(repo, 5);
    expect(r.status === "dry_run" && r.body).toContain("Jira lookup for PLAT-1 failed");
    const closed = new Triage({ cfg, gh, jira: { getIssue: async () => ({ key: "PLAT-1", status: "Done" }) }, log: createLogger("error", () => {}), now: () => new Date(`${TODAY}T10:00:00Z`) });
    expect((await closed.handle(repo, 5)) as any).toMatchObject({ verdict: "do_not_approve" });
  });
});

describe("config", () => {
  it("refuses to start without approvers, webhook secret or repos", () => {
    expect(() => loadConfig({ ...env, APPROVERS: "" })).toThrow(/APPROVERS/);
    expect(() => loadConfig({ ...env, GITHUB_WEBHOOK_SECRET: "" })).toThrow(/WEBHOOK_SECRET/);
    expect(() => loadConfig({ ...env, WATCHED_REPOS: "" })).toThrow(/WATCHED_REPOS/);
    expect(loadConfig(env).DRY_RUN).toBe(true);
  });
});

describe("webhook", () => {
  let close: (() => Promise<void>) | undefined;
  afterEach(async () => void (await close?.(), (close = undefined)));
  const sign = (b: string) => "sha256=" + createHmac("sha256", "whsec").update(b).digest("hex");

  async function start() {
    const seen: number[] = [];
    const triage = { handle: async (_r: unknown, n: number) => (seen.push(n), { status: "skipped", reason: "x" }) } as unknown as Triage;
    const s = createApp({ cfg, triage, log: createLogger("error", () => {}) }).listen(0, "127.0.0.1");
    await new Promise((r) => s.once("listening", r));
    close = () => new Promise((r) => s.close(() => r()));
    const url = `http://127.0.0.1:${(s.address() as AddressInfo).port}/webhook`;
    const post = (payload: unknown, o: { sig?: string; event?: string } = {}) => {
      const body = JSON.stringify(payload);
      return fetch(url, { method: "POST", body, headers: { "content-type": "application/json", "x-github-event": o.event ?? "pull_request", "x-hub-signature-256": o.sig ?? sign(body) } });
    };
    return { post, seen };
  }
  const pr = (o: object = {}) => ({ action: "opened", number: 7, repository: { full_name: "acme/gitops" }, ...o });

  it("rejects bad or missing signatures", async () => {
    expect(verifySignature("s", Buffer.from("x"), undefined)).toBe(false);
    expect(verifySignature("s", Buffer.from("x"), "sha256=zz")).toBe(false);
    const { post, seen } = await start();
    expect((await post(pr(), { sig: "sha256=" + "0".repeat(64) })).status).toBe(401);
    expect(seen).toEqual([]);
  });
  it("accepts signed PR events for watched repos, ignores everything else", async () => {
    const { post, seen } = await start();
    expect((await post(pr())).status).toBe(202);
    await new Promise((r) => setTimeout(r, 20));
    expect(seen).toEqual([7]);
    await post(pr({ action: "closed" }));
    await post(pr({ repository: { full_name: "acme/other" } }));
    await post(pr(), { event: "push" });
    await new Promise((r) => setTimeout(r, 20));
    expect(seen).toEqual([7]);
  });
});
