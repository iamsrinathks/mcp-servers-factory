# Problem statement

Audience: anyone (human or AI agent) who needs to know **what this repo is for and why it exists** before touching the code.

## Context

We are the platform team for a shared, multi-tenant GKE cluster at a bank. Tenants deploy through GitOps (Backstage IDP, Anthos Config Management, Config Sync). To meet CIS controls we are introducing **Audit-Guard**, a validating admission webhook that enforces two rules on tenant workloads:

| Rule | Meaning |
|---|---|
| CIS 4.4.1 | Secrets must not be injected as environment variables (`secretKeyRef`, `envFrom.secretRef`); mount them as files instead |
| CIS 4.1.5 | Pods must set `automountServiceAccountToken: false` unless they truly need the Kubernetes API |

Where a tenant genuinely cannot comply yet, the platform team can grant a time-boxed waiver: an `AuditException` custom resource, valid only on its `validDate` (same day, UTC), tied to a Jira ticket and an approver.

Audit-Guard is what makes existing tenants hit a wall. Turning it on is therefore an organisational problem as much as a technical one. This repo contains the tooling that keeps that rollout from drowning the platform team and from breaking teams. It is a **proof of concept** for the Audit-Guard POC.

## The three problems, and what we build for each

### 1. Nobody can quickly see *why* something was denied → `server/` + `gateway/` (read-only MCP)

**Today.** A denied deploy shows up as a failed sync or a `kubectl` error. To diagnose it, an engineer has to know which webhook denied it, then piece together `AuditException` objects, Config Sync status, events, pod state and the webhook's own health from several places, usually by asking the platform team.

**Why solve it.** Diagnosis is the top source of "please help" tickets during a rollout, and it is slow and repetitive. Engineers (and the AI assistants they already use) can answer most of it themselves if they can *ask the cluster safely*.

**What we build.** A read-only MCP server (`k8s-governance-mcp`) exposing 7 tools (`list_audit_exceptions`, `get_audit_exception`, `explain_denial`, `get_workload_status`, `list_events`, `get_configsync_status`, `get_audit_guard_health`), behind an MCP gateway that provides the banking-grade edge: JWT auth, per-user rate limits, circuit breaking, audit logging. Tenants only see their own namespaces; the cluster role has get/list only and **no access to Secrets**.

**Success looks like.** A tenant asks their assistant "why was payment-service denied?" and gets the rule, the fix, and whether a waiver exists, without a platform ticket.

### 2. Every denial needs a human to hand-write the same fix → `pr-drafter/`

**Today.** After a denial, someone works out which manifest to change, edits it, and opens a PR. The fix for these two rules is almost always the same mechanical change.

**Why solve it.** Toil for tenants, and a slow rollout: the faster teams fix, the fewer waivers we need. Waivers are risk we would rather not carry.

**What we build.** A service that consumes the denial log line and opens a **draft PR** against the owning team's repo (found through Backstage), with the minimal YAML fix and a "check before you merge" list. The fix is deterministic code (not an LLM), validated by re-running the same rules on its own output. It never merges.

**Success looks like.** A denial results in a small, reviewable PR the team can merge in minutes, and the team's response is "looks right" more often than "this is wrong".

### 3. Reviewing waiver requests is slow and inconsistent → `exception-triage/`

**Today.** Waiver PRs arrive and an approver checks the same things by hand each time: is it scoped to one workload, is the date today, is the ticket real and open, is the approver legitimate, has this team asked before. Misses are possible and the standard drifts by reviewer.

**Why solve it.** Waivers are the escape hatch of a security control. They must be narrow, justified and rare, and approvers' time is scarce.

**What we build.** A reviewer aid that runs those checks on every `AuditException` PR and posts one comment. It flags blockers and points needing judgement and states plainly that it is not an approval. The verdict is deterministic; branch protection with CODEOWNERS remains the real control.

**Success looks like.** Approvers spend their time on "does this workload really need this?" (which only a person can answer) instead of checking dates and ticket numbers.

## How they fit together

```
 tenant/engineer ── asks ──▶ [1] MCP gateway ▶ MCP server ▶ cluster (read-only)   "why was I denied?"
 Audit-Guard denial ─ log ─▶ [2] PR drafter ─▶ draft PR in tenant repo             "here is the fix"
 tenant can't comply ─ PR ─▶ [3] Exception triage ─▶ comment on waiver PR          "here's what to check"
                                                     └─▶ platform approver decides
```

The goal is that most denials end in a fix (path 2), the rest end in a *narrow, time-boxed, well-justified* waiver (path 3), and everyone can find out what happened without asking us (path 1).

## Principles (do not break these)

1. **AI and automation only read or propose.** Humans approve and merge. No component merges, approves, or writes an `AuditException`.
2. **Never touch Secrets.** No component reads Secret objects or values. RBAC excludes them; logs are redacted.
3. **Deterministic where it matters.** Fixes and verdicts come from testable code. An LLM is not in the decision path of any control.
4. **Unknown is not OK.** If evidence is missing (Jira down, owner unresolved, history unavailable), say so or do nothing. Never assume it passes.
5. **Fail closed, start in dry-run.** Every writer defaults to `DRY_RUN=true`, is limited to pilot namespaces/repos, and has rate caps.
6. **Least privilege, per repo.** GitHub App tokens are minted per repository with the smallest permission set.
7. **Reversible and idempotent.** Deterministic branch names, one comment updated in place, duplicate events collapse.

## Non-goals

- Not a replacement for Audit-Guard or its enforcement. This repo helps people live with it.
- No automatic waiver creation or approval, and no auto-merge, ever.
- No remediation of Helm-templated or non-YAML sources (flagged for a human instead).
- No judgement about whether a workload *needs* an exception; that is the approver's job.
- Not production-hardened yet. See "Status" in the README.
